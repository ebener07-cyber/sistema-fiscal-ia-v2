import fs from 'fs';
import path from 'path';

/**
 * Parser de Graphify - Carga la memoria técnica del proyecto
 * Enriquece los prompts de IA con contexto del sistema
 */

interface GraphifyContext {
  contexto: string;
  entidades: string;
  relaciones: string;
  componentes: string;
  rutas: string;
  mapaDelSistema: string;
}

async function loadGraphifyFile(filename: string): Promise<string> {
  try {
    const filePath = path.join(process.cwd(), 'graphify', filename);
    return fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    console.warn(`No se pudo cargar ${filename}:`, error);
    return '';
  }
}

export async function loadGraphifyContext(): Promise<GraphifyContext> {
  const [contexto, entidades, relaciones, componentes, rutas, mapaDelSistema] = await Promise.all([
    loadGraphifyFile('contexto.md'),
    loadGraphifyFile('entidades.md'),
    loadGraphifyFile('relaciones.md'),
    loadGraphifyFile('componentes.md'),
    loadGraphifyFile('rutas.md'),
    loadGraphifyFile('mapa_sistema.md'),
  ]);

  return {
    contexto,
    entidades,
    relaciones,
    componentes,
    rutas,
    mapaDelSistema,
  };
}

/**
 * Enriquece un prompt base con contexto de Graphify
 */
export async function enrichPromptWithGraphify(basePrompt: string): Promise<string> {
  try {
    const graphify = await loadGraphifyContext();

    // Resumir contexto para no exceder límites de tokens
    const resumedGraphify = `
## CONTEXTO TÉCNICO DEL SISTEMA

### Arquitectura
${graphify.contexto.substring(0, 500)}...

### Entidades Principales
${graphify.entidades.substring(0, 400)}...

### Rutas API Disponibles
${graphify.rutas.substring(0, 300)}...

### Relaciones de Datos
${graphify.relaciones.substring(0, 200)}...
`;

    return `${basePrompt}\n\n${resumedGraphify}`;
  } catch (error) {
    console.error('Error enriqueciendo prompt con Graphify:', error);
    return basePrompt;
  }
}

/**
 * Extrae información específica de Graphify
 */
export async function getGraphifySection(section: keyof GraphifyContext): Promise<string> {
  const graphify = await loadGraphifyContext();
  return graphify[section] || '';
}
