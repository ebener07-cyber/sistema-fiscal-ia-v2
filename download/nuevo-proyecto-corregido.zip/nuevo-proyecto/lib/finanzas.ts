/**
 * lib/finanzas.ts
 *
 * Lógica de negocio del módulo de Reestructura Financiera.
 * Implementa los cálculos descritos en el plan de 3 fases:
 *   - Fase 1: Diagnóstico (patrimonio neto, fondo emergencia, 50/30/20)
 *   - Fase 2: Avalancha de deudas y proyección de pagos
 *   - Fase 3: Crecimiento, inversiones y KPIs
 */

import prisma from './prisma';

// --------------------------------------------------------------------------
// Tipos compartidos
// --------------------------------------------------------------------------

export interface ResumenPatrimonio {
  activoTotal: number;
  pasivoTotal: number;
  patrimonioNeto: number;
  activosLiquidables: number; // Efectivo + inversiones líquidas
  activosIlliquidos: number;  // Bienes raíces, vehículos
  desglosePorTipoActivo: Array<{ tipo: string; total: number; count: number }>;
  desglosePorTipoPasivo: Array<{ tipo: string; total: number; count: number }>;
}

export interface ProyeccionPagoDeuda {
  mes: number;
  pagoTotal: number;
  interesPagado: number;
  capitalPagado: number;
  saldoRestante: number;
}

export interface DeudaConEstrategia {
  id: string;
  nombre: string;
  acreedor: string;
  saldoActual: number;
  tasaInteresMensual: number;
  pagoMensualMinimo: number;
  estrategia: 'avalancha' | 'bola_nieve' | 'personalizada';
  prioridadCalculada: number;
  estado: string;
  mesesParaPagar: number | null;
  interesTotalEstimado: number;
  proyeccion: ProyeccionPagoDeuda[];
}

export interface DistribucionFlujoCaja {
  ingresos: number;
  necesidades: number; // 50% objetivo
  deseos: number;      // 30% objetivo
  ahorroInversion: number; // 20% objetivo
  // Porcentaje real del total de egresos
  pctNecesidades: number;
  pctDeseos: number;
  pctAhorro: number;
  tasaAhorroReal: number; // (ingresos - egresos) / ingresos
  evaluacion: 'sano' | 'atenido' | 'critico';
  recomendacion: string;
}

export interface KPISnapshot {
  fecha: Date;
  patrimonioNeto: number;
  activoTotal: number;
  pasivoTotal: number;
  tasaAhorro: number;
  ratioEndeudamiento: number; // deuda total / ingresos mensuales
  diasCoberturaCaja: number;  // saldo caja / gastos diarios
  progresoFondoEmergencia: number; // %
  totalDeudas: number;
  faseActual: 1 | 2 | 3;
  // Evaluación contra metas
  alertas: string[];
}

// --------------------------------------------------------------------------
// FASE 1: Diagnóstico
// --------------------------------------------------------------------------

/**
 * Calcula el patrimonio neto de una empresa sumando todos sus activos
 * y restando todos sus pasivos registrados.
 */
export async function calcularPatrimonioNeto(empresaId: string): Promise<ResumenPatrimonio> {
  const [activos, pasivos] = await Promise.all([
    prisma.activo.findMany({ where: { empresaId } }),
    prisma.pasivo.findMany({ where: { empresaId, estado: { not: 'pagada' } } }),
  ]);

  const activoTotal = activos.reduce((sum, a) => sum + a.valor, 0);
  const pasivoTotal = pasivos.reduce((sum, p) => sum + p.saldo, 0);
  const patrimonioNeto = activoTotal - pasivoTotal;

  const activosLiquidables = activos
    .filter((a) => a.esLiquidable)
    .reduce((sum, a) => sum + a.valor, 0);
  const activosIlliquidos = activoTotal - activosLiquidables;

  // Desglose por tipo
  const tiposActivoMap = new Map<string, { total: number; count: number }>();
  for (const a of activos) {
    const cur = tiposActivoMap.get(a.tipo) ?? { total: 0, count: 0 };
    cur.total += a.valor;
    cur.count += 1;
    tiposActivoMap.set(a.tipo, cur);
  }
  const tiposPasivoMap = new Map<string, { total: number; count: number }>();
  for (const p of pasivos) {
    const cur = tiposPasivoMap.get(p.tipo) ?? { total: 0, count: 0 };
    cur.total += p.saldo;
    cur.count += 1;
    tiposPasivoMap.set(p.tipo, cur);
  }

  return {
    activoTotal,
    pasivoTotal,
    patrimonioNeto,
    activosLiquidables,
    activosIlliquidos,
    desglosePorTipoActivo: Array.from(tiposActivoMap.entries()).map(([tipo, v]) => ({
      tipo,
      total: v.total,
      count: v.count,
    })),
    desglosePorTipoPasivo: Array.from(tiposPasivoMap.entries()).map(([tipo, v]) => ({
      tipo,
      total: v.total,
      count: v.count,
    })),
  };
}

/**
 * Obtiene o crea el fondo de emergencia de una empresa.
 * Si no existe, lo crea con la meta por defecto ($200,000 MXN).
 */
export async function obtenerOcrearFondoEmergencia(empresaId: string) {
  const existente = await prisma.fondoEmergencia.findFirst({ where: { empresaId } });
  if (existente) return existente;

  return prisma.fondoEmergencia.create({
    data: { empresaId, meta: 200000, saldoActual: 0 },
  });
}

/**
 * Registra un depósito o retiro al fondo de emergencia y actualiza el saldo.
 */
export async function registrarMovimientoFondo(params: {
  fondoId: string;
  tipo: 'deposito' | 'retiro';
  monto: number;
  descripcion?: string;
}) {
  const { fondoId, tipo, monto, descripcion } = params;
  if (monto <= 0) throw new Error('El monto debe ser mayor a 0');

  return prisma.$transaction(async (tx) => {
    const fondo = await tx.fondoEmergencia.findUnique({ where: { id: fondoId } });
    if (!fondo) throw new Error('Fondo de emergencia no encontrado');

    const delta = tipo === 'deposito' ? monto : -monto;
    const nuevoSaldo = fondo.saldoActual + delta;
    if (nuevoSaldo < 0) {
      throw new Error(
        `Saldo insuficiente. Saldo actual: $${fondo.saldoActual.toFixed(2)} MXN, intentando retirar $${monto.toFixed(2)} MXN`
      );
    }

    await tx.movimientoFondo.create({
      data: { fondoId, tipo, monto, descripcion },
    });

    return tx.fondoEmergencia.update({
      where: { id: fondoId },
      data: { saldoActual: nuevoSaldo },
    });
  });
}

/**
 * Calcula la distribución 50/30/20 del flujo de caja del mes actual.
 */
export async function calcularFlujoCaja(
  empresaId: string,
  anio: number,
  mes: number // 1-12
): Promise<DistribucionFlujoCaja> {
  const inicio = new Date(anio, mes - 1, 1);
  const fin = new Date(anio, mes, 0, 23, 59, 59, 999);

  const movimientos = await prisma.movimientoFinanciero.findMany({
    where: {
      empresaId,
      fecha: { gte: inicio, lte: fin },
    },
  });

  const ingresos = movimientos
    .filter((m) => m.tipo === 'ingreso')
    .reduce((s, m) => s + m.monto, 0);

  const necesidades = movimientos
    .filter((m) => m.tipo === 'egreso' && m.categoria === 'necesidad')
    .reduce((s, m) => s + m.monto, 0);
  const deseos = movimientos
    .filter((m) => m.tipo === 'egreso' && m.categoria === 'deseo')
    .reduce((s, m) => s + m.monto, 0);
  const ahorroInversion = movimientos
    .filter((m) => m.tipo === 'egreso' && m.categoria === 'ahorro_inversion')
    .reduce((s, m) => s + m.monto, 0);

  const totalEgresos = necesidades + deseos + ahorroInversion;
  const pctNecesidades = totalEgresos > 0 ? (necesidades / totalEgresos) * 100 : 0;
  const pctDeseos = totalEgresos > 0 ? (deseos / totalEgresos) * 100 : 0;
  const pctAhorro = totalEgresos > 0 ? (ahorroInversion / totalEgresos) * 100 : 0;

  const tasaAhorroReal = ingresos > 0 ? ((ingresos - totalEgresos) / ingresos) * 100 : 0;

  // Evaluación
  let evaluacion: 'sano' | 'atenido' | 'critico' = 'sano';
  if (tasaAhorroReal < 0) evaluacion = 'critico';
  else if (tasaAhorroReal < 20) evaluacion = 'atenido';

  let recomendacion = '';
  if (evaluacion === 'critico') {
    recomendacion =
      '⚠️ Gastos mayores a ingresos. Reduce deseos (30% objetivo) y revisa necesidades fijas.';
  } else if (evaluacion === 'atenido') {
    recomendacion =
      '📈 Tasa de ahorro por debajo del 20% objetivo. Recorta deseos para alcanzar meta.';
  } else {
    recomendacion = '✅ Distribución saludable. Destina el exceso a pago de deudas o inversión.';
  }

  return {
    ingresos,
    necesidades,
    deseos,
    ahorroInversion,
    pctNecesidades,
    pctDeseos,
    pctAhorro,
    tasaAhorroReal,
    evaluacion,
    recomendacion,
  };
}

// --------------------------------------------------------------------------
// FASE 2: Avalancha de deudas
// --------------------------------------------------------------------------

/**
 * Ordena las deudas según la estrategia indicada:
 * - avalancha: tasa de interés más alta primero (menos costo total)
 * - bola_nieve: saldo más bajo primero (motivación psicológica)
 * - personalizada: respeta el campo `prioridad` (1 = primera)
 */
export async function ordenarDeudasPorEstrategia(
  empresaId: string
): Promise<DeudaConEstrategia[]> {
  const deudas = await prisma.deuda.findMany({
    where: { empresaId, estado: { in: ['activa', 'en_pago'] } },
  });

  // Mapear a struct enriquecida
  const enriquecidas: DeudaConEstrategia[] = deudas.map((d) => {
    const proyeccion = calcularProyeccionPago(
      d.saldoActual,
      d.tasaInteresMensual,
      d.pagoMensualMinimo
    );
    const interesTotalEstimado = proyeccion.reduce((s, p) => s + p.interesPagado, 0);
    const ultimoMes = proyeccion[proyeccion.length - 1];
    return {
      id: d.id,
      nombre: d.nombre,
      acreedor: d.acreedor,
      saldoActual: d.saldoActual,
      tasaInteresMensual: d.tasaInteresMensual,
      pagoMensualMinimo: d.pagoMensualMinimo,
      estrategia: d.estrategia as 'avalancha' | 'bola_nieve' | 'personalizada',
      prioridadCalculada: 0,
      estado: d.estado,
      mesesParaPagar: proyeccion.length === 0 ? null : proyeccion.length,
      interesTotalEstimado,
      proyeccion,
      // unused but required by signature
      ...(ultimoMes ? {} : {}),
    };
  });

  // Ordenar
  for (const d of enriquecidas) {
    if (d.estrategia === 'avalancha') {
      d.prioridadCalculada = 0; // se ordenará por tasa
    } else if (d.estrategia === 'bola_nieve') {
      d.prioridadCalculada = 0; // se ordenará por saldo
    } else {
      // personalizada: usa la prioridad guardada en la deuda original
      const original = deudas.find((x) => x.id === d.id);
      d.prioridadCalculada = original?.prioridad ?? 99;
    }
  }

  // Si todas son avalancha → ordenar por tasa desc
  // Si todas son bola_nieve → ordenar por saldo asc
  // Mixto → priorizar avalancha por defecto
  const todasAvalancha = enriquecidas.every((d) => d.estrategia === 'avalancha');
  const todasBolaNieve = enriquecidas.every((d) => d.estrategia === 'bola_nieve');

  if (todasAvalancha) {
    enriquecidas.sort((a, b) => b.tasaInteresMensual - a.tasaInteresMensual);
  } else if (todasBolaNieve) {
    enriquecidas.sort((a, b) => a.saldoActual - b.saldoActual);
  } else {
    // Mixto: ordenar por prioridadCalculada asc
    enriquecidas.sort((a, b) => a.prioridadCalculada - b.prioridadCalculada);
  }

  // Asignar prioridad final (1-indexed)
  enriquecidas.forEach((d, i) => {
    d.prioridadCalculada = i + 1;
  });

  return enriquecidas;
}

/**
 * Proyecta el pago de una deuda mes a mes con el método de amortización
 * francés (pago fijo mensual).
 *
 * @param saldo Saldo actual
 * @param tasaMensual Tasa de interés mensual en decimal (0.04 = 4%)
 * @param pagoMensual Pago mensual fijo. Si es <= interés del primer mes,
 *   la deuda nunca se paga y se retorna array vacío con advertencia.
 */
export function calcularProyeccionPago(
  saldo: number,
  tasaMensualPct: number,
  pagoMensual: number
): ProyeccionPagoDeuda[] {
  if (saldo <= 0) return [];
  const tasaMensual = tasaMensualPct / 100;
  const interesPrimerMes = saldo * tasaMensual;
  if (pagoMensual <= interesPrimerMes) {
    // El pago no cubre ni el interés → deuda crecería indefinidamente
    return [];
  }

  const proyeccion: ProyeccionPagoDeuda[] = [];
  let saldoRestante = saldo;
  let mes = 0;
  const MAX_MESES = 600; // 50 años de tope

  while (saldoRestante > 0.01 && mes < MAX_MESES) {
    mes++;
    const interesPagado = saldoRestante * tasaMensual;
    let capitalPagado = pagoMensual - interesPagado;
    if (capitalPagado > saldoRestante) {
      capitalPagado = saldoRestante;
    }
    const pagoTotal = capitalPagado + interesPagado;
    saldoRestante -= capitalPagado;
    proyeccion.push({
      mes,
      pagoTotal,
      interesPagado,
      capitalPagado,
      saldoRestante: Math.max(0, saldoRestante),
    });
  }

  return proyeccion;
}

/**
 * Calcula el "presupuesto avalancha" recomendado: cuánto destinar a la
 * deuda prioridad #1 además del mínimo, dado un excedente mensual.
 */
export function calcularPresupuestoAvalancha(
  deudasOrdenadas: DeudaConEstrategia[],
  excedenteMensual: number
): {
  pagoDeudaPrioridad1: number;
  pagoTotalMinimoOtras: number;
  descripcion: string;
} {
  if (deudasOrdenadas.length === 0) {
    return {
      pagoDeudaPrioridad1: 0,
      pagoTotalMinimoOtras: 0,
      descripcion: 'No hay deudas registradas.',
    };
  }

  const [principal, ...resto] = deudasOrdenadas;
  const pagoTotalMinimoOtras = resto.reduce((s, d) => s + d.pagoMensualMinimo, 0);
  const pagoDeudaPrioridad1 = principal.pagoMensualMinimo + excedenteMensual;

  return {
    pagoDeudaPrioridad1,
    pagoTotalMinimoOtras,
    descripcion: `Pagar mínimo en ${resto.length} deudas ($${pagoTotalMinimoOtras.toFixed(
      2
    )} MXN) y destinar TODO el excedente ($${excedenteMensual.toFixed(
      2
    )} MXN) a "${principal.nombre}" → $${pagoDeudaPrioridad1.toFixed(2)} MXN/mes.`,
  };
}

// --------------------------------------------------------------------------
// FASE 3: Crecimiento y KPIs
// --------------------------------------------------------------------------

/**
 * Calcula el snapshot completo de KPIs financieros de una empresa.
 *
 * Requiere:
 *   - Activos y pasivos registrados
 *   - Movimientos financieros del mes en curso (para tasa de ahorro)
 *   - Fondo de emergencia
 *   - Deudas activas
 *
 * Determina la fase actual del plan según:
 *   - Fase 1: sin fondo de emergencia o < 50% de meta
 *   - Fase 2: fondo ≥ 50% pero hay deudas con tasa > 5% mensual
 *   - Fase 3: fondo completo y deudas controladas
 */
export async function calcularKPIs(empresaId: string): Promise<KPISnapshot> {
  const patrimonio = await calcularPatrimonioNeto(empresaId);
  const fondo = await obtenerOcrearFondoEmergencia(empresaId);
  const deudas = await prisma.deuda.findMany({
    where: { empresaId, estado: { in: ['activa', 'en_pago'] } },
  });

  const hoy = new Date();
  const flujo = await calcularFlujoCaja(empresaId, hoy.getFullYear(), hoy.getMonth() + 1);

  const totalDeudas = deudas.reduce((s, d) => s + d.saldoActual, 0);
  const progresoFondoEmergencia =
    fondo.meta > 0 ? (fondo.saldoActual / fondo.meta) * 100 : 0;

  // Días de cobertura de caja = activos liquidables / (gastos mensuales / 30)
  const gastosMensuales = flujo.necesidades + flujo.deseos;
  const gastosDiarios = gastosMensuales / 30;
  const diasCoberturaCaja =
    gastosDiarios > 0 ? Math.floor(patrimonio.activosLiquidables / gastosDiarios) : 0;

  // Ratio endeudamiento = total deudas / ingresos mensuales
  const ratioEndeudamiento =
    flujo.ingresos > 0 ? (totalDeudas / flujo.ingresos) * 100 : 0;

  // Determinar fase
  let faseActual: 1 | 2 | 3 = 1;
  const tieneDeudaAgresiva = deudas.some((d) => d.tasaInteresMensual >= 5);
  if (progresoFondoEmergencia < 50) {
    faseActual = 1;
  } else if (tieneDeudaAgresiva) {
    faseActual = 2;
  } else {
    faseActual = 3;
  }

  // Alertas
  const alertas: string[] = [];
  if (progresoFondoEmergencia < 50) {
    alertas.push(
      `🚨 Fondo de emergencia al ${progresoFondoEmergencia.toFixed(1)}% — prioridad absoluta completarlo.`
    );
  }
  if (flujo.tasaAhorroReal < 20) {
    alertas.push(
      `⚠️ Tasa de ahorro real ${flujo.tasaAhorroReal.toFixed(1)}% — objetivo mínimo 20%.`
    );
  }
  if (ratioEndeudamiento > 36) {
    alertas.push(
      `⚠️ Ratio endeudamiento ${ratioEndeudamiento.toFixed(1)}% — objetivo < 36%.`
    );
  }
  if (diasCoberturaCaja < 60) {
    alertas.push(
      `⚠️ Cobertura de caja ${diasCoberturaCaja} días — objetivo > 60 días.`
    );
  }
  if (tieneDeudaAgresiva) {
    const agresivas = deudas.filter((d) => d.tasaInteresMensual >= 5);
    alertas.push(
      `🎯 ${agresivas.length} deuda(s) con tasa ≥ 5% mensual — aplicar avalancha urgente.`
    );
  }

  return {
    fecha: hoy,
    patrimonioNeto: patrimonio.patrimonioNeto,
    activoTotal: patrimonio.activoTotal,
    pasivoTotal: patrimonio.pasivoTotal,
    tasaAhorro: flujo.tasaAhorroReal,
    ratioEndeudamiento,
    diasCoberturaCaja,
    progresoFondoEmergencia,
    totalDeudas,
    faseActual,
    alertas,
  };
}

/**
 * Guarda un snapshot de los KPIs actuales en la base de datos.
 * Útil para histórico y gráficas de evolución.
 */
export async function guardarSnapshotKPIs(empresaId: string): Promise<KPISnapshot> {
  const kpis = await calcularKPIs(empresaId);
  await prisma.kPIFinanciero.create({
    data: {
      empresaId,
      fecha: kpis.fecha,
      patrimonioNeto: kpis.patrimonioNeto,
      activoTotal: kpis.activoTotal,
      pasivoTotal: kpis.pasivoTotal,
      tasaAhorro: kpis.tasaAhorro,
      ratioEndeudamiento: kpis.ratioEndeudamiento,
      diasCoberturaCaja: kpis.diasCoberturaCaja,
      progresoFondoEmergencia: kpis.progresoFondoEmergencia,
      totalDeudas: kpis.totalDeudas,
      faseActual: kpis.faseActual,
    },
  });
  return kpis;
}

// --------------------------------------------------------------------------
// Utilidades de formateo (para usar desde API y front)
// --------------------------------------------------------------------------

export function formatearMXN(cantidad: number): string {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    minimumFractionDigits: 2,
  }).format(cantidad);
}

export function formatearPorcentaje(valor: number, decimales = 1): string {
  return `${valor.toFixed(decimales)}%`;
}
