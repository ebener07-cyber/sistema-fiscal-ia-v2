import puppeteer, { Browser, Page } from 'puppeteer';
import * as fs from 'fs';
import * as path from 'path';

export interface SATCredentials {
  rfc: string;
  certificatePath: string;
  keyPath: string;
  password: string; // Contraseña de la e.firma
}

export class SATPuppeteerService {
  private browser?: Browser;
  private page?: Page;
  private credentials: SATCredentials;

  constructor(credentials: SATCredentials) {
    this.credentials = credentials;
  }

  /**
   * Iniciar navegador y login al SAT
   */
  async login(): Promise<void> {
    console.log('🔐 Iniciando sesión en el SAT...');

    this.browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });

    this.page = await this.browser.newPage();

    try {
      // Ir al portal de descarga masiva
      await this.page.goto('https://cfdidescargamasivasolicitud.clouda.sat.gob.mx/', {
        waitUntil: 'networkidle0',
        timeout: 60000,
      });

      console.log('📄 Portal del SAT cargado');

      // Esperar a que cargue el formulario
      await this.page.waitForSelector('#rfc', { timeout: 10000 });

      // Llenar RFC
      await this.page.type('#rfc', this.credentials.rfc);
      console.log('✍️  RFC ingresado');

      // Subir certificado .cer
      const certInput = await this.page.$('input[type="file"][accept=".cer"]');
      if (certInput) {
        await certInput.uploadFile(this.credentials.certificatePath);
        console.log('📄 Certificado .cer subido');
      }

      // Subir llave .key
      const keyInput = await this.page.$('input[type="file"][accept=".key"]');
      if (keyInput) {
        await keyInput.uploadFile(this.credentials.keyPath);
        console.log('🔑 Llave .key subida');
      }

      // Ingresar contraseña de e.firma
      await this.page.type('#contrasenia', this.credentials.password);
      console.log('✍️  Contraseña ingresada');

      // Resolver CAPTCHA (esto es manual o con servicio externo)
      console.log('⚠️  Resuelve el CAPTCHA manualmente en los próximos 30 segundos...');
      
      // Esperar a que el usuario resuelva el CAPTCHA
      await this.page.waitForSelector('#btnEnviar', { timeout: 30000 });

      // Click en Enviar
      await this.page.click('#btnEnviar');
      console.log('✅ Login enviado');

      // Esperar a que cargue el dashboard
      await this.page.waitForNavigation({ waitUntil: 'networkidle0', timeout: 30000 });
      console.log('✅ Sesión iniciada exitosamente');

    } catch (error) {
      console.error('❌ Error en login:', error);
      throw new Error('Error iniciando sesión en el SAT');
    }
  }

  /**
   * Solicitar descarga masiva
   */
  async solicitarDescarga(fechaInicial: string, fechaFinal: string, tipo: 'emitidos' | 'recibidos'): Promise<string> {
    if (!this.page) {
      throw new Error('Debes iniciar sesión primero');
    }

    console.log(`📤 Solicitando descarga: ${fechaInicial} a ${fechaFinal}`);

    try {
      // Seleccionar tipo de comprobante
      await this.page.select('#tipoSolicitud', tipo === 'emitidos' ? 'CFDI' : 'CFDI');
      
      // Seleccionar relación de terceros
      await this.page.select('#relacionTerceros', tipo === 'emitidos' ? 'R' : 'T');

      // Ingresar fechas
      await this.page.type('#fechaInicial', fechaInicial);
      await this.page.type('#fechaFinal', fechaFinal);

      // Click en solicitar
      await this.page.click('#btnSolicitar');

      // Esperar confirmación
      await this.page.waitForSelector('.alert-success', { timeout: 30000 });

      // Extraer ID de solicitud
      const solicitudElement = await this.page.$('.solicitud-id');
      const solicitudId = solicitudElement ? await this.page.evaluate(el => el.textContent, solicitudElement) : '';

      console.log(`✅ Solicitud creada: ${solicitudId}`);
      return solicitudId || '';
    } catch (error) {
      console.error('❌ Error solicitando descarga:', error);
      throw new Error('Error solicitando descarga');
    }
  }

  /**
   * Verificar estado de solicitudes
   */
  async verificarEstado(solicitudId: string): Promise<any> {
    if (!this.page) {
      throw new Error('Debes iniciar sesión primero');
    }

    console.log(`🔍 Verificando estado: ${solicitudId}`);

    try {
      // Ir a sección de consultas
      await this.page.goto('https://cfdidescargamasivasolicitud.clouda.sat.gob.mx/consultas', {
        waitUntil: 'networkidle0',
      });

      // Buscar solicitud
      await this.page.type('#solicitudId', solicitudId);
      await this.page.click('#btnBuscar');

      // Esperar resultados
      await this.page.waitForSelector('.resultado-solicitud', { timeout: 10000 });

      // Extraer información
      const estado = await this.page.evaluate(() => {
        const el = document.querySelector('.estado');
        return el ? el.textContent : 'desconocido';
      });

      const numeroCFDIs = await this.page.evaluate(() => {
        const el = document.querySelector('.numero-cfdis');
        return el ? parseInt(el.textContent) : 0;
      });

      console.log(`✅ Estado: ${estado}, CFDIs: ${numeroCFDIs}`);

      return {
        estado,
        numeroCFDIs,
      };
    } catch (error) {
      console.error('❌ Error verificando estado:', error);
      throw new Error('Error verificando estado');
    }
  }

  /**
   * Descargar paquete
   */
  async descargarPaquete(solicitudId: string, paqueteId: string): Promise<Buffer> {
    if (!this.page) {
      throw new Error('Debes iniciar sesión primero');
    }

    console.log(`📥 Descargando paquete: ${paqueteId}`);

    try {
      // Configurar descarga
      const downloadPath = path.join(process.cwd(), 'downloads');
      if (!fs.existsSync(downloadPath)) {
        fs.mkdirSync(downloadPath, { recursive: true });
      }

      const client = await this.page.target().createCDPSession();
      await client.send('Page.setDownloadBehavior', {
        behavior: 'allow',
        downloadPath: downloadPath,
      });

      // Click en descargar paquete
      await this.page.click(`#descargar-${paqueteId}`);

      // Esperar descarga
      await new Promise(resolve => setTimeout(resolve, 10000));

      // Leer archivo descargado
      const files = fs.readdirSync(downloadPath);
      const zipFile = files.find(f => f.endsWith('.zip'));

      if (zipFile) {
        const buffer = fs.readFileSync(path.join(downloadPath, zipFile));
        console.log('✅ Paquete descargado');
        return buffer;
      }

      throw new Error('No se encontró el archivo descargado');
    } catch (error) {
      console.error('❌ Error descargando paquete:', error);
      throw new Error('Error descargando paquete');
    }
  }

  /**
   * Cerrar navegador
   */
  async close(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      console.log('🔒 Sesión cerrada');
    }
  }
}

export function createSATPuppeteerService(credentials: SATCredentials): SATPuppeteerService {
  return new SATPuppeteerService(credentials);
}