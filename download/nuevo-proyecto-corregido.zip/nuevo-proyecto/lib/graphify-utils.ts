/**
 * Utilidades para trabajar con Graphify
 */

import { GraphifySectionKey } from '@/src/types/graphify';

/**
 * Extrae una sección específica de un contenido Markdown
 * Útil para parsear Graphify y extraer información estructurada
 */
export function extractMarkdownSection(content: string, sectionTitle: string): string {
  const lines = content.split('\n');
  let capturing = false;
  let sectionContent = '';

  for (const line of lines) {
    if (line.includes(sectionTitle)) {
      capturing = true;
      continue;
    }

    if (capturing) {
      // Detener si encontramos otro encabezado de nivel 1 o 2
      if (line.match(/^#{1,2}\s/)) {
        break;
      }
      sectionContent += line + '\n';
    }
  }

  return sectionContent.trim();
}

/**
 * Extrae todas las listas de un contenido Markdown
 */
export function extractMarkdownLists(content: string): string[] {
  const regex = /^[\s]*[-*]\s(.+)$/gm;
  const matches = content.match(regex) || [];
  return matches.map((item) => item.trim());
}

/**
 * Extrae todos los enlaces de un contenido Markdown
 */
export function extractMarkdownLinks(content: string): Array<{ text: string; url: string }> {
  const regex = /\[(.+?)\]\((.+?)\)/g;
  const links = [];
  let match;

  while ((match = regex.exec(content)) !== null) {
    links.push({ text: match[1], url: match[2] });
  }

  return links;
}

/**
 * Resume un contenido Markdown a los primeros N caracteres
 */
export function summarizeContent(content: string, maxChars: number = 500): string {
  if (content.length <= maxChars) {
    return content;
  }

  const truncated = content.substring(0, maxChars);
  return truncated.substring(0, truncated.lastIndexOf(' ')) + '...';
}

/**
 * Limpia contenido Markdown para mostrar como texto plano
 */
export function cleanMarkdown(content: string): string {
  return (
    content
      // Remover encabezados
      .replace(/^#+\s+/gm, '')
      // Remover negritas
      .replace(/\*\*(.+?)\*\*/g, '$1')
      // Remover itálicas
      .replace(/\*(.+?)\*/g, '$1')
      // Remover enlaces pero mantener el texto
      .replace(/\[(.+?)\]\(.+?\)/g, '$1')
      // Remover listas
      .replace(/^[\s]*[-*+]\s+/gm, '')
      // Remover bloques de código
      .replace(/```[\s\S]*?```/g, '')
      // Remover líneas vacías múltiples
      .replace(/\n\n+/g, '\n')
      .trim()
  );
}

/**
 * Formatea un objeto como tabla Markdown
 */
export function formatAsTable(
  data: Array<Record<string, string>>,
  headers?: string[]
): string {
  if (data.length === 0) return '';

  const cols = headers || Object.keys(data[0]);
  const header = '| ' + cols.join(' | ') + ' |';
  const separator = '| ' + cols.map(() => '---').join(' | ') + ' |';
  const rows = data
    .map((row) => '| ' + cols.map((col) => row[col] || '').join(' | ') + ' |')
    .join('\n');

  return [header, separator, rows].join('\n');
}

/**
 * Formatea una lista como viñetas Markdown
 */
export function formatAsList(items: string[], level: number = 0): string {
  const indent = '  '.repeat(level);
  return items.map((item) => `${indent}- ${item}`).join('\n');
}

/**
 * Detecta si un contenido es válido
 */
export function isValidContent(content: string | undefined): content is string {
  return Boolean(content && content.length > 0);
}

/**
 * Cache local para Graphify en el navegador (localStorage)
 */
export const GraphifyCache = {
  /**
   * Guarda una sección de Graphify en caché
   */
  save(section: GraphifySectionKey, content: string, ttl: number = 3600000) {
    const expiry = Date.now() + ttl;
    localStorage.setItem(`graphify_${section}`, JSON.stringify({ content, expiry }));
  },

  /**
   * Obtiene una sección de caché si es válida
   */
  get(section: GraphifySectionKey): string | null {
    const cached = localStorage.getItem(`graphify_${section}`);
    if (!cached) return null;

    try {
      const { content, expiry } = JSON.parse(cached);
      if (Date.now() > expiry) {
        localStorage.removeItem(`graphify_${section}`);
        return null;
      }
      return content;
    } catch {
      return null;
    }
  },

  /**
   * Limpia todo el caché de Graphify
   */
  clear() {
    const keys = Object.keys(localStorage);
    keys.forEach((key) => {
      if (key.startsWith('graphify_')) {
        localStorage.removeItem(key);
      }
    });
  },
};
