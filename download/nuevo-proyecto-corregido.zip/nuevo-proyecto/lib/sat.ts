import axios from 'axios';
import { XMLParser } from 'fast-xml-parser';
import * as https from 'https';

export interface SATCredentials {
  rfc: string;
  password: string;
  certificatePath?: string;
  keyPath?: string;
}

export interface SolicitudDescarga {
  fechaInicial: string;
  fechaFinal: string;
  tipoSolicitud: 'emitidos' | 'recibidos';
}

export class SATService {
  private baseUrl = 'https://cfdidescargamasivasolicitud.clouda.sat.gob.mx';
  private baseUrlDownload = 'https://cfdidescargamasiva.clouda.sat.gob.mx';
  private credentials: SATCredentials;
  private token?: string;

  constructor(credentials: SATCredentials) {
    this.credentials = credentials;
  }

  async authenticate(): Promise<string> {
    try {
      console.log(`🔐 Autenticando RFC: ${this.credentials.rfc}`);

      const fecha = new Date().toISOString();
      
      const soapRequest = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <Autenticar xmlns="http://tempuri.org/">
      <autenticacion>
        <Rfc>${this.credentials.rfc}</Rfc>
        <Password>${this.credentials.password}</Password>
        <FechaSolicitud>${fecha}</FechaSolicitud>
      </autenticacion>
    </Autenticar>
  </soap:Body>
</soap:Envelope>`;

      const httpsAgent = new https.Agent({ rejectUnauthorized: false });

      const response = await axios.post(
        `${this.baseUrl}/servicios/AutenticacionService.svc`,
        soapRequest,
        {
          headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'SOAPAction': 'http://tempuri.org/IAutenticacionService/Autenticar',
          },
          httpsAgent,
        }
      );

      const parser = new XMLParser({ ignoreAttributes: false });
      const result = parser.parse(response.data);
      
      const token = result['s:Envelope']?.['s:Body']?.['AutenticarResponse']?.['AutenticarResult'];
      
      if (!token) {
        throw new Error('No se recibió token de autenticación');
      }

      this.token = token;
      console.log('✅ Autenticación exitosa');
      return token;
    } catch (error: any) {
      console.error('❌ Error autenticación:', error.response?.data || error.message);
      throw new Error(`Error autenticando: ${error.message}`);
    }
  }

  async solicitarDescarga(solicitud: SolicitudDescarga): Promise<string> {
    try {
      if (!this.token) {
        await this.authenticate();
      }

      console.log('📤 Solicitando descarga:', solicitud);

      const soapRequest = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SolicitaDescarga xmlns="http://tempuri.org/">
      <solicitud>
        <FechaInicial>${solicitud.fechaInicial}T00:00:00</FechaInicial>
        <FechaFinal>${solicitud.fechaFinal}T23:59:59</FechaFinal>
        <RfcEmisor>${this.credentials.rfc}</RfcEmisor>
        <TipoSolicitud>CFDI</TipoSolicitud>
        <RfcSolicitado>${this.credentials.rfc}</RfcSolicitado>
        <RelacionTerceros>${solicitud.tipoSolicitud === 'emitidos' ? 'R' : 'T'}</RelacionTerceros>
      </solicitud>
    </SolicitaDescarga>
  </soap:Body>
</soap:Envelope>`;

      const httpsAgent = new https.Agent({ rejectUnauthorized: false });

      const response = await axios.post(
        `${this.baseUrl}/servicios/SolicitaDescargaService.svc`,
        soapRequest,
        {
          headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'SOAPAction': 'http://tempuri.org/ISolicitaDescargaService/SolicitaDescarga',
          },
          httpsAgent,
        }
      );

      const parser = new XMLParser({ ignoreAttributes: false });
      const result = parser.parse(response.data);
      
      const solicitudId = result['s:Envelope']?.['s:Body']?.['SolicitaDescargaResponse']?.['SolicitaDescargaResult'];
      
      if (!solicitudId) {
        throw new Error('No se recibió ID de solicitud');
      }

      console.log(`✅ Solicitud creada: ${solicitudId}`);
      return solicitudId;
    } catch (error: any) {
      console.error('❌ Error solicitando descarga:', error.response?.data || error.message);
      throw new Error(`Error solicitando descarga: ${error.message}`);
    }
  }

  async verificarEstado(solicitudId: string): Promise<any> {
    try {
      if (!this.token) {
        await this.authenticate();
      }

      console.log(`🔍 Verificando estado: ${solicitudId}`);

      const soapRequest = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <VerificaEstado xmlns="http://tempuri.org/">
      <solicitud>${solicitudId}</solicitud>
    </VerificaEstado>
  </soap:Body>
</soap:Envelope>`;

      const httpsAgent = new https.Agent({ rejectUnauthorized: false });

      const response = await axios.post(
        `${this.baseUrl}/servicios/VerificaEstadoService.svc`,
        soapRequest,
        {
          headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'SOAPAction': 'http://tempuri.org/IVerificaEstadoService/VerificaEstado',
          },
          httpsAgent,
        }
      );

      const parser = new XMLParser({ ignoreAttributes: false });
      const result = parser.parse(response.data);
      
      const estadoData = result['s:Envelope']?.['s:Body']?.['VerificaEstadoResponse']?.['VerificaEstadoResult'];

      return {
        estado: estadoData?.Estado || 'error',
        codigoEstado: estadoData?.CodigoEstado || 0,
        mensaje: estadoData?.Mensaje || 'Sin respuesta',
        numeroCFDIs: estadoData?.NumeroCFDIs || 0,
        paquetes: estadoData?.Paquetes || [],
      };
    } catch (error: any) {
      console.error('❌ Error verificando estado:', error.response?.data || error.message);
      throw new Error(`Error verificando estado: ${error.message}`);
    }
  }

  async descargarPaquete(solicitudId: string, paqueteId: string): Promise<Buffer> {
    try {
      if (!this.token) {
        await this.authenticate();
      }

      console.log(` Descargando paquete: ${paqueteId}`);

      const soapRequest = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <PeticionDescarga xmlns="http://tempuri.org/">
      <solicitud>${solicitudId}</solicitud>
      <paquete>${paqueteId}</paquete>
    </PeticionDescarga>
  </soap:Body>
</soap:Envelope>`;

      const httpsAgent = new https.Agent({ rejectUnauthorized: false });

      const response = await axios.post(
        `${this.baseUrlDownload}/servicios/PeticionDescargaService.svc`,
        soapRequest,
        {
          headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'SOAPAction': 'http://tempuri.org/IPeticionDescargaService/PeticionDescarga',
          },
          httpsAgent,
          responseType: 'arraybuffer',
        }
      );

      return Buffer.from(response.data);
    } catch (error: any) {
      console.error('❌ Error descargando paquete:', error.response?.data || error.message);
      throw new Error(`Error descargando paquete: ${error.message}`);
    }
  }
}

export function createSATService(credentials: SATCredentials): SATService {
  return new SATService(credentials);
}