import { XMLParser } from 'fast-xml-parser';

export interface CFDIData {
  uuid: string;
  fecha: string;
  folio: string;
  serie?: string;
  subtotal: number;
  total: number;
  descuento: number;
  moneda: string;
  tipoComprobante: string;
  metodoPago: string;
  formaPago: string;
  lugarExpedicion: string;
  esNomina: boolean;
  emisor: {
    rfc: string;
    nombre: string;
    regimenFiscal: string;
  };
  receptor: {
    rfc: string;
    nombre: string;
    usoCFDI: string;
  };
  conceptos: Array<{
    claveProdServ: string;
    cantidad: number;
    claveUnidad: string;
    unidad: string;
    descripcion: string;
    valorUnitario: number;
    importe: number;
  }>;
  impuestos: {
    totalTrasladados: number;
    totalRetenidos: number;
  };
}

export function parseCFDIXML(xmlContent: string): CFDIData | null {
  try {
    if (!xmlContent || !xmlContent.includes('Comprobante')) {
      console.log('❌ XML no contiene Comprobante');
      return null;
    }

    // Parser configurado para manejar namespaces del SAT
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
      allowBooleanAttributes: true,
      parseAttributeValue: false,
      parseTagValue: false,
      trimValues: true,
      isArray: (name, jpath, isLeafNode, isAttribute) => {
        // Forzar arrays para elementos que pueden repetirse
        const arrayElements = [
          'cfdi:Concepto', 'Concepto',
          'cfdi:Traslado', 'Traslado',
          'cfdi:Retencion', 'Retencion',
          'nomina12:Percepcion', 'Percepcion',
          'nomina12:Deduccion', 'Deduccion',
        ];
        return arrayElements.some(el => name === el || name.endsWith(':' + el));
      },
    });

    const result = parser.parse(xmlContent);
    
    // Buscar el comprobante (puede tener namespace o no)
    const comprobante = result['cfdi:Comprobante'] || result['Comprobante'];
    
    if (!comprobante) {
      console.log('❌ No se encontró nodo Comprobante');
      return null;
    }

    // Función auxiliar para extraer atributos
    const getAttr = (obj: any, name: string): string => {
      if (!obj) return '';
      return obj[`@_${name}`] || '';
    };

    // Extraer datos del comprobante
    const fecha = getAttr(comprobante, 'Fecha');
    const folio = getAttr(comprobante, 'Folio');
    const serie = getAttr(comprobante, 'Serie');
    const subtotal = parseFloat(getAttr(comprobante, 'SubTotal')) || 0;
    const total = parseFloat(getAttr(comprobante, 'Total')) || 0;
    const descuento = parseFloat(getAttr(comprobante, 'Descuento')) || 0;
    const moneda = getAttr(comprobante, 'Moneda') || 'MXN';
    const tipoComprobante = getAttr(comprobante, 'TipoDeComprobante') || 'I';
    const metodoPago = getAttr(comprobante, 'MetodoPago') || 'PUE';
    const formaPago = getAttr(comprobante, 'FormaPago') || '01';
    const lugarExpedicion = getAttr(comprobante, 'LugarExpedicion') || '';

    // Extraer emisor
    const emisor = comprobante['cfdi:Emisor'] || comprobante['Emisor'] || {};
    const emisorData = {
      rfc: getAttr(emisor, 'Rfc'),
      nombre: getAttr(emisor, 'Nombre'),
      regimenFiscal: getAttr(emisor, 'RegimenFiscal'),
    };

    // Extraer receptor
    const receptor = comprobante['cfdi:Receptor'] || comprobante['Receptor'] || {};
    const receptorData = {
      rfc: getAttr(receptor, 'Rfc'),
      nombre: getAttr(receptor, 'Nombre'),
      usoCFDI: getAttr(receptor, 'UsoCFDI'),
    };

    // Extraer UUID del Timbre Fiscal Digital
    let uuid = '';
    const complemento = comprobante['cfdi:Complemento'] || comprobante['Complemento'];
    
    if (complemento) {
      // Buscar TimbreFiscalDigital (puede estar en diferentes formatos)
      const timbre = complemento['tfd:TimbreFiscalDigital'] || 
                     complemento['TimbreFiscalDigital'];
      
      if (timbre) {
        uuid = getAttr(timbre, 'UUID') || getAttr(timbre, 'uuid') || '';
      } else {
        // Buscar en cualquier nodo hijo
        for (const key in complemento) {
          const node = complemento[key];
          if (node && typeof node === 'object') {
            const tempUuid = getAttr(node, 'UUID') || getAttr(node, 'uuid');
            if (tempUuid && tempUuid.length === 36) {
              uuid = tempUuid;
              break;
            }
          }
        }
      }
    }

    // Extraer conceptos
    const conceptosData: any[] = [];
    const conceptosNode = comprobante['cfdi:Conceptos'] || comprobante['Conceptos'];
    
    if (conceptosNode) {
      let conceptos = conceptosNode['cfdi:Concepto'] || conceptosNode['Concepto'] || [];
      if (!Array.isArray(conceptos)) conceptos = [conceptos];
      
      for (const concepto of conceptos) {
        if (!concepto) continue;
        conceptosData.push({
          claveProdServ: getAttr(concepto, 'ClaveProdServ'),
          cantidad: parseFloat(getAttr(concepto, 'Cantidad')) || 0,
          claveUnidad: getAttr(concepto, 'ClaveUnidad'),
          unidad: getAttr(concepto, 'Unidad'),
          descripcion: getAttr(concepto, 'Descripcion'),
          valorUnitario: parseFloat(getAttr(concepto, 'ValorUnitario')) || 0,
          importe: parseFloat(getAttr(concepto, 'Importe')) || 0,
        });
      }
    }

    // Extraer impuestos
    const impuestosNode = comprobante['cfdi:Impuestos'] || comprobante['Impuestos'];
    const impuestosData = {
      totalTrasladados: parseFloat(getAttr(impuestosNode, 'TotalImpuestosTrasladados')) || 0,
      totalRetenidos: parseFloat(getAttr(impuestosNode, 'TotalImpuestosRetenidos')) || 0,
    };

    // Detectar si es nómina
    const esNomina = tipoComprobante === 'N' || 
                     !!(complemento && (complemento['nomina12:Nomina'] || complemento['Nomina']));

    return {
      uuid: uuid.toUpperCase(),
      fecha: fecha || new Date().toISOString(),
      folio: folio || 'S/F',
      serie,
      subtotal,
      total,
      descuento,
      moneda,
      tipoComprobante,
      metodoPago,
      formaPago,
      lugarExpedicion,
      esNomina,
      emisor: emisorData,
      receptor: receptorData,
      conceptos: conceptosData,
      impuestos: impuestosData,
    };
  } catch (error: any) {
    console.error('❌ Error parseando CFDI:', error.message);
    return null;
  }
}
export interface CFDIValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Valida que un CFDI ya parseado tenga los campos minimos exigidos por el SAT.
 * No verifica el sello fiscal ni la existencia en el SAT; solo valida integridad
 * estructural basica para evitar guardar XML invalidos en la base de datos.
 */
export function validateCFDI(cfdi: CFDIData | null): CFDIValidationResult {
  const errors: string[] = [];

  if (!cfdi) {
    return { valid: false, errors: ['CFDI nulo o no parseado'] };
  }

  // UUID obligatorio, formato canonico de 36 caracteres
  if (!cfdi.uuid || cfdi.uuid.length !== 36) {
    errors.push('UUID ausente o con formato invalido');
  }

  // Fecha obligatoria
  if (!cfdi.fecha) {
    errors.push('Fecha del comprobante ausente');
  }

  // Folio: permitimos 'S/F' como valor por defecto del parser, pero si viene
  // vacio lo marcamos como advertencia.
  if (!cfdi.folio) {
    errors.push('Folio ausente');
  }

  // Totales numericos y coherentes
  if (typeof cfdi.subtotal !== 'number' || isNaN(cfdi.subtotal) || cfdi.subtotal < 0) {
    errors.push('Subtotal invalido');
  }
  if (typeof cfdi.total !== 'number' || isNaN(cfdi.total) || cfdi.total < 0) {
    errors.push('Total invalido');
  }

  // Coherencia basica: total = subtotal - descuento + traslados - retenidos
  // Tolerancia de 1 centavo por redondeo
  const expectedTotal =
    cfdi.subtotal -
    (cfdi.descuento || 0) +
    (cfdi.impuestos?.totalTrasladados || 0) -
    (cfdi.impuestos?.totalRetenidos || 0);
  if (
    typeof cfdi.total === 'number' &&
    !isNaN(cfdi.total) &&
    Math.abs(cfdi.total - expectedTotal) > 0.01
  ) {
    errors.push(
      `Total no cuadra con subtotal+impuestos (esperado=${expectedTotal.toFixed(2)}, actual=${cfdi.total.toFixed(2)})`
    );
  }

  // Emisor
  if (!cfdi.emisor?.rfc || cfdi.emisor.rfc.length < 12 || cfdi.emisor.rfc.length > 13) {
    errors.push('RFC del emisor ausente o invalido');
  }
  if (!cfdi.emisor?.nombre) {
    errors.push('Nombre del emisor ausente');
  }

  // Receptor
  if (!cfdi.receptor?.rfc || cfdi.receptor.rfc.length < 12 || cfdi.receptor.rfc.length > 13) {
    errors.push('RFC del receptor ausente o invalido');
  }

  // Tipo de comprobante valido: I, E, T, N, P
  const tiposValidos = ['I', 'E', 'T', 'N', 'P'];
  if (!tiposValidos.includes(cfdi.tipoComprobante)) {
    errors.push(`Tipo de comprobante invalido: "${cfdi.tipoComprobante}"`);
  }

  // Conceptos: al menos uno (excepto nomina que no siempre los trae en cfdi:Conceptos)
  if (!cfdi.esNomina && (!cfdi.conceptos || cfdi.conceptos.length === 0)) {
    errors.push('El CFDI no tiene conceptos');
  }

  return { valid: errors.length === 0, errors };
}
