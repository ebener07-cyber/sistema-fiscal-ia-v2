/**
 * Cálculos de ISR (Impuesto Sobre la Renta)
 * México 2024-2026
 */

// Tarjetas actualizadas para 2024 (LISR Art. 96, 97, 177)
export const TARIFAS_MENSUAL_ISR = {
  // Límite inferior, Límite superior, Cuota fija, % sobre excedente
  rangos: [
    { limiteInferior: 0.01, limiteSuperior: 746.04, cuotaFija: 0, porcentaje: 1.92 },
    { limiteInferior: 746.05, limiteSuperior: 6332.07, cuotaFija: 14.32, porcentaje: 6.40 },
    { limiteInferior: 6332.08, limiteSuperior: 11128.01, cuotaFija: 371.30, porcentaje: 10.88 },
    { limiteInferior: 11128.02, limiteSuperior: 12993.99, cuotaFija: 892.63, porcentaje: 16.00 },
    { limiteInferior: 12994.00, limiteSuperior: 15470.29, cuotaFija: 1191.18, porcentaje: 17.92 },
    { limiteInferior: 15470.30, limiteSuperior: 18568.64, cuotaFija: 1634.66, porcentaje: 21.36 },
    { limiteInferior: 18568.65, limiteSuperior: 34698.84, cuotaFija: 2296.33, porcentaje: 23.52 },
    { limiteInferior: 34698.85, limiteSuperior: 45894.49, cuotaFija: 6089.42, porcentaje: 30.00 },
    { limiteInferior: 45894.50, limiteSuperior: 58388.87, cuotaFija: 9447.70, porcentaje: 32.00 },
    { limiteInferior: 58388.88, limiteSuperior: 185166.76, cuotaFija: 13428.16, porcentaje: 34.00 },
    { limiteInferior: 185166.77, limiteSuperior: Infinity, cuotaFija: 56511.32, porcentaje: 35.00 },
  ],
  // Subsidio para el empleo (art. 94)
  // Nota: El subsidio se aplica sobre el ingreso mensual
  subsidy: [
    { limiteInferior: 0.01, limiteSuperior: 1768.96, subsidyAmount: 407.02 },
    { limiteInferior: 1768.97, limiteSuperior: 2653.38, subsidyAmount: 406.83 },
    { limiteInferior: 2653.39, limiteSuperior: 3478.05, subsidyAmount: 406.62 },
    { limiteInferior: 3478.06, limiteSuperior: 3621.03, subsidyAmount: 392.79 },
    { limiteInferior: 3621.04, limiteSuperior: 4535.01, subsidyAmount: 382.46 },
    { limiteInferior: 4535.02, limiteSuperior: 5716.90, subsidyAmount: 354.23 },
    { limiteInferior: 5716.91, limiteSuperior: 7301.86, subsidyAmount: 324.87 },
    { limiteInferior: 7301.87, limiteSuperior: 9122.29, subsidyAmount: 294.63 },
    { limiteInferior: 9122.30, limiteSuperior: 11065.45, subsidyAmount: 253.00 },
    { limiteInferior: 11065.46, limiteSuperior: 12993.99, subsidyAmount: 217.81 },
    { limiteInferior: 12994.00, limiteSuperior: Infinity, subsidyAmount: 0 },
  ],
};

// Tarifa para personas morales (art. 14)
export const TARIFA_ANUAL_MORALES = {
  // Para el ejercicio 2024
  rangos: [
    { limiteInferior: 0.01, limiteSuperior: 238140.18, cuotaFija: 0, porcentaje: 1.0 },
    { limiteInferior: 238140.19, limiteSuperior: 2007709.64, cuotaFija: 2381.40, porcentaje: 1.5 },
    { limiteInferior: 2007709.65, limiteSuperior: 3331873.90, cuotaFija: 2880.55, porcentaje: 2.0 },
    { limiteInferior: 3331873.91, limiteSuperior: 6176886.59, cuotaFija: 5536.88, porcentaje: 2.5 },
    { limiteInferior: 6176886.60, limiteSuperior: 11174603.67, cuotaFija: 12641.16, porcentaje: 3.0 },
    { limiteInferior: 11174603.68, limiteSuperior: Infinity, cuotaFija: 27647.27, porcentaje: 3.5 },
  ],
};

// Tarifa para personas físicas (art. 152)
export const TARIFA_ANUAL_FISICAS = {
  rangos: [
    { limiteInferior: 0.01, limiteSuperior: 8952.49, cuotaFija: 0, porcentaje: 1.92 },
    { limiteInferior: 8952.50, limiteSuperior: 75984.84, cuotaFija: 171.89, porcentaje: 6.40 },
    { limiteInferior: 75984.85, limiteSuperior: 133536.12, cuotaFija: 4455.96, porcentaje: 10.88 },
    { limiteInferior: 133536.13, limiteSuperior: 155927.88, cuotaFija: 10712.16, porcentaje: 16.00 },
    { limiteInferior: 155927.89, limiteSuperior: 185643.48, cuotaFija: 14292.80, porcentaje: 17.92 },
    { limiteInferior: 185643.49, limiteSuperior: 222823.68, cuotaFija: 19611.92, porcentaje: 21.36 },
    { limiteInferior: 222823.69, limiteSuperior: 416386.08, cuotaFija: 27544.64, porcentaje: 23.52 },
    { limiteInferior: 416386.09, limiteSuperior: 550733.88, cuotaFija: 73081.04, porcentaje: 30.00 },
    { limiteInferior: 550733.89, limiteSuperior: 700665.44, cuotaFija: 113386.56, porcentaje: 32.00 },
    { limiteInferior: 700665.45, limiteSuperior: 2222000.12, cuotaFija: 161203.68, porcentaje: 34.00 },
    { limiteInferior: 2222000.13, limiteSuperior: Infinity, cuotaFija: 678124.80, porcentaje: 35.00 },
  ],
};

export interface ISRResult {
  baseGravable: number;
  impuestoMarginal: number;
  cuotaFija: number;
  impuestoTotal: number;
  subsidy?: number;
  impuestoNeto: number;
  tasaEfectiva: number;
  rango: {
    limiteInferior: number;
    limiteSuperior: number;
    porcentaje: number;
  };
}

export interface ISROptions {
  tipoPersona: 'fisica' | 'moral';
  periodicidad: 'semanal' | 'quincenal' | 'mensual' | 'anual';
  ingreso: number;
  deducciones?: number;
  tipoCalculo?: 'nomina' | 'honorarios' | 'arrendamiento' | 'actividad';
}

/**
 * Calcula ISR para nómina (personas físicas)
 */
export function calcularISRNomina(
  ingresoMensual: number,
  deducciones: number = 0
): ISRResult {
  // Aplicar deducciones personales (art. 151 LISR)
  const baseGravable = Math.max(0, ingresoMensual - deducciones);

  // Buscar rango correspondiente
  const rango = TARIFAS_MENSUAL_ISR.rangos.find(
    (r) => baseGravable >= r.limiteInferior && baseGravable <= r.limiteSuperior
  );

  if (!rango) {
    throw new Error('Ingreso fuera de rango válido');
  }

  // Calcular impuesto marginal
  const excedente = baseGravable - rango.limiteInferior;
  const impuestoMarginal = excedente * (rango.porcentaje / 100);
  const cuotaFija = rango.cuotaFija;
  const impuestoTotal = impuestoMarginal + cuotaFija;

  // Buscar subsidy (subsidio para el empleo)
  const subsidyEntry = TARIFAS_MENSUAL_ISR.subsidy.find(
    (s) => baseGravable >= s.limiteInferior && baseGravable <= s.limiteSuperior
  );
  const subsidy = subsidyEntry?.subsidyAmount || 0;

  // El subsidy se resta del impuesto (si aplica)
  const impuestoNeto = Math.max(0, impuestoTotal - subsidy);
  const tasaEfectiva = baseGravable > 0 ? (impuestoNeto / baseGravable) * 100 : 0;

  return {
    baseGravable,
    impuestoMarginal,
    cuotaFija,
    impuestoTotal,
    subsidy,
    impuestoNeto,
    tasaEfectiva,
    rango: {
      limiteInferior: rango.limiteInferior,
      limiteSuperior: rango.limiteSuperior,
      porcentaje: rango.porcentaje,
    },
  };
}

/**
 * Calcula ISR para personas morales
 */
export function calcularISRPersonaMoral(ingresoAcumulable: number, deduccionesAutorizadas: number): ISRResult {
  const baseGravable = Math.max(0, ingresoAcumulable - deduccionesAutorizadas);

  const rango = TARIFA_ANUAL_MORALES.rangos.find(
    (r) => baseGravable >= r.limiteInferior && baseGravable <= r.limiteSuperior
  );

  if (!rango) {
    throw new Error('Base gravable fuera de rango');
  }

  const excedente = baseGravable - rango.limiteInferior;
  const impuestoMarginal = excedente * (rango.porcentaje / 100);
  const cuotaFija = rango.cuotaFija;
  const impuestoTotal = impuestoMarginal + cuotaFija;
  const tasaEfectiva = baseGravable > 0 ? (impuestoTotal / baseGravable) * 100 : 0;

  return {
    baseGravable,
    impuestoMarginal,
    cuotaFija,
    impuestoTotal,
    impuestoNeto: impuestoTotal,
    tasaEfectiva,
    rango: {
      limiteInferior: rango.limiteInferior,
      limiteSuperior: rango.limiteSuperior,
      porcentaje: rango.porcentaje,
    },
  };
}

/**
 * Calcula ISR para personas físicas (distintos tipos)
 */
export function calcularISRPersonaFisica(
  ingresoAnual: number,
  tipo: ISROptions['tipoCalculo'] = 'nomina'
): ISRResult {
  const baseGravable = Math.max(0, ingresoAnual);

  const rango = TARIFA_ANUAL_FISICAS.rangos.find(
    (r) => baseGravable >= r.limiteInferior && baseGravable <= r.limiteSuperior
  );

  if (!rango) {
    throw new Error('Ingreso anual fuera de rango');
  }

  const excedente = baseGravable - rango.limiteInferior;
  const impuestoMarginal = excedente * (rango.porcentaje / 100);
  const cuotaFija = rango.cuotaFija;
  const impuestoTotal = impuestoMarginal + cuotaFija;
  const tasaEfectiva = baseGravable > 0 ? (impuestoTotal / baseGravable) * 100 : 0;

  return {
    baseGravable,
    impuestoMarginal,
    cuotaFija,
    impuestoTotal,
    impuestoNeto: impuestoTotal,
    tasaEfectiva,
    rango: {
      limiteInferior: rango.limiteInferior,
      limiteSuperior: rango.limiteSuperior,
      porcentaje: rango.porcentaje,
    },
  };
}

/**
 * Convierte ingreso de una periodicidad a mensual
 */
export function periodicidadAMensual(ingreso: number, periodicidad: ISROptions['periodicidad']): number {
  const factores: Record<string, number> = {
    semanal: 4.33,
    quincenal: 2,
    mensual: 1,
    anual: 1 / 12,
  };
  return ingreso * (factores[periodicidad] || 1);
}

/**
 * Calcula ISR con conversión de periodicidad
 */
export function calcularISR(options: ISROptions): ISRResult {
  const ingresoMensual = periodicidadAMensual(options.ingreso, options.periodicidad);

  if (options.tipoPersona === 'moral') {
    return calcularISRPersonaMoral(options.ingreso, options.deducciones || 0);
  }

  // Para personas físicas en nómina
  if (options.tipoCalculo === 'nomina') {
    return calcularISRNomina(ingresoMensual, options.deducciones || 0);
  }

  // Para otros tipos de personas físicas
  return calcularISRPersonaFisica(options.ingreso, options.tipoCalculo);
}

/**
 * Calcula retención de ISR sobre honorarios (art. 106 LISR)
 * Tasa fija del 10/11 sobre el monto total
 */
export function calcularRetencionHonorarios(montoBruto: number): {
  retencion: number;
  montoNeto: number;
} {
  const retencion = montoBruto * 0.10; // 10% sobre el total
  return {
    retencion: Math.round(retencion * 100) / 100,
    montoNeto: Math.round((montoBruto - retencion) * 100) / 100,
  };
}

/**
 * Calcula retención de ISR sobre arrendamiento (art. 108 LISR)
 * Tasa del 10% sobre el monto total
 */
export function calcularRetencionArrendamiento(montoBruto: number): {
  retencion: number;
  montoNeto: number;
} {
  const retencion = montoBruto * 0.10;
  return {
    retencion: Math.round(retencion * 100) / 100,
    montoNeto: Math.round((montoBruto - retencion) * 100) / 100,
  };
}