import * as forge from 'node-forge';
import * as crypto from 'crypto';
import * as fs from 'fs';

/**
 * Cargar certificado .cer
 */
export function loadCertificate(certPath: string): string {
  const certPem = fs.readFileSync(certPath, 'utf8');
  return certPem;
}

/**
 * Cargar llave privada .key
 */
export function loadPrivateKey(keyPath: string): string {
  const keyPem = fs.readFileSync(keyPath, 'utf8');
  return keyPem;
}

/**
 * Genera un sello digital SHA-256 para un CFDI usando la llave privada del SAT.
 *
 * Nota: Las llaves .key del SAT son DER PKCS#8 encriptadas con password.
 * Aquí usamos forge para desencriptar y convertir a PEM, y luego Node crypto
 * para firmar (forge no expone signing con la API que necesitamos).
 */
export function generateSello(
  xmlContent: string,
  privateKeyPath: string,
  password: string
): string {
  const keyBuffer = fs.readFileSync(privateKeyPath);

  // Intentar como PEM (texto) primero; si falla, asumir DER binario.
  let forgePrivateKey: forge.pki.PrivateKey | null = null;
  try {
    const keyPem = keyBuffer.toString('utf8');
    // Primero intentar desencriptar con password (formato PKCS#8 encriptado)
    forgePrivateKey = forge.pki.decryptRsaPrivateKey(keyPem, password);
    if (!forgePrivateKey) {
      // Si no estaba encriptada, parsear directamente
      forgePrivateKey = forge.pki.privateKeyFromPem(keyPem);
    }
  } catch {
    // Era DER binario: convertir a PEM DER y desencriptar
    const derBase64 = keyBuffer.toString('base64');
    const pemFromDer = `-----BEGIN ENCRYPTED PRIVATE KEY-----\n${derBase64}\n-----END ENCRYPTED PRIVATE KEY-----`;
    forgePrivateKey = forge.pki.decryptRsaPrivateKey(pemFromDer, password);
  }

  if (!forgePrivateKey) {
    throw new Error('No se pudo cargar/descifrar la llave privada del SAT');
  }

  const pemDecrypted = forge.pki.privateKeyToPem(forgePrivateKey);

  const signer = crypto.createSign('SHA256');
  signer.update(xmlContent, 'utf8');
  signer.end();

  const signature = signer.sign(pemDecrypted, 'base64');
  return signature;
}

/**
 * Obtener número de serie del certificado
 */
export function getCertSerialNumber(certPath: string): string {
  const certPem = fs.readFileSync(certPath, 'utf8');
  const cert = forge.pki.certificateFromPem(certPem);
  const serial = cert.serialNumber;
  return serial.toUpperCase();
}

/**
 * Convertir certificado a base64
 */
export function certToBase64(certPath: string): string {
  const certPem = fs.readFileSync(certPath, 'utf8');
  const cert = forge.pki.certificateFromPem(certPem);
  const der = forge.asn1.toDer(forge.pki.certificateToAsn1(cert)).getBytes();
  return Buffer.from(der, 'binary').toString('base64');
}
