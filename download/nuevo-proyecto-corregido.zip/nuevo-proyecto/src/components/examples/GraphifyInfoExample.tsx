'use client';

/**
 * Componente de Ejemplo: Información del Sistema
 * Muestra cómo usar Graphify en un componente
 */

import { useGraphify, useGraphifySection } from '@/src/providers/GraphifyProvider';
import { cleanMarkdown, summarizeContent } from '@/lib/graphify-utils';

export function GraphifyInfoExample() {
  // Opción 1: Obtener todo el contexto
  const { graphify, isLoading } = useGraphify();

  // Opción 2: Obtener solo una sección específica
  const { content: entidadesContent } = useGraphifySection('entidades');

  if (isLoading) {
    return (
      <div className="p-4 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-700">⏳ Cargando contexto del sistema...</p>
      </div>
    );
  }

  if (!graphify || !entidadesContent) {
    return (
      <div className="p-4 bg-yellow-50 rounded-lg">
        <p className="text-sm text-yellow-700">⚠️ No se pudo cargar el contexto del sistema</p>
      </div>
    );
  }

  // Procesar el contenido
  const cleanedContent = cleanMarkdown(entidadesContent);
  const summary = summarizeContent(cleanedContent, 300);

  return (
    <div className="space-y-6">
      {/* Sección 1: Contexto del Sistema */}
      <div className="border rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-2">📋 Contexto del Sistema</h3>
        <p className="text-gray-700 text-sm">
          {summarizeContent(graphify.contexto, 200)}
        </p>
      </div>

      {/* Sección 2: Entidades */}
      <div className="border rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-2">📊 Entidades Disponibles</h3>
        <pre className="bg-gray-50 p-4 rounded text-xs overflow-auto max-h-64">
          {summary}
        </pre>
      </div>

      {/* Sección 3: Rutas Disponibles */}
      {graphify.rutas && (
        <div className="border rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2">🛣️ Rutas API</h3>
          <div className="bg-gray-50 p-4 rounded text-sm">
            <p className="text-gray-700 whitespace-pre-wrap">
              {summarizeContent(cleanMarkdown(graphify.rutas), 300)}
            </p>
          </div>
        </div>
      )}

      {/* Sección 4: Componentes */}
      {graphify.componentes && (
        <div className="border rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2">🧩 Componentes</h3>
          <div className="bg-gray-50 p-4 rounded text-sm">
            <p className="text-gray-700 whitespace-pre-wrap">
              {summarizeContent(cleanMarkdown(graphify.componentes), 300)}
            </p>
          </div>
        </div>
      )}

      {/* Información de Debug */}
      <div className="border-t pt-4 text-xs text-gray-500">
        <p>✓ Graphify cargado exitosamente ({Object.keys(graphify || {}).length} secciones)</p>
        <p>✓ Total caracteres: {Object.values(graphify || {}).reduce((sum, val) => sum + (typeof val === 'string' ? val.length : 0), 0).toLocaleString()}</p>
      </div>
    </div>
  );
}

export default GraphifyInfoExample;
