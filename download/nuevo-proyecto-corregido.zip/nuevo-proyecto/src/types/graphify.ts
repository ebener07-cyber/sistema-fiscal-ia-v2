/**
 * Tipos para Graphify - Memoria Técnica del Sistema
 */

export interface GraphifyContext {
  contexto: string;
  entidades: string;
  relaciones: string;
  componentes: string;
  rutas: string;
  mapaDelSistema: string;
  sesiones?: string;
  dependencias?: string;
}

export type GraphifySectionKey = keyof GraphifyContext;

export interface GraphifyResponse extends GraphifyContext {
  isLoading: boolean;
  error: string | null;
}

/**
 * Información de una entidad del sistema
 */
export interface EntityInfo {
  nombre: string;
  descripcion: string;
  campos: Record<string, string>;
  relaciones: string[];
}

/**
 * Información de una ruta API
 */
export interface RouteInfo {
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  descripcion: string;
  autenticacion: boolean;
  parámetros?: Record<string, string>;
}

/**
 * Información del componente
 */
export interface ComponentInfo {
  nombre: string;
  ruta: string;
  props: Record<string, string>;
  descripcion: string;
}
