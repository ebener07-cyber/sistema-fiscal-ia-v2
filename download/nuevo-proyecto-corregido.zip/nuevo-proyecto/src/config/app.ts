/**
 * Configuración centralizada de la aplicación
 */

export const APP_CONFIG = {
  // Nombre y versión
  name: 'Asesor Fiscal IA',
  version: '1.0.0',
  description: 'Sistema integral de asesoramiento fiscal con IA para México',

  // URLs y rutas
  routes: {
    dashboard: '/dashboard',
    chat: '/ia-fiscal',
    empresas: '/empresas',
    clientes: '/clientes',
    facturas: '/facturacion',
    sat: '/sat',
  },

  // API endpoints
  api: {
    chat: '/api/ia-fiscal/chat',
    hello: '/api/hello',
  },

  // Configuración de IA
  ai: {
    model: 'llama-3.3-70b-versatile',
    temperature: 0.7,
    maxTokens: 1000,
  },

  // Modelos de impuestos
  taxes: {
    iva: 0.16, // 16%
    iva_reduced: 0.0, // Alimentos, medicinas
  },

  // Períodos fiscales
  fiscal: {
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
  },

  // UI/UX
  ui: {
    sidebarCollapsible: true,
    theme: 'light',
    language: 'es',
  },

  // Timeout en ms
  timeouts: {
    apiRequest: 30000,
    chatResponse: 60000,
  },
} as const;

export type AppConfig = typeof APP_CONFIG;
