/**
 * Validación de variables de ambiente
 * Asegura que todas las variables necesarias están configuradas
 */

type Env = {
  GROQ_API_KEY: string;
  DATABASE_URL: string;
  NODE_ENV: 'development' | 'production' | 'test';
};

function validateEnv(): Env {
  const requiredVars = ['GROQ_API_KEY', 'DATABASE_URL'] as const;
  const missingVars: string[] = [];

  for (const varName of requiredVars) {
    if (!process.env[varName]) {
      missingVars.push(varName);
    }
  }

  if (missingVars.length > 0) {
    console.warn(
      `⚠️ Variables de ambiente faltantes: ${missingVars.join(', ')}\n` +
      `Asegúrate de que estén en .env.local`
    );
  }

  return {
    GROQ_API_KEY: process.env.GROQ_API_KEY || '',
    DATABASE_URL: process.env.DATABASE_URL || '',
    NODE_ENV: (process.env.NODE_ENV as Env['NODE_ENV']) || 'development',
  };
}

const env = validateEnv();

export default env;
