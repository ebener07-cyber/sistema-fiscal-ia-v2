export type ExtractedXML = { name: string; content: Buffer };

/**
 * Extrae todos los archivos .xml de un Buffer ZIP en memoria.
 *
 * Usa `entry.getData()` (que retorna el Buffer binario crudo) en lugar de
 * `readAsText()` para evitar la doble conversión texto → Buffer que rompía
 * los acentos y caracteres especiales de los CFDI (Percepción, Deducción,
 * Año, etc.).
 */
export async function extractXMLsFromZIP(
  zipBuffer: Buffer
): Promise<ExtractedXML[]> {
  const AdmZip = (await import('adm-zip')).default;
  const zip = new AdmZip(zipBuffer);

  const entries = zip.getEntries();
  const xmls: ExtractedXML[] = [];

  for (const entry of entries) {
    if (entry.isDirectory) continue;
    const fileName = (entry.entryName || entry.name || '').toString();
    if (!fileName.toLowerCase().endsWith('.xml')) continue;

    // Buffer crudo del archivo. Cuando el caller haga .toString('utf8')
    // se respetan los caracteres especiales del XML del SAT.
    const content = entry.getData();
    xmls.push({ name: fileName, content });
  }

  return xmls;
}
