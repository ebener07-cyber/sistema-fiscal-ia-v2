'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';

interface GraphifyContext {
  contexto: string;
  entidades: string;
  relaciones: string;
  componentes: string;
  rutas: string;
  mapaDelSistema: string;
  sesiones: string;
  dependencias: string;
  isLoading: boolean;
  error: string | null;
}

interface GraphifyContextType {
  graphify: GraphifyContext | null;
  isLoading: boolean;
  getSection: (section: keyof Omit<GraphifyContext, 'isLoading' | 'error'>) => string;
}

const GraphifyCtx = createContext<GraphifyContextType | undefined>(undefined);

/**
 * Proveedor de Graphify - Carga la memoria técnica en toda la app
 */
export function GraphifyProvider({ children }: { children: React.ReactNode }) {
  const [graphify, setGraphify] = useState<GraphifyContext | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadGraphify() {
      try {
        setIsLoading(true);
        const response = await fetch('/api/graphify');
        if (!response.ok) {
          throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();
        setGraphify(data);
      } catch (error) {
        console.error('Error cargando Graphify:', error);
        // No fallar la app si Graphify no carga, usar defaults
        setGraphify({
          contexto: '',
          entidades: '',
          relaciones: '',
          componentes: '',
          rutas: '',
          mapaDelSistema: '',
          sesiones: '',
          dependencias: '',
          isLoading: false,
          error: error instanceof Error ? error.message : 'Error desconocido',
        });
      } finally {
        setIsLoading(false);
      }
    }

    loadGraphify();
  }, []);

  const getSection = (section: keyof Omit<GraphifyContext, 'isLoading' | 'error'>) => {
    return graphify?.[section] || '';
  };

  const value: GraphifyContextType = {
    graphify,
    isLoading,
    getSection,
  };

  return <GraphifyCtx.Provider value={value}>{children}</GraphifyCtx.Provider>;
}

/**
 * Hook para acceder a Graphify desde cualquier componente
 */
export function useGraphify() {
  const context = useContext(GraphifyCtx);
  if (!context) {
    throw new Error('useGraphify debe ser usado dentro de GraphifyProvider');
  }
  return context;
}

/**
 * Hook para obtener una sección específica de Graphify
 */
export function useGraphifySection(section: keyof Omit<GraphifyContext, 'isLoading' | 'error'>) {
  const { getSection, isLoading } = useGraphify();
  return { content: getSection(section), isLoading };
}
