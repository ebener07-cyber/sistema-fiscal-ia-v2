# Plan de corrección (siguiente iteración)

## Situación actual
El proyecto compila parcialmente pero sigue fallando en `app/api/descarga-sat/procesar/route.ts` por desalineación entre la interfaz real `CFDIData` (en `lib/cfdi-parser.ts`) y las propiedades usadas por el route (ej. `complemento`, `totalImpuestosTrasladados`, `tipoDeComprobante`, `objetoImp`, etc.).

## Decisión necesaria
Alinear implementación en una de dos rutas:

### Opción A (modificar parser / tipos)
- Ampliar `lib/cfdi-parser.ts` (y su `CFDIData`) para incluir:
  - `complemento.timbreFiscalDigital.uuid`
  - `impuestos.totalImpuestosTrasladados`
  - alias/propiedades compatibles con el route
  - `conceptos[].noIdentificacion` y `conceptos[].objetoImp`
- Ventaja: el route actual queda funcional con cambios mínimos.
- Desventaja: aumenta complejidad del parser y riesgo de afectar otras rutas.

### Opción B (modificar route)
- Cambiar `app/api/descarga-sat/procesar/route.ts` para usar exclusivamente propiedades existentes en `CFDIData`:
  - `cfdi.uuid` (ya existe)
  - `cfdi.impuestos.totalTrasladados` (ya existe)
  - `cfdi.tipoComprobante` (ya existe)
  - `cfdi.conceptos[].claveProdServ/cantidad/claveUnidad/unidad/descripcion/valorUnitario/importe`
  - No asumir `noIdentificacion` ni `objetoImp` (mapear a valores default/prisma-required)
- Ventaja: menor impacto en el parser.
- Desventaja: requiere revisar otras incompatibilidades con Prisma (relación `empresa`).

## Siguiente paso propuesto (recomendado)
Ejecutar **Opción B**:
- Completar la corrección de `procesar/route.ts` hasta eliminar:
  - accesos a `cfdi.complemento.*`
  - accesos a `impuestos.totalImpuestosTrasladados`
  - accesos a `cfdi.tipoDeComprobante`
  - mapeos a `conceptos[].noIdentificacion` y `conceptos[].objetoImp`
- Ajustar `prisma.factura.create` para incluir `empresaId` + relación según Prisma (si `empresa` es required, usar `empresa: { connect: { id: ... } }`).

## Validación
1. `npx next build --no-lint`
2. `npx eslint -c eslint.config.mjs . --max-warnings=0`


