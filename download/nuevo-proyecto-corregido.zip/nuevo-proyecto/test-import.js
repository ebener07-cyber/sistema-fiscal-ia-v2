async function test() {
  const empresaId = 'cmqimtha10000cids4d04e5ee'; // ELECTRONICMA
  
  console.log('Importando CFDIs de nómina...');
  const res = await fetch(`http://localhost:3000/api/nomina/importar?empresaId=${empresaId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  });
  console.log('Status:', res.status);
  console.log('Content-Type:', res.headers.get('content-type'));
  const text = await res.text();
  console.log('Response:', text.substring(0, 2000));
}

test().catch(console.error);