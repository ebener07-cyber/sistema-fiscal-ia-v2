# Validaciones SAT

Reglas de validación para CFDI mexicano.

## Tipos de Validación
- UUID único
- Schema XSD 4.0
- Timbre fiscal

## Relacionado
- [[arquitectura-cfdi]]
- [[parse-cfdi-xml]]