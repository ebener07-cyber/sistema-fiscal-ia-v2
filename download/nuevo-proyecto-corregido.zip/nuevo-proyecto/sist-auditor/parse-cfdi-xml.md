```markdown
# parseCFDIXML

Validación de XMLs CFDI contra schema SAT.

## Funciones
- Validar UUID
- Validar schema XSD
- Detectar tipo de comprobante

## Relacionado
- [[arquitectura-cfdi]]
- [[validaciones-sat]]