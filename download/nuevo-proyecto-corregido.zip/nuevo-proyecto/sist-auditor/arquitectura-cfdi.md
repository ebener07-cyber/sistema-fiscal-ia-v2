# Arquitectura del Sistema CFDI

## Descripción
Sistema de procesamiento de XMLs CFDI para facturación mexicana (SAT).

## Componentes Principales

### 1. Route Handler (app/api/procesar-xmls/route.ts)
- **Función:** Endpoint principal que recibe archivos ZIP
- **Responsabilidades:**
  - Extraer archivos del ZIP
  - Validar XMLs CFDI
  - Manejar duplicados
  - Retornar respuesta JSON

### 2. AdmZip (Extracción ZIP)
- **Función:** Extrae archivos XML del ZIP subido
- **Ubicación:** Dependencia externa

### 3. parseCFDIXML (Validación CFDI)
- **Función:** Valida XMLs contra schema SAT
- **Validaciones:**
  - UUID duplicados
  - Schema XSD
  - Tipos de comprobante

### 4. Prisma (Conexión BD)
- **Función:** ORM para base de datos
- **Tablas:**
  - Facturas
  - Conceptos
  - Validaciones

## Componentes Relacionados

- [[parse-cfdi-xml]] - Validación de XMLs
- [[validaciones-sat]] - Reglas del SAT
- [[prisma-schema]] - Modelos de BD

## Diagrama de Arquitectura

```mermaid
graph TD
    A[Route - App/API/Procesar-xmls] --> B[AdmZip - Extracción ZIP]
    A --> C[parseCFDIXML - Validación CFDI]
    C --> D[prisma - Conexión BD]
    B --> E[Archivos XML individuales]
    D --> F[Registro en Base de Datos - Facturas/Conceptos]
    A --> G[Manejo de duplicados en BD]
    A --> H[Respuesta JSON final al cliente]