# Prisma Schema

Modelos de base de datos para CFDI.

## Modelos
- Factura
- Concepto
- Validacion

## Relacionado
- [[arquitectura-cfdi]]