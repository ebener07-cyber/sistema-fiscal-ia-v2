# Next.js & React Prompts - Guía de Patrones

## Estructura de Componentes

Cuando generes componentes React:
```
- Usar TypeScript (interfaces/types)
- Props tipados
- Usar hooks (useState, useEffect, useCallback)
- Estilos con Tailwind CSS
- Exportar como named export
```

## Patrones de Rutas

```
/dashboard - Panel principal
/ia-fiscal - Chat con IA
/empresas - Gestión de empresas
/clientes - Gestión de clientes
/facturas - CFDI y facturas
/api/ia-fiscal/chat - Endpoint de chat
```

## Patrones de API Routes

```typescript
// POST /api/ia-fiscal/chat
- Input: { message: string }
- Output: { reply: string }
- Enriquece con contexto de Graphify automáticamente
```

## Estado Global (Context/Store)

```
Considera usar Context para:
- Empresa seleccionada actual
- Usuario autenticado
- Alertas globales
- Tema (light/dark)
```

## Integración con Graphify

El sistema carga automáticamente:
1. Contexto técnico en prompts de IA
2. Información de entidades en componentes
3. Rutas disponibles en navegación
