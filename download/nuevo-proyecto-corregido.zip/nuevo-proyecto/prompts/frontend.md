# Frontend Prompts - Instrucciones de UI/UX

## Mensajes de Validación

### Error de Validación
```
Cuando un campo falle validación:
- Mostrar mensaje en rojo bajo el campo
- Explicar qué está mal: "RFC debe tener formato XXXXXX######XXX"
- Sugerir corrección
```

### Confirmación de Acción
```
Para acciones críticas (eliminar, cambiar régimen):
- Mostrar modal con confirmación
- Resaltar los datos que se van a cambiar
- Dar opción de "Cancelar" y "Confirmar"
```

## Mensajes de Error

### Error de Conexión
```
"No se pudo conectar al servidor. Verifica tu conexión a internet.
Reintentando en 5 segundos..."
```

### Error de IA
```
"La IA fiscal no pudo procesар tu solicitud. 
Intenta reformular la pregunta o intenta más tarde."
```

## Mensajes de Éxito

### Datos Guardados
```
"✓ Cambios guardados exitosamente"
Mostrar durante 3 segundos y desaparecer
```

## Prompts para Componentes

### Tabla de Clientes
```
Mostrar:
- RFC, Nombre, Régimen fiscal
- Últimas obligaciones vencidas (en rojo si hay)
- Última actualización
- Botones: Ver, Editar, Alertas
```

### Dashboard Fiscal
```
Mostrar alertas prominentes:
1. Pagos vencidos
2. Declaraciones sin presentar
3. CFDI con inconsistencias
4. Cambios de régimen pendientes
```
