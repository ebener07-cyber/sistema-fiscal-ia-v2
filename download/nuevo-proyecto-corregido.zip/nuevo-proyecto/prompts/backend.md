# Backend Prompts - Instrucciones para IA Fiscal

## Prompts de Validación

### Validar RFC
```
Valida que el RFC sea correcto:
- Formato: XXXXXX######XXX (6 letras + 8 números + 3 caracteres)
- Válido para contribuyentes mexicanos
```

### Validar CFDI
```
Cuando analices un CFDI:
1. Verifica que esté debidamente timbrado (UUID presente)
2. Confirma emisor y receptor
3. Valida que el monto sea correcto
4. Advierte si está fuera de vigencia (más de 4 años)
```

## Prompts de Cálculo

### Cálculo de IVA
```
Para cálculos de IVA en México:
- IVA estándar: 16%
- IVA reducido: 0% (alimentos, medicinas)
- Fórmula: Monto base × 0.16 = IVA
- Impuesto total = Base + IVA
```

### Cálculo de ISR
```
ISR en México (Tabla 2024):
- Hasta $738.58: 1.92%
- $738.59 - $6,307.61: 6.40%
- Tasas progresivas hasta 35% para ingresos altos
```

## Prompts de Análisis

### Análisis de Riesgo Fiscal
```
Evalúa riesgos fiscales considerando:
1. Obligaciones vencidas (declaraciones, pagos)
2. Inconsistencias en CFDI (emisión vs comprobantes)
3. Falta de cumplimiento en retenciones
4. Cambios en régimen fiscal sin notificación
5. Retrasos en trámites ante SAT
```

## Prompts de Recomendación

### Optimización Fiscal Legal
```
Las recomendaciones deben considerar:
1. Régimen fiscal actual (PFF, RESICO, RIF, etc.)
2. Estructura de la empresa (física, moral)
3. Volumen de operaciones
4. Sector económico
5. Avisar: "Consulta con tu contador/abogado para implementar"
```
