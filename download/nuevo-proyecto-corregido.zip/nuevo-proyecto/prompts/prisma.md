# Prisma Prompts - Esquema y Operaciones BD

## Entidades Principales

### Empresa
```prisma
- id: String (UUID)
- rfc: String (unique)
- nombre: String
- regimen: String (PFF, RESICO, etc.)
- estatus: String (activa, inactiva)
- createdAt: DateTime
- updatedAt: DateTime
```

### Cliente
```prisma
- id: String (UUID)
- empresaId: String (FK)
- rfc: String
- nombre: String
- email: String
- obligacionesFiscales: AlertaFiscal[]
```

### Factura (CFDI)
```prisma
- id: String (UUID)
- empresaId: String (FK)
- uuid: String (UUID de timbrado)
- monto: Decimal
- estatus: String (timbrada, cancelada)
- fechaEmision: DateTime
```

### AlertaFiscal
```prisma
- id: String (UUID)
- empresaId: String (FK)
- tipo: String (vencimiento, inconsistencia)
- descripcion: String
- prioridad: String (baja, media, alta)
- resuelta: Boolean
```

## Operaciones Comunes

### Obtener alertas activas de empresa
```typescript
const alertas = await prisma.alertaFiscal.findMany({
  where: {
    empresaId,
    resuelta: false
  },
  orderBy: { createdAt: 'desc' }
});
```

### Crear nueva empresa
```typescript
const empresa = await prisma.empresa.create({
  data: {
    rfc,
    nombre,
    regimen: 'PFF', // Default
    estatus: 'activa'
  }
});
```

## Consideraciones

- Validar RFC antes de crear empresa
- Usar transacciones para múltiples operaciones
- Implementar soft deletes (campo estatus)
- Audit trail para cambios de régimen fiscal
