const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function clean() {
  console.log('Limpiando base de datos...');
  await prisma.concepto.deleteMany();
  await prisma.impuesto.deleteMany();
  await prisma.factura.deleteMany();
  await prisma.descargaSAT.deleteMany();
  console.log('Base de datos limpiada - 0 facturas');
  await prisma.$disconnect();
}

clean().catch(console.error);