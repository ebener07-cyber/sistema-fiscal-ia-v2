# Relaciones del Sistema

Dashboard
│
├── DashboardLayout
├── DashboardCard
├── DataTable
└── Prisma

Empresas
│
└── DashboardLayout

Clientes
│
├── DashboardLayout
└── ClienteTable

Empresa
│
├── Cliente
│
└── Factura
