# Rutas del Sistema

/dashboard

/clientes

/empresas

/facturacion

/gastos

/impuestos

/ia-fiscal

/imss

/infonavit

/login

/nomina

/proveedores

/ptu

/reportes

/sat

/sat/buzon-tributario

/sat/cfdi

/sat/constancia-fiscal

/sat/opinion-cumplimiento
