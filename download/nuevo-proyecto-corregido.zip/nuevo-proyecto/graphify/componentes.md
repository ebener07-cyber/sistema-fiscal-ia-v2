# Componentes del Sistema

## DashboardLayout

Responsable de:

* Layout principal
* Sidebar
* Navbar
* Renderizado de páginas

Dependencias:

* Sidebar
* Navbar

---

## Sidebar

Responsable de:

* Navegación principal

Rutas activas:

* Dashboard
* Empresas
* Clientes
* Facturación
* Gastos
* Impuestos
* Nómina
* Reportes

Rutas pendientes:

* SAT
* IMSS
* Infonavit
* PTU
* Proveedores
* IA Fiscal

---

## Navbar

Responsable de:

* Barra superior
* Información contextual
* Acciones globales

---

## ClienteTable

Tabla de clientes.

---

## DataTable

Tabla general para Dashboard.

---

## DashboardCard

Tarjetas KPI.
