# Entidades del Sistema

## Empresa

Campos:

* id
* nombre
* rfc
* email
* telefono
* direccion
* createdAt

Relaciones:

* Cliente[]
* Factura[]

---

## Cliente

Campos:

* id
* nombre
* rfc
* correo
* empresaId
* createdAt

Relaciones:

* Empresa

---

## Factura

Campos:

* id
* folio
* monto
* empresaId
* createdAt

Relaciones:

* Empresa

---

## AlertaFiscal

Campos:

* id
* titulo
* descripcion
* prioridad
* createdAt
