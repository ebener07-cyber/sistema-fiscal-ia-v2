# Dependencias Detectadas

## Framework

* Next.js 15
* React
* TypeScript

## UI

* TailwindCSS
* Lucide React

## Base de Datos

* PostgreSQL
* Prisma ORM

## Arquitectura

DashboardLayout
├── Sidebar
├── Navbar
└── Páginas

Dashboard
├── DashboardCard
├── DataTable
└── Prisma

Clientes
├── DashboardLayout
└── ClienteTable
