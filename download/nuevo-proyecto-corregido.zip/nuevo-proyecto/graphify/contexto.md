# Contexto Global

Proyecto:

Sistema Fiscal Auditado

Stack:

* Next.js 15
* React
* TypeScript
* Prisma ORM
* PostgreSQL
* TailwindCSS

Objetivo:

Plataforma empresarial para gestión fiscal, financiera y laboral.

Estado actual:

* Prisma configurado
* PostgreSQL conectado
* Dashboard funcional
* Empresas conectadas a BD
* Clientes en desarrollo
* Facturación en desarrollo
* SAT en desarrollo

Arquitectura IA:

Graphify = Memoria Técnica

ChatGPT = Arquitecto y Programador Principal
