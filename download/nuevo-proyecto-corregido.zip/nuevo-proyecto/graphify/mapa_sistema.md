# Mapa General del Sistema Fiscal Auditado

Sistema Fiscal Auditado
│
├── Dashboard
│
├── Empresas
│   ├── Clientes
│   └── Facturación
│
├── SAT
│   ├── CFDI
│   ├── Opinión de Cumplimiento
│   ├── Constancia Fiscal
│   └── Buzón Tributario
│
├── Nómina
│
├── IMSS
│
├── Infonavit
│
├── PTU
│
├── Proveedores
│
├── Gastos
│
├── Impuestos
│
├── IA Fiscal
│
└── Reportes
