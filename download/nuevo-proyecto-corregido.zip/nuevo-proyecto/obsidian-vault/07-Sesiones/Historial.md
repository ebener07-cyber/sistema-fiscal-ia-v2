# Sesiones y Decisiones Técnicas

> Historial de decisiones importantes del proyecto

---

## Sesión: Setup Inicial

**Fecha:** 2024

**Decisiones:**
- Uso de Next.js 15 como framework principal
- Prisma como ORM
- PostgreSQL como base de datos
- TailwindCSS para estilos

---

## Sesión: Arquitectura de Dashboard

**Fecha:** 2024

**Decisiones:**
- DashboardLayout como componente base
- Sidebar para navegación
- Navbar para información contextual
- Cards KPI para métricas

---

## Sesión: Modelo de Datos

**Fecha:** 2024

**Decisiones:**
- Empresa como entidad central
- Cliente y Factura relacionados con Empresa
- AlertaFiscal para notificaciones

---

## Sesión: Graphify Integration

**Fecha:** 2024

**Decisiones:**
- Crear carpeta `graphify/` para documentación técnica
- Archivos Markdown para cada sección
- Carga dinámica para enriquecer prompts de IA

---

## Sesión: Obsidian Integration

**Fecha:** 2026

**Decisiones:**
- Crear vault de Obsidian en `obsidian-vault/`
- Sincronización bidireccional con `graphify/`
- Scripts de sync en `obsidian-sync/`

---

## Pendientes

- [ ] Implementar autenticación completa
- [ ] Terminar módulo de facturación
- [ ] Integrar validación SAT
- [ ] Completar cálculo de nómina