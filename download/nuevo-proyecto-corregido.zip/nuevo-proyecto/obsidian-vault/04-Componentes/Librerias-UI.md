# Componentes del Sistema

## DashboardLayout

**Responsable de:**
- Layout principal de la aplicación
- Sidebar de navegación
- Navbar superior
- Renderizado de páginas

**Dependencias:**
- `Sidebar`
- `Navbar`

**Ubicación:** `components/DashboardLayout.tsx`

---

## Sidebar

**Responsable de:**
- Navegación principal del sistema

**Rutas activas:**
- Dashboard
- Empresas
- Clientes
- Facturación
- Gastos
- Impuestos
- Nómina
- Reportes

**Rutas pendientes:**
- SAT
- IMSS
- Infonavit
- PTU
- Proveedores
- IA Fiscal

**Ubicación:** `components/Sidebar.tsx`

---

## Navbar

**Responsable de:**
- Barra superior de la aplicación
- Información contextual
- Acciones globales

**Ubicación:** `components/Navbar.tsx`

---

## ClienteTable

**Responsable de:**
- Mostrar tabla de clientes
- Acciones CRUD sobre clientes

**Ubicación:** `components/ClienteTable.tsx`

---

## DataTable

**Responsable de:**
- Tabla genérica para Dashboard
- Renderizado de datos tabulares

**Ubicación:** `components/DataTable.tsx`

---

## DashboardCard

**Responsable de:**
- Tarjetas KPI para el dashboard
- Mostrar métricas clave

**Ubicación:** `components/DashboardCard.tsx`

---

## Componentes de Formularios

**Ubicación:** `components/forms/`

- Formularios reutilizables para cada entidad

---

## Componentes UI Base

**Ubicación:** `components/ui/`

- Elementos base: botones, inputs, cards, etc.