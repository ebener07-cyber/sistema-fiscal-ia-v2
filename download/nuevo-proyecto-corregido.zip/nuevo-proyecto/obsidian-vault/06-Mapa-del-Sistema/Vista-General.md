# Mapa General del Sistema

## Arquitectura de Módulos

```
Sistema Fiscal Auditado
│
├── Dashboard
│   ├── KPIs
│   ├── Métricas
│   └── Reportes rápidos
│
├── Empresas
│   ├── Clientes
│   └── Facturación
│
├── SAT
│   ├── CFDI
│   ├── Opinión de Cumplimiento
│   ├── Constancia Fiscal
│   └── Buzón Tributario
│
├── Nómina
│   ├── Cálculo de nómina
│   ├── Timbrado
│   └── Emisión de recibos
│
├── IMSS
│   ├── Altas/Bajas
│   └── Reportes
│
├── Infonavit
│   ├── Créditos
│   └── Amortizaciones
│
├── PTU
│   └── Cálculo de participación
│
├── Proveedores
│   └── Gestión de proveedores
│
├── Gastos
│   └── Control de gastos
│
├── Impuestos
│   ├── ISR
│   ├── IVA
│   └── DIOT
│
├── IA Fiscal
│   └── Asistente inteligente
│
└── Reportes
    ├── Financieros
    ├── Fiscales
    └── Laborales
```

## Flujo de Navegación

```
Login
  │
  ▼
Dashboard ──────────────────────────────────────┐
  │                                            │
  ├── Empresas ──── Clientes                   │
  │                └── Facturas                │
  │                                            │
  ├── SAT ───────── CFDI                       │
  │            ├── Opinión                     │
  │            ├── Constancia                   │
  │            └── Buzón                        │
  │                                            │
  ├── Nómina ────── IMSS                       │
  │            ├── Infonavit                    │
  │            └── PTU                          │
  │                                            │
  ├── Impuestos ── ISR                         │
  │            ├── IVA                          │
  │            └── DIOT                         │
  │                                            │
  ├── Proveedores                              │
  ├── Gastos                                    │
  ├── IA Fiscal                                │
  └── Reportes                                 │
```