# Obsidian Vault - Graphify Integration

Este vault está sincronizado bidireccionalmente con la carpeta `graphify/` del proyecto.

## Estructura de Carpetas

| Carpeta Obsidian | Archivo Graphify | Descripción |
|------------------|------------------|-------------|
| 01-Contexto/ | contexto.md | Arquitectura general |
| 02-Entidades/ | entidades.md | Entidades de base de datos |
| 03-Relaciones/ | relaciones.md | Relaciones entre entidades |
| 04-Componentes/ | componentes.md | Componentes React |
| 05-Rutas/ | rutas.md | Endpoints de API |
| 06-Mapa-del-Sistema/ | mapa_sistema.md | Vista general |
| 07-Sesiones/ | sesiones.md | Historial de decisiones |
| 08-Dependencias/ | dependencias.md | Paquetes npm |

## Comandos Rápidos

### Sincronizar cambios
```bash
npx ts-node obsidian-sync/sync.ts
```

### Sincronización en tiempo real
```bash
npx ts-node obsidian-sync/watch.ts
```

## Tips para Obsidian

- Usa `[[enlaces]]` para conectar notas entre sí
- Agrega tags con `#etiqueta` para categorizar
- Usa `#importante` o `#pendiente` para seguimiento
- Los archivos se sincronizan automáticamente al guardar

## Mapeo de Carpetas

Los archivos se mapean automáticamente según `obsidian-sync/sync-config.json`