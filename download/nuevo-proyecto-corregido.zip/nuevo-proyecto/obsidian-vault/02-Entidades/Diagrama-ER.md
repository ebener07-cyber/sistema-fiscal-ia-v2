# Entidades del Sistema

## Empresa

**Campos:**
- `id` - Identificador único
- `nombre` - Razón social
- `rfc` - RFC de la empresa
- `email` - Correo electrónico
- `telefono` - Teléfono de contacto
- `direccion` - Dirección fiscal
- `createdAt` - Fecha de creación

**Relaciones:**
- `Cliente[]` - Una empresa tiene muchos clientes
- `Factura[]` - Una empresa tiene muchas facturas

---

## Cliente

**Campos:**
- `id` - Identificador único
- `nombre` - Nombre o razón social
- `rfc` - RFC del cliente
- `correo` - Correo electrónico
- `empresaId` - FK a Empresa
- `createdAt` - Fecha de creación

**Relaciones:**
- `Empresa` - Un cliente pertenece a una empresa

---

## Factura

**Campos:**
- `id` - Identificador único
- `folio` - Número de folio
- `monto` - Importe total
- `empresaId` - FK a Empresa
- `createdAt` - Fecha de creación

**Relaciones:**
- `Empresa` - Una factura pertenece a una empresa

---

## AlertaFiscal

**Campos:**
- `id` - Identificador único
- `titulo` - Título de la alerta
- `descripcion` - Descripción detallada
- `prioridad` - Nivel de prioridad (alta, media, baja)
- `createdAt` - Fecha de creación

---

## Diagrama de Relaciones

```
Empresa (1) ──────< Cliente (N)
Empresa (1) ──────< Factura (N)
Empresa (1) ──────< AlertaFiscal (N)
```