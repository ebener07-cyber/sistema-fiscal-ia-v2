# Relaciones entre Entidades

## Dashboard

```
Dashboard
├── DashboardLayout
├── DashboardCard
├── DataTable
└── Prisma
```

## Empresas

```
Empresas
└── DashboardLayout
```

## Clientes

```
Clientes
├── DashboardLayout
└── ClienteTable
```

## Modelo de Datos

```
Empresa
├── Cliente (1:N)
└── Factura (1:N)
```

## Jerarquía de Componentes

```
DashboardLayout
├── Sidebar
├── Navbar
└── Contenido (páginas)

Dashboard
├── DashboardCard (KPI cards)
├── DataTable (tablas de datos)
└── Prisma (acceso a datos)
```

## Flujo de Datos

1. **UI** → Componentes React
2. **API Routes** → Endpoints Next.js
3. **Prisma** → ORM de base de datos
4. **PostgreSQL** → Base de datos

## Relaciones con Módulos

| Módulo | Dependencias |
|--------|-------------|
| Dashboard | DashboardLayout, Prisma |
| Empresas | DashboardLayout, Prisma |
| Clientes | DashboardLayout, ClienteTable |
| Facturación | DashboardLayout, Prisma |
| SAT | Prisma, APIs externas |