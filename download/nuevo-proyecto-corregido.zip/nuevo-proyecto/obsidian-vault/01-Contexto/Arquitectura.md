# Contexto Global

## Proyecto

Sistema Fiscal Auditado

## Stack Tecnológico

- **Frontend**: Next.js 15, React, TypeScript
- **Estilos**: TailwindCSS
- **Base de Datos**: PostgreSQL, Prisma ORM
- **UI Components**: Lucide React

## Objetivo

Plataforma empresarial para gestión fiscal, financiera y laboral.

## Estado Actual del Proyecto

- ✅ Prisma configurado
- ✅ PostgreSQL conectado
- ✅ Dashboard funcional
- ✅ Empresas conectadas a BD
- 🔄 Clientes en desarrollo
- 🔄 Facturación en desarrollo
- 🔄 SAT en desarrollo

## Arquitectura IA

- **Graphify** = Memoria Técnica del proyecto
- **ChatGPT** = Arquitecto y Programador Principal

## Módulos Principales

| Módulo | Estado | Descripción |
|--------|--------|-------------|
| Dashboard | ✅ | Panel principal con KPIs |
| Empresas | ✅ | Gestión de empresas |
| Clientes | 🔄 | Gestión de clientes |
| Facturación | 🔄 | CFDI y facturas |
| SAT | 🔄 | Validaciones SAT |
| Nómina | 🔄 | Cálculo de nómina |
| Impuestos | 🔄 | Declaración de impuestos |
| Gastos | 🔄 | Control de gastos |

## Notas de Arquitectura

- El sistema usa un DashboardLayout como base para todos los módulos
- Prisma genera tipos automáticamente desde el schema
- Graphify carga archivos .md para dar contexto a la IA