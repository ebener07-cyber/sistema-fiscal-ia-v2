# Rutas del Sistema

## Rutas Principales

| Ruta | Módulo | Estado |
|------|--------|--------|
| `/dashboard` | Dashboard | ✅ |
| `/empresas` | Empresas | ✅ |
| `/clientes` | Clientes | ✅ |
| `/facturacion` | Facturación | 🔄 |
| `/gastos` | Gastos | 🔄 |
| `/impuestos` | Impuestos | 🔄 |
| `/nomina` | Nómina | 🔄 |
| `/reportes` | Reportes | 🔄 |

## Rutas SAT

| Ruta | Descripción | Estado |
|------|-------------|--------|
| `/sat` | Portal SAT principal | 🔄 |
| `/sat/buzon-tributario` | Buzón Tributario | 🔄 |
| `/sat/cfdi` | Gestión de CFDI | 🔄 |
| `/sat/constancia-fiscal` | Constancia de situación fiscal | 🔄 |
| `/sat/opinion-cumplimiento` | Opinión de cumplimiento | 🔄 |

## Rutas de Nómina y Laboral

| Ruta | Descripción | Estado |
|------|-------------|--------|
| `/nomina` | Cálculo de nómina | 🔄 |
| `/imss` | Tramites IMSS | 🔄 |
| `/infonavit` | Tramites Infonavit | 🔄 |
| `/ptu` | PTU (Participación de Utilidades) | 🔄 |

## Otras Rutas

| Ruta | Descripción | Estado |
|------|-------------|--------|
| `/proveedores` | Gestión de proveedores | 🔄 |
| `/ia-fiscal` | Asistente de IA fiscal | 🔄 |
| `/login` | Autenticación | 🔄 |

## API Routes

**Ubicación:** `app/api/`

- `/api/auth/*` - Autenticación
- `/api/clientes/*` - CRUD de clientes
- `/api/empresas/*` - CRUD de empresas
- `/api/facturas/*` - CRUD de facturas