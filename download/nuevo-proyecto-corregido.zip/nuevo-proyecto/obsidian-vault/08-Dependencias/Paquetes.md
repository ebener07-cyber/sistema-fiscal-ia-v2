# Dependencias del Proyecto

## Framework Principal

| Paquete | Versión | Propósito |
|---------|---------|-----------|
| next | 15.x | Framework React |
| react | ^19 | Librería UI |
| react-dom | ^19 | DOM rendering |
| typescript | ^5 | Tipado estático |

## Base de Datos

| Paquete | Versión | Propósito |
|---------|---------|-----------|
| @prisma/client | ^6 | ORM para PostgreSQL |
| prisma | ^6 | CLI de Prisma |
| postgresql | - | Base de datos |

## UI y Estilos

| Paquete | Versión | Propósito |
|---------|---------|-----------|
| tailwindcss | ^4 | Framework CSS |
| lucide-react | ^0.400+ | Iconos |
| clsx | ^2 | Utilidad de clases |

## Utilidades

| Paquete | Versión | Propósito |
|---------|---------|-----------|
| @types/node | ^22 | Tipos Node.js |
| @types/react | ^19 | Tipos React |

## Arquitectura de Componentes

```
DashboardLayout
├── Sidebar
├── Navbar
└── Páginas

Dashboard
├── DashboardCard
├── DataTable
└── Prisma

Clientes
├── DashboardLayout
└── ClienteTable
```

## Scripts Disponibles

```bash
# Desarrollo
npm run dev

# Build
npm run build

# Prisma
npx prisma generate
npx prisma db push
npx prisma studio
```