#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

// Configuración
const OBSIDIAN_VAULT = 'C:\\Users\\compu\\vault-obsidian'; // ← Ajusta esta ruta
const ARCHITECTURE_DIR = 'docs/architecture';

// Extraer cambios del commit
function getChangedFiles() {
  try {
    const output = execSync('git diff --cached --name-only --diff-filter=ACMR')
      .toString()
      .trim()
      .split('\n');
    return output.filter(f => f.endsWith('.ts') || f.endsWith('.tsx') || f.endsWith('.js'));
  } catch {
    return fs.readdirSync('.')
      .filter(f => f.endsWith('.ts'))
      .map(f => path.join(process.cwd(), f));
  }
}

// Analizar imports y dependencias
function analyzeDependencies(files) {
  const graph = {};
  const dependencies = {};
  
  files.forEach(file => {
    try {
      const content = fs.readFileSync(file, 'utf8');
      const importRegex = /import\s+.*?\s+from\s+['"](.*?)['"]/g;
      const matches = [...content.matchAll(importRegex)];
      
      const fileName = path.basename(file);
      graph[fileName] = [];
      dependencies[fileName] = [];
      
      matches.forEach(match => {
        const importPath = match[1];
        if (!importPath.startsWith('next/') && !importPath.startsWith('@/lib/')) {
          const importName = importPath.split('/').pop() || importPath;
          graph[fileName].push(importName);
          dependencies[fileName].push(importPath);
        }
      });
    } catch (e) {
      console.log(`Error leyendo ${file}: ${e.message}`);
    }
  });
  
  return { graph, dependencies };
}

// Generar diagrama Mermaid
function generateMermaid(graph, dependencies) {
  let md = '```mermaid\ngraph TD\n';
  
  // Nodos principales
  Object.entries(graph).forEach(([file, imports]) => {
    const nodeName = file.replace(/\.(ts|tsx|js)$/, '');
    md += `    ${nodeName}[${file}]\n`;
    
    imports.forEach(imp => {
      const impName = imp.split('/').pop().replace(/\.(ts|tsx|js)$/, '');
      md += `    ${nodeName} --> ${impName}\n`;
    });
  });
  
  md += '```\n\n## 📦 Dependencias\n\n';
  Object.entries(dependencies).forEach(([file, deps]) => {
    if (deps.length > 0) {
      md += `### ${file}\n`;
      deps.forEach(dep => md += `- ${dep}\n`);
      md += '\n';
    }
  });
  
  return md;
}

// Actualizar Obsidian Vault
function updateObsidian(content, fileName) {
  const vaultPath = path.join(OBSIDIAN_VAULT, ARCHITECTURE_DIR);
  if (!fs.existsSync(vaultPath)) {
    fs.mkdirSync(vaultPath, { recursive: true });
  }
  
  const filePath = path.join(vaultPath, `${fileName}.md`);
  fs.writeFileSync(filePath, `# ${fileName}\n\n${content}`);
  console.log(`✅ Diagrama guardado en: ${filePath}`);
}

// Main
(function main() {
  console.log('🔍 Analizando cambios...');
  const files = getChangedFiles();
  console.log(`📄 Archivos encontrados: ${files.length}`);
  
  if (files.length === 0) return;
  
  const { graph, dependencies } = analyzeDependencies(files);
  const mermaid = generateMermaid(graph, dependencies);
  const date = new Date().toISOString().split('T')[0];
  
  updateObsidian(mermaid, `architecture-${date}`);
  console.log('🎉 Workflow completado');
})();