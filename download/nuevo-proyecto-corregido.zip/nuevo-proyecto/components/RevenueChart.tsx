'use client';

export default function RevenueChart() {
  const data = [
    { month: 'Ene', income: 2.0, expenses: 1.2, profit: 0.8 },
    { month: 'Feb', income: 2.2, expenses: 1.4, profit: 0.8 },
    { month: 'Mar', income: 2.3, expenses: 1.5, profit: 0.8 },
    { month: 'Abr', income: 2.4, expenses: 1.6, profit: 0.8 },
    { month: 'May', income: 2.5, expenses: 1.7, profit: 0.8 },
  ];

  const maxValue = 2.5;

  return (
    <div className="bg-gradient-to-br from-dark-card to-dark-bg border border-purple-500/20 rounded-2xl p-6 backdrop-blur-sm">
      <h3 className="text-white text-lg font-semibold mb-4">
        Resumen Financiero del Mes
      </h3>

      <div className="flex gap-8 items-end justify-around h-64 mb-6">
        {data.map((item) => (
          <div key={item.month} className="flex flex-col items-center gap-2">
            {/* Barras */}
            <div className="flex gap-1 h-48 items-end">
              <div
                className="w-3 bg-gradient-to-t from-purple-600 to-purple-400 rounded-t opacity-80"
                style={{ height: `${(item.income / maxValue) * 100}%` }}
              />
              <div
                className="w-3 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t opacity-80"
                style={{ height: `${(item.expenses / maxValue) * 100}%` }}
              />
              <div
                className="w-3 bg-gradient-to-t from-green-600 to-green-400 rounded-t opacity-80"
                style={{ height: `${(item.profit / maxValue) * 100}%` }}
              />
            </div>
            <span className="text-xs text-gray-400">{item.month}</span>
          </div>
        ))}
      </div>

      {/* Leyenda */}
      <div className="flex gap-6 justify-center text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-gradient-to-r from-purple-600 to-purple-400" />
          <span className="text-gray-400">Ingresos</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-gradient-to-r from-blue-600 to-blue-400" />
          <span className="text-gray-400">Gastos</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-gradient-to-r from-green-600 to-green-400" />
          <span className="text-gray-400">Utilidad</span>
        </div>
      </div>

      {/* Valores en escala */}
      <div className="mt-4 text-xs text-gray-500 flex justify-between">
        <span>$0</span>
        <span>$500K</span>
        <span>$1M</span>
        <span>$1.5M</span>
        <span>$2.5M</span>
      </div>
    </div>
  );
}
