'use client';

import { Sparkles, TrendingDown } from 'lucide-react';

export default function AiRecommendation() {
  return (
    <div className="bg-gradient-to-br from-purple-900/20 via-dark-card to-dark-bg border border-purple-500/30 rounded-2xl p-6 backdrop-blur-sm shadow-glow-isr">
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0">
          <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-purple-500/20 border border-purple-400/50">
            <Sparkles size={24} className="text-purple-400" />
          </div>
        </div>

        <div className="flex-1">
          <h3 className="text-white text-lg font-bold mb-2 flex items-center gap-2">
            Recomendación IA
          </h3>

          <p className="text-gray-300 text-sm mb-4">
            💡 Si deduces <span className="text-purple-400 font-bold">$95,000</span> adicionales 
            antes del cierre mensual, tu ISR podría reducirse aproximadamente en:
          </p>

          <div className="bg-dark-bg/50 border border-purple-500/20 rounded-lg p-4 mb-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingDown className="text-green-400" size={20} />
              <span className="text-green-400 text-2xl font-bold">$23,750</span>
            </div>
            <p className="text-gray-400 text-sm">
              Estimado de ahorro fiscal
            </p>
            <p className="text-gray-500 text-xs mt-2">
              19.3% menos de ISR en junio
            </p>
          </div>

          <button className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 text-white font-semibold py-2 px-4 rounded-lg transition-all flex items-center justify-center gap-2">
            Ver detalle de estrategia →
          </button>
        </div>
      </div>
    </div>
  );
}