import Sidebar from "./Sidebar";
import Navbar from "./Navbar";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({
  children,
}: DashboardLayoutProps) {
  return (
    <div className="flex min-h-screen bg-[#040816] text-white">
      <Sidebar />

      <main className="flex-1 px-10 py-8 overflow-y-auto">
        <Navbar />
        {children}
      </main>
    </div>
  );
}