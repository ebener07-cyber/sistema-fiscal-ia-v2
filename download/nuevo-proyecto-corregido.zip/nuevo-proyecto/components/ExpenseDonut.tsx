'use client';

export default function ExpenseDonut() {
  const total = 1250000;
  const segments = [
    { label: 'Deducibles autorizadas', value: 812500, color: 'from-purple-600 to-purple-400', percent: 65 },
    { label: 'Deducibles limitadas', value: 250000, color: 'from-blue-600 to-blue-400', percent: 20 },
    { label: 'No deducibles', value: 125000, color: 'from-gray-600 to-gray-400', percent: 10 },
    { label: 'Pendientes de clasificar', value: 62500, color: 'from-orange-600 to-orange-400', percent: 5 },
  ];

  // Calcular ángulos para el donut
  let currentAngle = -90;
  const segmentPaths = segments.map((segment) => {
    const sliceAngle = (segment.percent / 100) * 360;
    const startAngle = currentAngle * (Math.PI / 180);
    const endAngle = (currentAngle + sliceAngle) * (Math.PI / 180);

    const startX = 50 + 40 * Math.cos(startAngle);
    const startY = 50 + 40 * Math.sin(startAngle);
    const endX = 50 + 40 * Math.cos(endAngle);
    const endY = 50 + 40 * Math.sin(endAngle);

    const largeArc = sliceAngle > 180 ? 1 : 0;

    const path = `M ${startX} ${startY} A 40 40 0 ${largeArc} 1 ${endX} ${endY} L ${50 + 20 * Math.cos(endAngle)} ${50 + 20 * Math.sin(endAngle)} A 20 20 0 ${largeArc} 0 ${50 + 20 * Math.cos(startAngle)} ${50 + 20 * Math.sin(startAngle)} Z`;

    currentAngle += sliceAngle;
    return { path, color: segment.color };
  });

  return (
    <div className="bg-gradient-to-br from-dark-card to-dark-bg border border-purple-500/20 rounded-2xl p-6 backdrop-blur-sm">
      <h3 className="text-white text-lg font-semibold mb-6">
        Distribución de Gastos
      </h3>

      <div className="flex gap-8 items-center">
        {/* Donut Chart */}
        <div className="flex-1 flex justify-center">
          <div className="relative w-48 h-48">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {segmentPaths.map((segment, idx) => (
                <path
                  key={idx}
                  d={segment.path}
                  className={`bg-gradient-to-r ${segment.color} fill-current`}
                  style={{
                    fill: `url(#gradient-${idx})`,
                  }}
                />
              ))}
              <defs>
                {segments.map((segment, idx) => (
                  <linearGradient
                    key={idx}
                    id={`gradient-${idx}`}
                    x1="0%"
                    y1="0%"
                    x2="100%"
                    y2="100%"
                  >
                    <stop offset="0%" stopColor={segment.color.split(' to-')[0].split('from-')[1]} />
                    <stop offset="100%" stopColor={segment.color.split(' to-')[1]} />
                  </linearGradient>
                ))}
              </defs>
            </svg>

            {/* Centro con valor total */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-center">
                <p className="text-gray-400 text-xs">Total</p>
                <p className="text-white text-xl font-bold">
                  ${(total / 1000000).toFixed(2)}M
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Leyenda */}
        <div className="flex-1 space-y-3">
          {segments.map((segment, idx) => (
            <div key={idx} className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${segment.color}`} />
              <div className="flex-1">
                <p className="text-gray-400 text-sm">{segment.label}</p>
                <p className="text-white text-sm font-semibold">
                  {segment.percent}% · ${(segment.value / 1000).toFixed(0)}K
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
