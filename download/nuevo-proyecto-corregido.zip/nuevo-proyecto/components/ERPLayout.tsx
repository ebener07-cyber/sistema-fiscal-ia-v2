'use client';

import { ReactNode } from 'react';
import { useRouter, usePathname } from 'next/navigation';

type ModuleKey =
  | 'dashboard'
  | 'empresas'
  | 'contabilidad'
  | 'descarga'
  | 'inventario'
  | 'bancos'
  | 'nomina'
  | 'crm'
  | 'compras'
  | 'tributario'
  | 'diot'
  | 'reportes'
  | 'usuarios';

interface Module {
  key: ModuleKey;
  name: string;
  icon: string;
  color: string;
  bgColor: string;
  description: string;
  entities: string[];
  connects: ModuleKey[];
  path: string;
}

export const MODULES: Record<ModuleKey, Module> = {
  dashboard: {
    key: 'dashboard',
    name: 'Dashboard',
    icon: '📊',
    color: 'text-slate-700',
    bgColor: 'bg-slate-100',
    description: 'Panel ejecutivo con KPIs, volumen de CFDIs descargados y estatus',
    entities: ['KPIs', 'Widgets', 'Notificaciones', 'Resumen SAT'],
    connects: ['descarga', 'contabilidad', 'bancos', 'tributario'],
    path: '/dashboard',
  },
  empresas: {
    key: 'empresas',
    name: 'Empresas',
    icon: '🏢',
    color: 'text-blue-700',
    bgColor: 'bg-blue-100',
    description: 'Gestión de empresas con validación de constancia fiscal del SAT',
    entities: ['Alta de empresas', 'Validación RFC', 'Constancia fiscal', 'Catálogo SAT'],
    connects: ['contabilidad', 'tributario', 'diot'],
    path: '/empresas',
  },
  contabilidad: {
    key: 'contabilidad',
    name: 'Contabilidad',
    icon: '📒',
    color: 'text-emerald-700',
    bgColor: 'bg-emerald-100',
    description: 'Libros contables, asientos automáticos, pólizas desde XML del SAT',
    entities: ['Plan de cuentas', 'Asientos automáticos', 'Diario', 'Mayor', 'Balance'],
    connects: ['descarga', 'bancos', 'compras', 'nomina', 'tributario'],
    path: '/contabilidad',
  },
  descarga: {
    key: 'descarga',
    name: 'Descarga SAT',
    icon: '🟢',
    color: 'text-rose-700',
    bgColor: 'bg-rose-100',
    description: 'Descarga masiva de CFDIs emitidos/recibidos directamente del portal del SAT',
    entities: ['Login SAT', 'Solicitud', 'Verificación', 'Descarga', 'Paquetes ZIP', 'XML/Metadata', 'Historial'],
    connects: ['contabilidad', 'inventario', 'bancos', 'tributario'],
    path: '/descarga-sat',
  },
  inventario: {
    key: 'inventario',
    name: 'Inventario',
    icon: '📦',
    color: 'text-amber-700',
    bgColor: 'bg-amber-100',
    description: 'Productos y servicios clasificados desde CFDI de compras y ventas',
    entities: ['Productos', 'Servicios', 'Claves SAT', 'Unidades', 'Catálogo c_ClaveProdServ'],
    connects: ['descarga', 'compras'],
    path: '/inventario',
  },
  bancos: {
    key: 'bancos',
    name: 'Bancos',
    icon: '🏦',
    color: 'text-cyan-700',
    bgColor: 'bg-cyan-100',
    description: 'Conciliación automática contra CFDIs de pagos y transferencias',
    entities: ['Cuentas', 'Conciliación', 'Pagos', 'Cobros', 'Estado de cuenta'],
    connects: ['contabilidad', 'descarga', 'compras', 'nomina'],
    path: '/bancos',
  },
  nomina: {
    key: 'nomina',
    name: 'Nómina',
    icon: '💼',
    color: 'text-purple-700',
    bgColor: 'bg-purple-100',
    description: 'Recibos de nómina descargados del SAT, IMSS, SUA e incidencias',
    entities: ['Empleados', 'Recibos SAT', 'IMSS/INFONAVIT', 'SUA', 'Incidencias'],
    connects: ['contabilidad', 'bancos', 'tributario', 'usuarios'],
    path: '/nomina',
  },
  crm: {
    key: 'crm',
    name: 'CRM / Clientes',
    icon: '🤝',
    color: 'text-pink-700',
    bgColor: 'bg-pink-100',
    description: 'Clientes y proveedores identificados automáticamente por RFC en los CFDIs',
    entities: ['Clientes', 'Proveedores', 'RFC', 'Historial CFDI', 'Contactos'],
    connects: ['descarga', 'reportes', 'usuarios'],
    path: '/crm',
  },
  compras: {
    key: 'compras',
    name: 'Compras',
    icon: '🛒',
    color: 'text-orange-700',
    bgColor: 'bg-orange-100',
    description: 'Cuentas por pagar generadas desde CFDI de gastos descargados del SAT',
    entities: ['Proveedores', 'CxP', 'Gastos', 'Facturas recibidas'],
    connects: ['inventario', 'contabilidad', 'bancos', 'descarga'],
    path: '/compras',
  },
  tributario: {
    key: 'tributario',
    name: 'Tributario',
    icon: '⚖️',
    color: 'text-red-700',
    bgColor: 'bg-red-100',
    description: 'Declaraciones ISR, IVA, DIOT generadas desde XML descargados y validados',
    entities: ['ISR', 'IVA', 'DIOT', 'Declaraciones', 'Acuses SAT', 'Conta Electrónica'],
    connects: ['contabilidad', 'descarga', 'bancos', 'nomina', 'compras'],
    path: '/tributario',
  },
  diot: {
    key: 'diot',
    name: 'DIOT',
    icon: '📋',
    color: 'text-indigo-700',
    bgColor: 'bg-indigo-100',
    description: 'Declaración Informativa de Operaciones con Terceros - Generación automática',
    entities: ['Generación DIOT', 'Validación RFC', 'Retenciones', 'Presentación SAT'],
    connects: ['contabilidad', 'tributario', 'reportes'],
    path: '/diot',
  },
  reportes: {
    key: 'reportes',
    name: 'Reportes',
    icon: '📈',
    color: 'text-indigo-700',
    bgColor: 'bg-indigo-100',
    description: 'Reportes fiscales, ventas, gastos, XML masivos y BI',
    entities: ['Reporte ventas', 'Reporte gastos', 'Reporte XML', 'Exportar Excel', 'BI'],
    connects: ['dashboard', 'contabilidad', 'descarga', 'tributario'],
    path: '/reportes',
  },
  usuarios: {
    key: 'usuarios',
    name: 'Usuarios',
    icon: '🔐',
    color: 'text-slate-700',
    bgColor: 'bg-slate-100',
    description: 'Control de acceso por RFC, roles, permisos y credenciales SAT',
    entities: ['Roles', 'Permisos', 'Usuarios', 'Credenciales SAT', 'e.firma', 'Auditoría'],
    connects: ['dashboard', 'crm', 'nomina', 'descarga'],
    path: '/usuarios',
  },
};

const NAV_ORDER: ModuleKey[] = [
  'dashboard',
  'empresas',
  'descarga',
  'contabilidad',
  'inventario',
  'bancos',
  'nomina',
  'crm',
  'compras',
  'tributario',
  'diot',
  'reportes',
  'usuarios',
];

export function ERPSidebar() {
  const router = useRouter();
  const pathname = usePathname();

  const getActiveModule = (): ModuleKey => {
    const module = Object.values(MODULES).find(m => pathname.startsWith(m.path));
    return module?.key || 'dashboard';
  };

  const active = getActiveModule();

  return (
    <aside className="w-60 bg-white border-r border-gray-200 flex flex-col shrink-0 min-h-screen fixed left-0 top-0">
      <div className="p-5 border-b border-gray-200">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-rose-500 to-red-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
            A
          </div>
          <div>
            <h1 className="font-bold text-gray-900 leading-tight">Abbax-IA ERP</h1>
            <p className="text-[11px] text-gray-400">Sistema Fiscal Inteligente</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-3 overflow-y-auto">
        <p className="px-3 py-2 text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Módulos</p>
        {NAV_ORDER.map((key) => {
          const m = MODULES[key];
          const isActive = active === key;
          return (
            <button
              key={key}
              onClick={() => router.push(m.path)}
              className={`w-full text-left px-3 py-2 rounded-lg flex items-center gap-3 text-sm transition
                ${isActive ? 'bg-rose-50 text-rose-700 font-semibold' : 'text-gray-600 hover:bg-gray-50'}`}
            >
              <span className="text-base">{m.icon}</span>
              <span>{m.name}</span>
              {isActive && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-rose-500" />}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-200 flex items-center gap-3">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-orange-400 to-pink-500 flex items-center justify-center text-white font-bold text-sm">A</div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-gray-900 truncate">Alejandro G.</p>
          <p className="text-[11px] text-gray-400 truncate">Admin · Fiscalía</p>
        </div>
      </div>
    </aside>
  );
}

export function ERPHeader({ mod }: { mod: Module }) {
  return (
    <header className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between sticky top-0 z-10">
      <div>
        <div className="flex items-center gap-1.5 text-xs text-gray-400">
          <span>Abbax-IA ERP</span><span>›</span>
          <span className="text-rose-600 font-medium">{mod.name}</span>
        </div>
        <h2 className="text-xl font-bold mt-1">{mod.icon} {mod.name}</h2>
        <p className="text-sm text-gray-500">{mod.description}</p>
      </div>
      <div className="flex items-center gap-2">
        <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          SAT Conectado
        </span>
        <span className="px-3 py-1 bg-gray-100 text-gray-600 text-xs font-medium rounded-full">
          v2.4.1
        </span>
      </div>
    </header>
  );
}

export function ERPLayout({ children, moduleKey }: { children: ReactNode; moduleKey: ModuleKey }) {
  const mod = MODULES[moduleKey];

  return (
    <div className="flex h-screen bg-gray-50 font-sans">
      <ERPSidebar />
      <main className="flex-1 overflow-y-auto ml-60">
        <ERPHeader mod={mod} />
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
}