'use client';

import { AlertTriangle, AlertCircle, CheckCircle, Clock } from 'lucide-react';

interface Alert {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title: string;
  description: string;
  time: string;
}

const alerts: Alert[] = [
  {
    id: '1',
    type: 'error',
    title: 'ISR proyectado alto',
    description: 'Tu ISR está 12% arriba del promedio',
    time: 'Hoy',
  },
  {
    id: '2',
    type: 'warning',
    title: 'CFDI pendientes',
    description: 'Tienes 8 facturas pendientes de sellar',
    time: 'Ayer',
  },
  {
    id: '3',
    type: 'warning',
    title: 'Gastos sin categoría',
    description: '$32,500 en gastos por clasificar',
    time: 'Ayer',
  },
  {
    id: '4',
    type: 'success',
    title: 'Opinión de cumplimiento',
    description: 'Tu opinión está en estado POSITIVO',
    time: '2 días',
  },
];

const getAlertIcon = (type: string) => {
  switch (type) {
    case 'error':
      return <AlertTriangle className="text-red-400" size={20} />;
    case 'warning':
      return <AlertCircle className="text-yellow-400" size={20} />;
    case 'success':
      return <CheckCircle className="text-green-400" size={20} />;
    case 'info':
      return <Clock className="text-blue-400" size={20} />;
    default:
      return null;
  }
};

const getAlertStyles = (type: string) => {
  switch (type) {
    case 'error':
      return 'bg-red-500/10 border-red-500/30 hover:bg-red-500/20';
    case 'warning':
      return 'bg-yellow-500/10 border-yellow-500/30 hover:bg-yellow-500/20';
    case 'success':
      return 'bg-green-500/10 border-green-500/30 hover:bg-green-500/20';
    case 'info':
      return 'bg-blue-500/10 border-blue-500/30 hover:bg-blue-500/20';
    default:
      return 'bg-gray-500/10 border-gray-500/30 hover:bg-gray-500/20';
  }
};

export default function FiscalAlertPanel() {
  return (
    <div className="bg-gradient-to-br from-dark-card to-dark-bg border border-red-500/20 rounded-2xl p-6 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white text-lg font-semibold">Alertas Inteligentes</h3>
        <a href="#" className="text-purple-400 text-sm hover:text-purple-300">
          Ver todas
        </a>
      </div>

      <div className="space-y-3">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className={`border rounded-lg p-3 cursor-pointer transition-colors ${getAlertStyles(alert.type)}`}
          >
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                {getAlertIcon(alert.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-semibold text-sm">{alert.title}</p>
                <p className="text-gray-400 text-xs mt-1">{alert.description}</p>
              </div>
              <div className="flex-shrink-0 text-gray-500 text-xs whitespace-nowrap ml-2">
                {alert.time}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
