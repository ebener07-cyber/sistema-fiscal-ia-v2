"use client";

interface Alert {
  id: string;
  title: string;
  description: string;
  severity: "Baja" | "Media" | "Alta";
  module: string;
}

interface FiscalAlertProps {
  alerts: Alert[];
}

const severityColors = {
  Baja: "bg-green-100 border-green-300",
  Media: "bg-yellow-100 border-yellow-300",
  Alta: "bg-red-100 border-red-300",
};

export default function FiscalAlert({ alerts }: FiscalAlertProps) {
  if (alerts.length === 0) {
    return <div className="text-center text-gray-500 p-4">Sin alertas fiscales</div>;
  }

  return (
    <div className="space-y-3 p-4">
      {alerts.map((alert) => (
        <div
          key={alert.id}
          className={`p-4 rounded-lg border-l-4 ${severityColors[alert.severity]}`}
        >
          <div className="flex justify-between items-start">
            <h3 className="font-semibold text-gray-800">{alert.title}</h3>
            <span className="text-xs text-gray-500">{alert.module}</span>
          </div>
          <p className="text-gray-600 mt-1">{alert.description}</p>
        </div>
      ))}
    </div>
  );
}