'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card, CardHeader, CardContent } from '@/components/ui/Card';
import { useApi } from '@/hooks/useApi';

interface ClienteFormProps {
  empresaId: string;
  onSuccess?: () => void;
  initialData?: any;
}

export function ClienteForm({ empresaId, onSuccess, initialData }: ClienteFormProps) {
  const [formData, setFormData] = useState({
    nombre: initialData?.nombre || '',
    rfc: initialData?.rfc || '',
    correo: initialData?.correo || '',
    empresaId: initialData?.empresaId || empresaId,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const { loading, error, execute } = useApi();

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.nombre.trim()) newErrors.nombre = 'Nombre es requerido';
    if (!formData.rfc.trim()) newErrors.rfc = 'RFC es requerido';
    if (!formData.correo.trim()) newErrors.correo = 'Email es requerido';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.correo)) {
      newErrors.correo = 'Email no válido';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const url = initialData?.id ? `/api/clientes/${initialData.id}` : '/api/clientes';
    const method = initialData?.id ? 'PUT' : 'POST';

    const result = await execute(url, method, formData);
    if (result) {
      setFormData({ nombre: '', rfc: '', correo: '', empresaId });
      onSuccess?.();
    }
  };

  return (
    <Card>
      <CardHeader>
        <h2 className="text-xl font-bold">
          {initialData ? 'Editar Cliente' : 'Nuevo Cliente'}
        </h2>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Nombre"
            value={formData.nombre}
            onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
            error={errors.nombre}
            placeholder="Ej: Cliente ABC"
          />
          <Input
            label="RFC"
            value={formData.rfc}
            onChange={(e) => setFormData({ ...formData, rfc: e.target.value })}
            error={errors.rfc}
            placeholder="Ej: CLI123456XYZ"
            disabled={!!initialData}
          />
          <Input
            label="Email"
            type="email"
            value={formData.correo}
            onChange={(e) => setFormData({ ...formData, correo: e.target.value })}
            error={errors.correo}
            placeholder="cliente@example.com"
          />
          {error && <div className="text-red-600 text-sm p-3 bg-red-50 rounded">{error}</div>}
          <Button type="submit" loading={loading} className="w-full">
            {initialData ? 'Actualizar' : 'Crear'} Cliente
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
