'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card, CardHeader, CardContent } from '@/components/ui/Card';
import { useApi } from '@/hooks/useApi';

interface EmpresaFormProps {
  onSuccess?: () => void;
  initialData?: any;
}

export function EmpresaForm({ onSuccess, initialData }: EmpresaFormProps) {
  const [formData, setFormData] = useState({
    nombre: initialData?.nombre || '',
    rfc: initialData?.rfc || '',
    email: initialData?.email || '',
    telefono: initialData?.telefono || '',
    direccion: initialData?.direccion || '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const { loading, error, execute } = useApi();

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.nombre.trim()) newErrors.nombre = 'Nombre es requerido';
    if (!formData.rfc.trim()) newErrors.rfc = 'RFC es requerido';
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email no válido';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const url = initialData?.id
      ? `/api/empresas/${initialData.id}`
      : '/api/empresas';
    const method = initialData?.id ? 'PUT' : 'POST';

    const result = await execute(url, method, formData);
    if (result) {
      setFormData({ nombre: '', rfc: '', email: '', telefono: '', direccion: '' });
      onSuccess?.();
    }
  };

  return (
    <Card>
      <CardHeader>
        <h2 className="text-xl font-bold">
          {initialData ? 'Editar Empresa' : 'Nueva Empresa'}
        </h2>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Nombre"
            value={formData.nombre}
            onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
            error={errors.nombre}
            placeholder="Ej: Mi Empresa S.A."
          />
          <Input
            label="RFC"
            value={formData.rfc}
            onChange={(e) => setFormData({ ...formData, rfc: e.target.value })}
            error={errors.rfc}
            placeholder="Ej: MIE123456ABC"
            disabled={!!initialData}
          />
          <Input
            label="Email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            error={errors.email}
            placeholder="contacto@empresa.com"
          />
          <Input
            label="Teléfono"
            value={formData.telefono}
            onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
            placeholder="+52 55 1234 5678"
          />
          <Input
            label="Dirección"
            value={formData.direccion}
            onChange={(e) => setFormData({ ...formData, direccion: e.target.value })}
            placeholder="Calle Principal 123, México"
          />
          {error && <div className="text-red-600 text-sm p-3 bg-red-50 rounded">{error}</div>}
          <Button type="submit" loading={loading} className="w-full">
            {initialData ? 'Actualizar' : 'Crear'} Empresa
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
