interface KpiCardProps {
  title: string;
  value: string;
  change: string;
}

export default function KpiCard({
  title,
  value,
  change,
}: KpiCardProps) {
  return (
    <div className="bg-[#0F172A] border border-purple-500/20 rounded-2xl p-6">
      <h3 className="text-gray-400 text-sm mb-2">
        {title}
      </h3>

      <p className="text-3xl font-bold text-white">
        {value}
      </p>

      <span className="text-purple-400 text-sm">
        {change}
      </span>
    </div>
  );
}