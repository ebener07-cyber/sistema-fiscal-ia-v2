import { ReactNode } from "react";

interface DashboardCardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon?: ReactNode;
  color?: "isr" | "iva" | "ptu" | "imss" | "default";
  trend?: {
    value: number;
    direction: "up" | "down";
  };
}

const colorStyles = {
  isr: {
    bg: "bg-gradient-to-br from-purple-900/50 to-purple-800/30",
    border: "border-isr-purple/40",
    text: "text-isr-purple",
    trend: "text-isr-purple",
    glow: "shadow-glow-isr",
  },
  iva: {
    bg: "bg-gradient-to-br from-blue-900/50 to-blue-800/30",
    border: "border-iva-blue/40",
    text: "text-iva-blue",
    trend: "text-iva-blue",
    glow: "shadow-glow-iva",
  },
  ptu: {
    bg: "bg-gradient-to-br from-green-900/50 to-green-800/30",
    border: "border-ptu-green/40",
    text: "text-ptu-green",
    trend: "text-ptu-green",
    glow: "shadow-glow-ptu",
  },
  imss: {
    bg: "bg-gradient-to-br from-orange-900/50 to-orange-800/30",
    border: "border-imss-orange/40",
    text: "text-imss-orange",
    trend: "text-imss-orange",
    glow: "shadow-glow-imss",
  },
  default: {
    bg: "bg-dark-card",
    border: "border-purple-500/20",
    text: "text-purple-400",
    trend: "text-purple-400",
    glow: "",
  },
};

export default function DashboardCard({
  title,
  value,
  subtitle,
  icon,
  color = "default",
  trend,
}: DashboardCardProps) {
  const styles = colorStyles[color];

  return (
    <div
      className={`${styles.bg} border ${styles.border} rounded-2xl p-6 backdrop-blur-sm ${styles.glow}`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-gray-400 text-sm mb-2">{title}</h3>
        </div>
        {icon && <div className={`${styles.text} text-2xl`}>{icon}</div>}
      </div>

      <p className="text-3xl font-bold text-white mb-2">{value}</p>

      {trend && (
        <p className={`${styles.trend} text-sm font-semibold`}>
          {trend.direction === "up" ? "▲" : "▼"} {trend.value}% vs Abril
        </p>
      )}

      {subtitle && <p className={`${styles.text} text-sm mt-2`}>{subtitle}</p>}
    </div>
  );
}