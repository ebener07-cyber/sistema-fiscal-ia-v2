"use client";

import { useState } from "react";

interface QuickSimulationProps {
  onSimulate: (monto: number) => { iva: number; isr: number };
}

export default function QuickSimulation({ onSimulate }: QuickSimulationProps) {
  const [monto, setMonto] = useState<number>(0);
  const [resultado, setResultado] = useState<{ iva: number; isr: number } | null>(null);

  const handleSimular = () => {
    if (monto > 0) {
      setResultado(onSimulate(monto));
    }
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Simulador Fiscal Rápido</h2>
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700">Monto (MXN)</label>
        <input
          type="number"
          value={monto}
          onChange={(e) => setMonto(Number(e.target.value))}
          className="mt-1 block w-full border border-gray-300 rounded-md p-2"
        />
      </div>
      <button
        onClick={handleSimular}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Simular
      </button>
      {resultado && (
        <div className="mt-4 p-3 bg-gray-100 rounded">
          <p>IVA (16%): ${resultado.iva.toFixed(2)}</p>
          <p>ISR (10% estimado): ${resultado.isr.toFixed(2)}</p>
        </div>
      )}
    </div>
  );
}