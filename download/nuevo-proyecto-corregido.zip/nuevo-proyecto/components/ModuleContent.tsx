'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { MODULES } from './ERPLayout';

type ModuleKey = keyof typeof MODULES;

const GRID_POSITIONS: Partial<Record<ModuleKey, { col: number; row: number }>> = {
  dashboard:    { col: 1, row: 1 },
  descarga:     { col: 2, row: 1 },
  contabilidad: { col: 3, row: 1 },
  inventario:   { col: 4, row: 1 },
  bancos:       { col: 1, row: 2 },
  nomina:       { col: 2, row: 2 },
  crm:          { col: 3, row: 2 },
  compras:      { col: 4, row: 2 },
  tributario:   { col: 1, row: 3 },
  reportes:     { col: 2, row: 3 },
  usuarios:     { col: 3, row: 3 },
};

function ModuleCard({ mod, isCenter, selected }: { mod: any; isCenter?: boolean; selected?: boolean }) {
  return (
    <div
      className={`group text-left w-full p-4 rounded-xl border transition-all
        ${selected ? 'border-rose-500 ring-2 ring-rose-200 shadow-md' : 'border-gray-200 hover:border-gray-300 hover:shadow-md'}
        ${isCenter ? 'bg-gradient-to-br from-rose-600 to-red-700 text-white shadow-lg scale-105' : 'bg-white'}`}
    >
      <div className="flex items-center gap-3 mb-2">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl ${isCenter ? 'bg-white/20' : mod.bgColor}`}>
          {mod.icon}
        </div>
        <h3 className={`font-bold text-sm ${isCenter ? 'text-white' : mod.color}`}>{mod.name}</h3>
      </div>
      <p className={`text-xs leading-relaxed ${isCenter ? 'text-rose-100' : 'text-gray-500'}`}>
        {mod.description}
      </p>
    </div>
  );
}

export function ModulePlaceholder({ moduleKey }: { moduleKey: ModuleKey }) {
  const router = useRouter();
  const mod = MODULES[moduleKey];

  return (
    <div className="space-y-6">
      {/* Mapa de módulos */}
      <section>
        <h3 className="text-lg font-bold mb-1">Mapa de Módulos ERP</h3>
        <p className="text-xs text-gray-500 mb-4">11 módulos interconectados · Datos alimentados desde el portal SAT</p>
        <div className="relative bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
          <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 0 }}>
            {Object.values(MODULES).map((m) =>
              m.connects.map((targetKey) => {
                const from = GRID_POSITIONS[m.key as ModuleKey];
                const to = GRID_POSITIONS[targetKey];
                if (!from || !to) return null;
                const x1 = ((from.col - 0.5) / 4) * 100;
                const y1 = ((from.row - 0.5) / 3) * 100;
                const x2 = ((to.col - 0.5) / 4) * 100;
                const y2 = ((to.row - 0.5) / 3) * 100;
                return (
                  <line key={`${m.key}-${targetKey}`} x1={`${x1}%`} y1={`${y1}%`} x2={`${x2}%`} y2={`${y2}%`}
                    stroke="#f43f5e" strokeWidth="1.5" strokeDasharray="4 4" opacity="0.2" />
                );
              })
            )}
          </svg>
          <div className="relative grid grid-cols-4 gap-4" style={{ zIndex: 1 }}>
            {(['dashboard', 'descarga', 'contabilidad', 'inventario',
               'bancos', 'nomina', 'crm', 'compras',
               'tributario', 'reportes', 'usuarios'] as ModuleKey[]).map((key) => (
              <div key={key} className={key === 'usuarios' ? 'col-start-3' : ''}>
                <ModuleCard
                  mod={MODULES[key]}
                  isCenter={key === 'descarga'}
                  selected={key === moduleKey}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Entidades + conexiones */}
      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
          <div className="flex items-center gap-4 mb-5">
            <div className={`w-14 h-14 rounded-xl ${mod.bgColor} flex items-center justify-center text-3xl`}>
              {mod.icon}
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold">{mod.name}</h3>
              <p className="text-sm text-gray-500">{mod.description}</p>
            </div>
          </div>
          <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Entidades</h4>
          <div className="grid grid-cols-3 gap-2 mb-5">
            {mod.entities.map((e) => (
              <div key={e} className="px-3 py-2.5 bg-gray-50 border border-gray-100 rounded-lg text-sm text-gray-700 hover:bg-rose-50 hover:border-rose-200 transition cursor-pointer">
                <span className="text-xs text-gray-400 mr-1.5">▸</span>{e}
              </div>
            ))}
          </div>
          <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Módulos conectados</h4>
          <div className="flex flex-wrap gap-2">
            {mod.connects.map((k) => {
              const c = MODULES[k];
              return (
                <button key={k} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${c.bgColor} ${c.color} border border-transparent hover:border-current`}>
                  {c.icon} {c.name}
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-gradient-to-br from-rose-50 to-red-50 border border-rose-200 rounded-2xl p-5">
          <div className="text-3xl mb-3">🟢</div>
          <h4 className="font-bold text-gray-900 mb-1">¿Buscas descargar facturas?</h4>
          <p className="text-xs text-gray-600 leading-relaxed mb-4">
            Toda la información contable, fiscal y bancaria se alimenta desde el módulo de <strong>Descarga SAT</strong>.
            Ve ahí para conectarte al portal y bajar tus CFDIs masivamente.
          </p>
          <button
            onClick={() => router.push('/descarga-sat')}
            className="w-full px-4 py-2.5 bg-rose-600 text-white text-sm font-semibold rounded-lg hover:bg-rose-700 shadow-sm"
          >
            Ir a Descarga SAT →
          </button>
        </div>
      </div>
    </div>
  );
}