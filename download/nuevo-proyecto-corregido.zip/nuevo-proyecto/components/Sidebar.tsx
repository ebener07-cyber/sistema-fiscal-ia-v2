import Link from "next/link";

import {
  LayoutDashboard,
  Building2,
  Users,
  Receipt,
  Calculator,
  Wallet,
  BarChart3,
  TrendingUp,
} from "lucide-react";
export default function Sidebar() {
  return (
    <aside className="w-56 bg-[#071124] border-r border-white/10 p-6">
      <h1 className="text-xl font-bold text-purple-400 mb-10 whitespace-nowrap">
  Sistema Fiscal IA
</h1>

      <nav className="space-y-4">
        <Link
  href="/dashboard"
  className="flex items-center gap-3 text-white hover:text-purple-400"
>
  <LayoutDashboard size={18} />
  Dashboard
</Link>

<Link
  href="/empresas"
  className="flex items-center gap-3 text-gray-400 hover:text-purple-400"
>
  <Building2 size={18} />
  Empresas
</Link>

<Link
  href="/clientes"
  className="flex items-center gap-3 text-gray-400 hover:text-purple-400"
>
  <Users size={18} />
  Clientes
</Link>

<Link
  href="/facturacion"
  className="block text-gray-400 hover:text-purple-400 py-2"
>
  Facturación
</Link>

<Link
  href="/gastos"
  className="block text-gray-400 hover:text-purple-400 py-2"
>
  Gastos
</Link>

<Link
  href="/impuestos"
  className="block text-gray-400 hover:text-purple-400 py-2"
>
  Impuestos
</Link>

<Link
  href="/nomina"
  className="block text-gray-400 hover:text-purple-400 py-2"
>
  Nómina
</Link>

<Link
  href="/finanzas"
  className="flex items-center gap-3 text-purple-300 hover:text-purple-400 font-semibold"
>
  <TrendingUp size={18} />
  Reestructura Financiera
</Link>

<Link
  href="/reportes"
  className="block text-gray-400 hover:text-purple-400 py-2"
>
  Reportes
</Link>
      </nav>
    </aside>
  );
}