"use client";

import { useAuth } from "@/providers/AuthProvider";
import { useRouter } from "next/navigation";

export default function Navbar() {
  const { user, logout } = useAuth();
  const router = useRouter();

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  return (
    <div className="flex justify-between items-center mb-8">
      <input
        type="text"
        placeholder="Buscar..."
        className="bg-[#0B1227] border border-white/10 rounded-xl px-4 py-3 w-[400px] text-white"
      />

      <div className="flex items-center gap-4">
        <span className="text-gray-300">
          {user?.name || "Usuario"}
        </span>
        <button
          onClick={handleLogout}
          className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/50 rounded-lg text-red-400 text-sm transition"
        >
          Cerrar Sesión
        </button>
      </div>
    </div>
  );
}