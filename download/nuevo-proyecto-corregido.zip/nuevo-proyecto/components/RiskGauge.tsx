'use client';

export default function RiskGauge({
  riskLevel,
  percentage,
}: {
  riskLevel?: 'Bajo' | 'Medio' | 'Alto' | number;
  percentage?: number;
}) {
const numericRiskLevel = typeof riskLevel === 'number' ? riskLevel : (typeof percentage === 'number' ? percentage : 65);

  const riskColor =
    numericRiskLevel < 30 ? 'from-green-600 to-green-400' :
    numericRiskLevel < 60 ? 'from-yellow-600 to-yellow-400' :
    'from-red-600 to-red-400';

  const riskLabel =
    numericRiskLevel < 30 ? 'Bajo' :
    numericRiskLevel < 60 ? 'Medio' :
    'Alto';

  return (
    <div className="bg-gradient-to-br from-dark-card to-dark-bg border border-orange-500/20 rounded-2xl p-6 backdrop-blur-sm">
      <h3 className="text-white text-lg font-semibold mb-6">
        Riesgo Fiscal
      </h3>

      <div className="flex flex-col items-center">
        <div className="relative w-40 h-24">
          <svg viewBox="0 0 100 50" className="w-full h-full">
            <path
              d="M 10 50 A 40 40 0 0 1 90 50"
              stroke="#334155"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M 10 50 A 40 40 0 0 1 43.3 8"
              stroke="#10B981"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M 43.3 8 A 40 40 0 0 1 76.7 8"
              stroke="#EAB308"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M 76.7 8 A 40 40 0 0 1 90 50"
              stroke="#EF4444"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
            />
            <line
              x1="50"
              y1="50"
            x2={50 + 35 * Math.cos((numericRiskLevel / 100) * Math.PI - Math.PI)}
              y2={50 - 35 * Math.sin((numericRiskLevel / 100) * Math.PI - Math.PI)}
              stroke="white"
              strokeWidth="2"
              strokeLinecap="round"
            />
            <circle cx="50" cy="50" r="3" fill="white" />
          </svg>
        </div>

        <div className="mt-4 text-center">
          <p className={`text-4xl font-bold bg-gradient-to-r ${riskColor} bg-clip-text text-transparent`}>
            {numericRiskLevel}%
          </p>
          <p className={`text-sm font-semibold ${
            numericRiskLevel < 30 ? 'text-green-400' :
            numericRiskLevel < 60 ? 'text-yellow-400' :
            'text-red-400'
          }`}>
            {riskLabel}
          </p>
        </div>

        <div className="mt-6 w-full space-y-2 text-sm">
          <div className="flex justify-between items-center">
            <span className="text-gray-400">Cumplimiento SAT</span>
            <span className="text-green-400 font-semibold">80%</span>
          </div>
          <div className="w-full bg-dark-bg rounded-full h-2 overflow-hidden">
            <div className="bg-green-500 h-full rounded-full" style={{ width: '80%' }} />
          </div>

          <div className="flex justify-between items-center mt-4">
            <span className="text-gray-400">Documentación</span>
            <span className="text-yellow-400 font-semibold">60%</span>
          </div>
          <div className="w-full bg-dark-bg rounded-full h-2 overflow-hidden">
            <div className="bg-yellow-500 h-full rounded-full" style={{ width: '60%' }} />
          </div>

          <div className="flex justify-between items-center mt-4">
            <span className="text-gray-400">Deducciones</span>
            <span className="text-orange-400 font-semibold">50%</span>
          </div>
          <div className="w-full bg-dark-bg rounded-full h-2 overflow-hidden">
            <div className="bg-orange-500 h-full rounded-full" style={{ width: '50%' }} />
          </div>
        </div>
      </div>
    </div>
  );
}