export default function ClienteTable() {
  return (
    <div className="bg-[#0b1635] border border-purple-900 rounded-2xl p-6">
      <table className="w-full">
        <thead>
          <tr>
            <th className="text-left">Nombre</th>
            <th className="text-left">RFC</th>
            <th className="text-left">Correo</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>Juan Pérez</td>
            <td>PEPJ900101XXX</td>
            <td>juan@email.com</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}