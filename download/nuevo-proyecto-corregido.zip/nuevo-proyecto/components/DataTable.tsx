export default function DataTable({
  empresas,
}: {
  empresas: any[];
}) {
  return (
    <div className="bg-[#0F172A] border border-purple-500/20 rounded-2xl p-6">
      <h2 className="text-xl font-semibold mb-4">
        Empresas Registradas
      </h2>

      <table className="w-full">
        <thead>
          <tr className="text-left text-gray-400 border-b border-white/10">
            <th className="pb-3">Empresa</th>
            <th className="pb-3">RFC</th>
            <th className="pb-3">Estado</th>
          </tr>
        </thead>

        <tbody>
  {empresas.map((empresa) => (
    <tr
      key={empresa.id}
      className="border-b border-white/5"
    >
      <td className="py-3">
        {empresa.nombre}
      </td>

      <td className="py-3">
        {empresa.rfc}
      </td>

      <td className="py-3 text-green-400">
        Activa
      </td>
    </tr>
  ))}
</tbody>
      </table>
    </div>
  );
}