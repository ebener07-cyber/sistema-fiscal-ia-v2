# TODO - Revisión completa y corrección de errores

## Paso 1: Auditoría de SAT/CFDI
- [ ] Revisar `app/api/descarga-sat/*/route.ts`
- [ ] Revisar `app/api/procesar-xmls/route.ts`
- [ ] Revisar `lib/cfdi-parser.ts`, `lib/sat.ts`, `lib/sat/index.ts`, `src/lib/extractXMLsFromZIP.ts`

## Paso 2: Corregir errores de compilación
- [ ] Asegurar que existan/importen funciones usadas (ej. `validateCFDI`)
- [ ] Eliminar duplicidad/inconsistencia entre implementaciones de `extractXMLsFromZIP`
- [ ] Alinear interfaces/propiedades entre rutas y Prisma (`schema.prisma`)

## Paso 3: Unificar flujo SAT
- [ ] Verificar que rutas usen el mismo service SAT (real vs mock)

## Paso 4: Verificación
- [ ] Ejecutar `npx eslint -c eslint.config.mjs .`
- [ ] Ejecutar `npx next build`
- [ ] Ejecutar nuevamente lint hasta quedar verde

