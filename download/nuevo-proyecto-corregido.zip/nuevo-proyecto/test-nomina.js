async function test() {
  // Buscar facturas tipo N (nómina)
  const res = await fetch('http://localhost:3000/api/facturas?tipoComprobante=N');
  const data = await res.json();
  console.log('Facturas tipo N (nómina):', data.data?.length || 0);
  
  if (data.data?.length > 0) {
    console.log('Primeras 3:', JSON.stringify(data.data.slice(0, 3), null, 2));
  }
  
  // También buscar todas las facturas para ver qué tipos hay
  const allRes = await fetch('http://localhost:3000/api/facturas?limit=100');
  const allData = await allRes.json();
  const tipos = {};
  allData.data?.forEach(f => {
    tipos[f.tipoComprobante || 'sin_tipo'] = (tipos[f.tipoComprobante || 'sin_tipo'] || 0) + 1;
  });
  console.log('\nTipos de comprobantes en BD:', tipos);
}

test().catch(console.error);