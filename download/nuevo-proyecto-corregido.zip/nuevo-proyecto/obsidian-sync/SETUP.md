# Setup de Obsidian + Graphify

Este script inicializa la sincronización entre Obsidian y Graphify.

## Pasos de Setup

### 1. Ejecutar inicialización

```bash
npx ts-node obsidian-sync/setup.ts
```

### 2. Abrir Obsidian

1. Abre Obsidian
2. Click en "Abrir vault"
3. Selecciona la carpeta `obsidian-vault/`

### 3. Empezar a editar

Edita los archivos en Obsidian y luego ejecuta:

```bash
npx ts-node obsidian-sync/sync.ts
```

### 4. (Opcional) Sincronización automática

Para sincronización en tiempo real:

```bash
npx ts-node obsidian-sync/watch.ts
```

## Estructura Creada

```
nuevo-proyecto/
├── obsidian-vault/     ← Abrir en Obsidian
│   ├── 01-Contexto/
│   ├── 02-Entidades/
│   ├── 03-Relaciones/
│   ├── 04-Componentes/
│   ├── 05-Rutas/
│   ├── 06-Mapa-del-Sistema/
│   ├── 07-Sesiones/
│   └── 08-Dependencias/
├── obsidian-sync/      ← Scripts de sincronización
│   ├── sync.ts
│   ├── watch.ts
│   └── sync-config.json
└── graphify/           ← Carpeta original (se mantiene)
    ├── contexto.md
    ├── entidades.md
    └── ...
```