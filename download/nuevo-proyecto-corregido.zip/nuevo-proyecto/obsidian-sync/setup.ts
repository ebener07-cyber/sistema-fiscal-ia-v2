import fs from 'fs';
import path from 'path';
import { syncToObsidian } from './sync';

interface SyncConfig {
  mappings: { obsidian: string; graphify: string; description: string }[];
  obsidianVault: string;
  graphifyFolder: string;
}

function loadConfig(): SyncConfig {
  const configPath = path.join(process.cwd(), 'obsidian-sync', 'sync-config.json');
  const configData = fs.readFileSync(configPath, 'utf-8');
  return JSON.parse(configData);
}

function createDirectory(dirPath: string): void {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
    console.log(`  ✓ Creado: ${dirPath}`);
  }
}

function createObsidianStructure(): void {
  const config = loadConfig();
  const basePath = process.cwd();
  const vaultPath = path.join(basePath, config.obsidianVault);

  console.log('\n📁 Creando estructura del vault...\n');

  // Crear carpetas base
  const folders = [
    '01-Contexto',
    '02-Entidades',
    '03-Relaciones',
    '04-Componentes',
    '05-Rutas',
    '06-Mapa-del-Sistema',
    '07-Sesiones',
    '08-Dependencias',
  ];

  folders.forEach((folder) => {
    createDirectory(path.join(vaultPath, folder));
  });

  // Crear carpeta .obsidian para configuración de Obsidian
  createDirectory(path.join(vaultPath, '.obsidian'));

  console.log('\n✅ Estructura del vault creada\n');
}

function initializeSync(): void {
  console.log('🔄 Inicializando sincronización...\n');

  // Copiar archivos existentes de graphify al vault
  syncToObsidian();

  console.log('✅ Sincronización inicializada\n');
}

function printInstructions(): void {
  console.log(`
╔════════════════════════════════════════════════════════════════╗
║           OBSIDIAN + GRAPHIFY INTEGRATION SETUP               ║
╠════════════════════════════════════════════════════════════════╣
║                                                                ║
║  1. Abre Obsidian                                             ║
║                                                                ║
║  2. Click en "Abrir vault" → Selecciona:                      ║
║     nuevo-proyecto/obsidian-vault                             ║
║                                                                ║
║  3. Edita los archivos en Obsidian                            ║
║                                                                ║
║  4. Para sincronizar a graphify/:                              ║
║     npx ts-node obsidian-sync/sync.ts to-graphify             ║
║                                                                ║
║  5. Para sincronización en tiempo real:                        ║
║     npx ts-node obsidian-sync/watch.ts                        ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
`);
}

function main(): void {
  console.log('\n🚀 Setup de Obsidian + Graphify\n');

  createObsidianStructure();
  initializeSync();
  printInstructions();
}

main();