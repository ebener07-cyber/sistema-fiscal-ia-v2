import fs from 'fs';
import path from 'path';
import { syncBidirectional } from './sync';

/**
 * Watcher que monitorea cambios en ambas carpetas
 * y sincroniza automáticamente
 */

interface SyncConfig {
  mappings: { obsidian: string; graphify: string }[];
  obsidianVault: string;
  graphifyFolder: string;
}

function loadConfig(): SyncConfig {
  const configPath = path.join(process.cwd(), 'obsidian-sync', 'sync-config.json');
  const configData = fs.readFileSync(configPath, 'utf-8');
  return JSON.parse(configData);
}

// Archivos monitoreados
const watchedFiles: Map<string, number> = new Map();

function getConfig(): SyncConfig {
  return loadConfig();
}

function getWatchedFiles(config: SyncConfig): string[] {
  const basePath = process.cwd();
  const files: string[] = [];

  config.mappings.forEach(({ obsidian, graphify }) => {
    files.push(path.join(basePath, config.obsidianVault, obsidian));
    files.push(path.join(basePath, config.graphifyFolder, graphify));
  });

  return files;
}

function checkForChanges(): void {
  const config = getConfig();
  const files = getWatchedFiles(config);
  let hasChanges = false;

  files.forEach((filePath) => {
    if (!fs.existsSync(filePath)) return;

    const stat = fs.statSync(filePath);
    const mtime = stat.mtimeMs;
    const lastMtime = watchedFiles.get(filePath);

    if (lastMtime !== undefined && Math.abs(mtime - lastMtime) > 100) {
      console.log(`\n📝 Cambio detectado: ${path.basename(filePath)}`);
      hasChanges = true;
    }

    watchedFiles.set(filePath, mtime);
  });

  if (hasChanges) {
    console.log('🔄 Sincronizando...\n');
    syncBidirectional();
  }
}

function initializeWatcher(): void {
  const config = getConfig();
  const files = getWatchedFiles(config);

  console.log('👁 Inicializando watcher...\n');

  files.forEach((filePath) => {
    if (fs.existsSync(filePath)) {
      const stat = fs.statSync(filePath);
      watchedFiles.set(filePath, stat.mtimeMs);
      console.log(`  ✓ Monitoreando: ${path.basename(filePath)}`);
    }
  });

  console.log('\n✅ Watcher activo. Presiona Ctrl+C para salir.\n');
}

function startWatching(): void {
  initializeWatcher();

  // Verificar cambios cada 2 segundos
  setInterval(checkForChanges, 2000);
}

startWatching();