# Obsidian Graphify Sync

Sistema de sincronización bidireccional entre Obsidian y Graphify.

## Estructura

```
obsidian-vault/          ← Abrir esta carpeta en Obsidian como vault
├── 01-Contexto/         → graphify/contexto.md
├── 02-Entidades/        → graphify/entidades.md
├── 03-Relaciones/       → graphify/relaciones.md
├── 04-Componentes/      → graphify/componentes.md
├── 05-Rutas/            → graphify/rutas.md
├── 06-Mapa-del-Sistema/ → graphify/mapa_sistema.md
├── 07-Sesiones/         → graphify/sesiones.md
└── 08-Dependencias/     → graphify/dependencias.md
```

## Uso

### Opción 1: Script de sincronización (tiempo real)

```bash
# En terminal PowerShell
npx ts-node obsidian-sync/watch.ts
```

### Opción 2: Sincronización manual

```bash
npx ts-node obsidian-sync/sync.ts
```

### Opción 3: One-time setup

1. Abrir Obsidian
2. Seleccionar "Abrir vault" → elegir `obsidian-vault/`
3. Editar archivos en Obsidian
4. Ejecutar `sync.ts` para sincronizar a graphify/

## Configuración

El archivo `sync-config.json` contiene el mapeo entre archivos:

```json
{
  "mappings": [
    {
      "obsidian": "01-Contexto/Arquitectura.md",
      "graphify": "contexto.md"
    }
  ]
}
```