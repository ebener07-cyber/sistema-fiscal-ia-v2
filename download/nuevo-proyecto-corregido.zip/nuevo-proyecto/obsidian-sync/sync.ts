import fs from 'fs';
import path from 'path';

interface SyncConfig {
  mappings: {
    obsidian: string;
    graphify: string;
    description: string;
  }[];
  obsidianVault: string;
  graphifyFolder: string;
}

/**
 * Carga la configuración de sincronización
 */
function loadConfig(): SyncConfig {
  const configPath = path.join(process.cwd(), 'obsidian-sync', 'sync-config.json');
  const configData = fs.readFileSync(configPath, 'utf-8');
  return JSON.parse(configData);
}

/**
 * Copia contenido de un archivo a otro
 */
function copyFileSync(source: string, dest: string): void {
  const content = fs.readFileSync(source, 'utf-8');
  fs.writeFileSync(dest, content, 'utf-8');
  console.log(`✓ Sincronizado: ${path.basename(source)} → ${path.basename(dest)}`);
}

/**
 * Sincroniza Graphify → Obsidian (para inicializar el vault)
 */
export function syncToObsidian(): void {
  const config = loadConfig();
  const basePath = process.cwd();

  console.log('\n🔄 Sincronizando Graphify → Obsidian Vault\n');

  config.mappings.forEach(({ obsidian, graphify }) => {
    const sourcePath = path.join(basePath, config.graphifyFolder, graphify);
    const destPath = path.join(basePath, config.obsidianVault, obsidian);

    // Crear directorio destino si no existe
    const destDir = path.dirname(destPath);
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }

    if (fs.existsSync(sourcePath)) {
      copyFileSync(sourcePath, destPath);
    } else {
      console.log(`⚠ No encontrado: ${graphify}`);
    }
  });

  console.log('\n✅ Sincronización Graphify → Obsidian completada\n');
}

/**
 * Sincroniza Obsidian → Graphify (para actualizar el proyecto)
 */
export function syncToGraphify(): void {
  const config = loadConfig();
  const basePath = process.cwd();

  console.log('\n🔄 Sincronizando Obsidian Vault → Graphify\n');

  config.mappings.forEach(({ obsidian, graphify }) => {
    const sourcePath = path.join(basePath, config.obsidianVault, obsidian);
    const destPath = path.join(basePath, config.graphifyFolder, graphify);

    if (fs.existsSync(sourcePath)) {
      copyFileSync(sourcePath, destPath);
    } else {
      console.log(`⚠ No encontrado en vault: ${obsidian}`);
    }
  });

  console.log('\n✅ Sincronización Obsidian → Graphify completada\n');
}

/**
 * Sincronización bidireccional (más reciente gana)
 */
export function syncBidirectional(): void {
  const config = loadConfig();
  const basePath = process.cwd();

  console.log('\n🔄 Sincronización bidireccional\n');

  config.mappings.forEach(({ obsidian, graphify }) => {
    const obsidianPath = path.join(basePath, config.obsidianVault, obsidian);
    const graphifyPath = path.join(basePath, config.graphifyFolder, graphify);

    const obsidianExists = fs.existsSync(obsidianPath);
    const graphifyExists = fs.existsSync(graphifyPath);

    if (!obsidianExists && !graphifyExists) {
      console.log(`⚠ No existe en ningún lado: ${graphify}`);
      return;
    }

    if (!obsidianExists) {
      // Solo existe en graphify, copiar a obsidian
      const destDir = path.dirname(obsidianPath);
      if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
      }
      copyFileSync(graphifyPath, obsidianPath);
      return;
    }

    if (!graphifyExists) {
      // Solo existe en obsidian, copiar a graphify
      copyFileSync(obsidianPath, graphifyPath);
      return;
    }

    // Ambos existen, comparar timestamps
    const obsidianStat = fs.statSync(obsidianPath);
    const graphifyStat = fs.statSync(graphifyPath);

    if (obsidianStat.mtime > graphifyStat.mtime) {
      // Obsidian es más reciente
      copyFileSync(obsidianPath, graphifyPath);
    } else {
      // Graphify es más reciente
      copyFileSync(graphifyPath, obsidianPath);
    }
  });

  console.log('\n✅ Sincronización bidireccional completada\n');
}

// CLI
const args = process.argv.slice(2);
const direction = args[0] || 'bidirectional';

switch (direction) {
  case 'to-obsidian':
    syncToObsidian();
    break;
  case 'to-graphify':
    syncToGraphify();
    break;
  case 'bidirectional':
  default:
    syncBidirectional();
}