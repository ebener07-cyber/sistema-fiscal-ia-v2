/**
 * Script para sincronizar recibos de nómina desde la tabla factura
 * hacia la tabla reciboNomina
 * 
 * Ejecutar con: npx ts-node sync-nomina.ts
 */

import prisma from './lib/prisma';

async function syncRecibosNomina() {
  console.log('🔄 Sincronizando recibos de nómina...\n');

  try {
    // 1. Obtener todas las facturas que son complementos de nómina
    const facturasNomina = await prisma.factura.findMany({
      where: {
        complementoNomina: true,
        receptorRfc: { not: null },
      },
      select: {
        id: true,
        uuid: true,
        folio: true,
        serie: true,
        fecha: true,
        monto: true,
        subtotal: true,
        totalImpuestos: true,
        empresaId: true,
        receptorRfc: true,
        receptorNombre: true,
        emisorRfc: true,
        emisorNombre: true,
        xmlOriginal: true,
      },
    });

    console.log(`📋 Facturas de nómina encontradas: ${facturasNomina.length}`);

    let sincronizados = 0;
    let yaExistian = 0;
    let errores = 0;

    for (const factura of facturasNomina) {
      // Saltar facturas sin RFC de receptor (no se puede ubicar al empleado)
      if (!factura.receptorRfc) continue;
      try {
        // Verificar si ya existe el recibo
        const existente = await prisma.reciboNomina.findFirst({
          where: { uuid: factura.uuid },
        });

        if (existente) {
          yaExistian++;
          continue;
        }

        // Buscar o crear empleado
        let empleado = await prisma.empleado.findFirst({
          where: { rfc: factura.receptorRfc, empresaId: factura.empresaId },
        });

        if (!empleado) {
          empleado = await prisma.empleado.create({
            data: {
              nombre: factura.receptorNombre || 'Empleado sin nombre',
              rfc: factura.receptorRfc || 'XAXX000000XXX',
              empresaId: factura.empresaId,
              puesto: 'Empleado',
              status: 'Activo',
            },
          });
          console.log(`  ➕ Empleado creado: ${empleado.nombre}`);
        }

        // Extraer datos del XML
        const xmlContent = factura.xmlOriginal || '';
        
        // Extraer fecha de pago
        const fechaPagoMatch = xmlContent.match(/FechaPago="([^"]*)"/);
        const fechaPago = fechaPagoMatch ? new Date(fechaPagoMatch[1]) : factura.fecha;
        
        // Extraer percepciones y deducciones
        const percepMatch = xmlContent.match(/TotalPercepciones="([^"]*)"/);
        const deduMatch = xmlContent.match(/TotalDeducciones="([^"]*)"/);
        
        const totalPercepciones = percepMatch ? parseFloat(percepMatch[1]) : factura.subtotal;
        const totalDeducciones = deduMatch ? parseFloat(deduMatch[1]) : factura.totalImpuestos;
        
        // Extraer ISR e IMSS
        const isrMatch = xmlContent.match(/<nomina12:ISR[^>]*Importe="([^"]*)"/) || xmlContent.match(/<nomina:ISR[^>]*Importe="([^"]*)"/);
        const imssMatch = xmlContent.match(/<nomina12:SeguridadSocial[^>]*Importe="([^"]*)"/) || xmlContent.match(/<nomina:SeguridadSocial[^>]*Importe="([^"]*)"/);
        
        const isr = isrMatch ? parseFloat(isrMatch[1]) : 0;
        const imss = imssMatch ? parseFloat(imssMatch[1]) : 0;

        // Crear recibo de nómina
        await prisma.reciboNomina.create({
          data: {
            folio: factura.folio || 'S/F',
            serie: factura.serie,
            fecha: factura.fecha,
            fechaPago,
            periodo: 'quincena',
            anio: fechaPago.getFullYear(),
            mes: fechaPago.getMonth() + 1,
            quincena: 0,
            salarioPercibido: factura.monto,
            totalPercepciones,
            totalDeducciones,
            neto: factura.monto - totalDeducciones,
            isr,
            imss,
            infonavit: 0,
            uuid: factura.uuid,
            xmlContent,
            estado: 'timbrado',
            empleadoId: empleado.id,
            empresaId: factura.empresaId,
          },
        });

        sincronizados++;
        console.log(`  ✅ Sincronizado: ${factura.folio} - ${factura.receptorNombre} - $${factura.monto}`);

      } catch (error: any) {
        errores++;
        console.error(`  ❌ Error con factura ${factura.folio}:`, error.message);
      }
    }

    console.log('\n📊 RESUMEN:');
    console.log(`✅ Sincronizados: ${sincronizados}`);
    console.log(`⏭️  Ya existían: ${yaExistian}`);
    console.log(`❌ Errores: ${errores}`);

    // Mostrar totales
    const totalRecibos = await prisma.reciboNomina.count();
    const totalNeto = await prisma.reciboNomina.aggregate({
      _sum: { neto: true },
    });

    console.log(`\n💰 Total recibos en BD: ${totalRecibos}`);
    console.log(`💵 Total neto: $${(totalNeto._sum.neto || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}`);

  } catch (error: any) {
    console.error('❌ Error general:', error);
  } finally {
    await prisma.$disconnect();
  }
}

syncRecibosNomina();