import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Rutas que requieren autenticación
const protectedRoutes = ["/dashboard", "/clientes", "/empresas", "/facturacion", "/finanzas", "/gastos", "/ia-fiscal", "/impuestos", "/imss", "/infonavit", "/nomina", "/proveedores", "/ptu", "/reportes", "/sat"];

// Rutas públicas (no requieren auth)
const publicRoutes = ["/login", "/api/auth/login", "/api/auth/register"];

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Permitir rutas públicas
  if (publicRoutes.some((route) => pathname.startsWith(route))) {
    return NextResponse.next();
  }

  // Verificar si es una ruta protegida
  const isProtectedRoute = protectedRoutes.some((route) =>
    pathname.startsWith(route)
  );

  if (!isProtectedRoute) {
    return NextResponse.next();
  }

  // Verificar token
  const token = request.cookies.get("auth-token")?.value;

  if (!token) {
    // Redirigir a login
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Verificar si el token es válido (decodificar base64)
  try {
    const payload = JSON.parse(
      Buffer.from(token, "base64").toString()
    );

    // Verificar expiración
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      // Token expirado, redirigir a login
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("expired", "true");
      return NextResponse.redirect(loginUrl);
    }

    // Token válido, permitir acceso
    return NextResponse.next();
  } catch {
    // Token inválido, redirigir a login
    const loginUrl = new URL("/login", request.url);
    return NextResponse.redirect(loginUrl);
  }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!api|_next/static|_next/image|favicon.ico).*)",
  ],
};
