const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const count = await prisma.factura.count();
  console.log('Facturas en BD:', count);
  
  const sample = await prisma.factura.findFirst({
    select: { uuid: true, folio: true, fecha: true }
  });
  console.log('Ejemplo:', sample);
  
  await prisma.$disconnect();
}

main().catch(console.error);