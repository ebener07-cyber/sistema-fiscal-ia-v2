import { SATDescargaMasiva } from 'sat-descarga-masiva';

async function testSAT() {
  console.log(' Probando conexión con SAT...');
  
  const client = new SATDescargaMasiva({
    rfc: 'AL0980508ID6',
    password: 'Mexi1967', // ← CAMBIA ESTO
  });

  try {
    console.log('🔐 Autenticando...');
    await client.autenticar();
    console.log('✅ Autenticación exitosa!');
    
    console.log('📤 Probando solicitud de descarga...');
    const hoy = new Date();
    const hace30Dias = new Date();
    hace30Dias.setDate(hoy.getDate() - 30);
    
    const solicitudId = await client.solicitarDescarga({
      fechaInicial: hace30Dias.toISOString().split('T')[0],
      fechaFinal: hoy.toISOString().split('T')[0],
      tipoSolicitud: 'recibidos',
    });
    
    console.log('✅ Solicitud creada:', solicitudId);
  } catch (error: any) {
    console.error('❌ Error:', error.message);
  }
}

testSAT();