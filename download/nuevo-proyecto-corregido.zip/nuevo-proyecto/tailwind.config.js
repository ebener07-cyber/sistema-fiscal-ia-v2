/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        'dark-bg': '#040816',
        'dark-card': '#0F172A',
        'dark-sidebar': '#071124',
        'isr-purple': '#8B5CF6',
        'iva-blue': '#3B82F6',
        'ptu-green': '#10B981',
        'imss-orange': '#F97316',
        'fiscal-warning': '#EF4444',
        'isr-light': '#A78BFA',
        'iva-light': '#60A5FA',
        'ptu-light': '#6EE7B7',
        'imss-light': '#FB923C',
        'isr-dark': '#7C3AED',
        'iva-dark': '#1D4ED8',
        'ptu-dark': '#059669',
        'imss-dark': '#EA580C',
      },
      backgroundImage: {
        'isr-gradient': 'linear-gradient(135deg, #7C3AED 0%, #A78BFA 100%)',
        'iva-gradient': 'linear-gradient(135deg, #1D4ED8 0%, #60A5FA 100%)',
        'ptu-gradient': 'linear-gradient(135deg, #059669 0%, #6EE7B7 100%)',
        'imss-gradient': 'linear-gradient(135deg, #EA580C 0%, #FB923C 100%)',
      },
    },
  },
  plugins: [],
}