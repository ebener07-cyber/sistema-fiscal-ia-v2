'use client';

import { useState } from 'react';
import { ERPLayout } from '@/components/ERPLayout';

export default function ComprasPage() {
  const [filtro, setFiltro] = useState<'todas' | 'pendientes' | 'pagadas'>('todas');

  const compras = [
    { id: 'COMP-001', proveedor: 'Telmex S.A.B.', rfc: 'TLM910101ABC', folio: 'B-5678', fecha: '2025-11-27', monto: 4500, vencimiento: '2025-12-15', status: 'pendiente' },
    { id: 'COMP-002', proveedor: 'Office Depot', rfc: 'OFD910101XYZ', folio: 'B-9012', fecha: '2025-11-25', monto: 1280, vencimiento: '2025-12-10', status: 'pagada' },
    { id: 'COMP-003', proveedor: 'Amazon México', rfc: 'AME170101DEF', folio: 'B-3456', fecha: '2025-11-20', monto: 8750, vencimiento: '2025-12-05', status: 'pendiente' },
    { id: 'COMP-004', proveedor: 'CFE', rfc: 'CFE370101GHI', folio: 'B-7890', fecha: '2025-11-15', monto: 2340, vencimiento: '2025-11-30', status: 'vencida' },
    { id: 'COMP-005', proveedor: 'Telmex S.A.B.', rfc: 'TLM910101ABC', folio: 'B-1234', fecha: '2025-11-10', monto: 4500, vencimiento: '2025-11-25', status: 'pagada' },
  ];

  const comprasFiltradas = compras.filter(c => 
    filtro === 'todas' ? true : c.status === filtro
  );

  const totalPendiente = compras.filter(c => c.status === 'pendiente').reduce((s, c) => s + c.monto, 0);
  const totalPagado = compras.filter(c => c.status === 'pagada').reduce((s, c) => s + c.monto, 0);
  const totalVencido = compras.filter(c => c.status === 'vencida').reduce((s, c) => s + c.monto, 0);

  return (
    <ERPLayout moduleKey="compras">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Compras</h3>
            <p className="text-sm text-gray-500">Cuentas por pagar generadas desde CFDI de gastos descargados del SAT</p>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
               Reporte
            </button>
            <button className="px-4 py-2 bg-orange-600 text-white rounded-lg text-sm font-medium hover:bg-orange-700">
              + Nueva Compra
            </button>
          </div>
        </div>

        {/* Filtros */}
        <div className="flex gap-2">
          {[
            { key: 'todas', label: 'Todas' },
            { key: 'pendientes', label: 'Pendientes' },
            { key: 'pagadas', label: 'Pagadas' },
          ].map((f) => (
            <button
              key={f.key}
              onClick={() => setFiltro(f.key as typeof filtro)}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition ${
                filtro === f.key 
                  ? 'bg-orange-600 text-white' 
                  : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white rounded-xl border-l-4 border-amber-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Por Pagar</p>
            <p className="text-2xl font-bold text-amber-600 mt-1">${totalPendiente.toLocaleString('es-MX')}</p>
            <p className="text-xs text-gray-400 mt-1">{compras.filter(c => c.status === 'pendiente').length} facturas</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-emerald-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Pagadas</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">${totalPagado.toLocaleString('es-MX')}</p>
            <p className="text-xs text-gray-400 mt-1">{compras.filter(c => c.status === 'pagada').length} facturas</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-red-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Vencidas</p>
            <p className="text-2xl font-bold text-red-600 mt-1">${totalVencido.toLocaleString('es-MX')}</p>
            <p className="text-xs text-gray-400 mt-1">{compras.filter(c => c.status === 'vencida').length} facturas</p>
          </div>
        </div>

        {/* Tabla */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm">
          <div className="p-5 border-b border-gray-200">
            <h3 className="font-bold text-gray-900">Cuentas por Pagar</h3>
            <p className="text-xs text-gray-500 mt-0.5">Facturas de proveedores descargadas del SAT</p>
          </div>
          <table className="w-full">
            <thead>
              <tr className="text-xs text-gray-500 border-b border-gray-200 bg-gray-50">
                <th className="text-left px-5 py-3 font-medium">ID</th>
                <th className="text-left px-3 py-3 font-medium">Proveedor</th>
                <th className="text-left px-3 py-3 font-medium">Folio</th>
                <th className="text-left px-3 py-3 font-medium">Fecha</th>
                <th className="text-right px-3 py-3 font-medium">Monto</th>
                <th className="text-left px-3 py-3 font-medium">Vencimiento</th>
                <th className="text-left px-5 py-3 font-medium">Status</th>
                <th className="text-left px-5 py-3 font-medium">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {comprasFiltradas.map((compra) => (
                <tr key={compra.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                  <td className="px-5 py-3 font-mono text-orange-600 font-semibold">{compra.id}</td>
                  <td className="px-3 py-3">
                    <p className="text-gray-900 font-medium">{compra.proveedor}</p>
                    <p className="text-xs text-gray-500 font-mono">{compra.rfc}</p>
                  </td>
                  <td className="px-3 py-3 font-mono text-gray-700">{compra.folio}</td>
                  <td className="px-3 py-3 text-gray-600 text-xs">{compra.fecha}</td>
                  <td className="px-3 py-3 text-right font-semibold text-gray-900">
                    ${compra.monto.toLocaleString('es-MX')}
                  </td>
                  <td className="px-3 py-3 text-gray-600 text-xs">{compra.vencimiento}</td>
                  <td className="px-5 py-3">
                    <span className={`px-2 py-1 text-xs font-semibold rounded ${
                      compra.status === 'pagada' ? 'bg-emerald-100 text-emerald-700' :
                      compra.status === 'pendiente' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {compra.status.charAt(0).toUpperCase() + compra.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    {compra.status === 'pendiente' && (
                      <button className="text-xs text-orange-600 hover:text-orange-800 font-medium">
                        Pagar →
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </ERPLayout>
  );
}