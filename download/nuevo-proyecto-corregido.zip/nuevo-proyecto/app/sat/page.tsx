export default function SATPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white">SAT</h1>
      <p className="mt-4 text-gray-400">Portal SAT en desarrollo.</p>
    </div>
  );
}