'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

const fmt = (n: number) =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);

const TIPOS = ['etf', 'fondo_deuda', 'bien_raiz', 'cesion', 'otro'];

export default function InversionesPage() {
  const [empresaId, setEmpresaId] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<any>({});

  useEffect(() => {
    const id = localStorage.getItem('empresaId') || '';
    if (!id) {
      setLoading(false);
      return;
    }
    setEmpresaId(id);
    cargar(id);
  }, []);

  const cargar = (id: string) => {
    fetch(`/api/finanzas/inversiones?empresaId=${id}`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await fetch('/api/finanzas/inversiones', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, ...form }),
    });
    const d = await r.json();
    if (d.error) alert(d.error);
    else {
      setShowForm(false);
      setForm({});
      cargar(empresaId);
    }
  };

  if (loading) return <div className="p-8">Cargando...</div>;
  if (!data) return <div className="p-8">Sin datos.</div>;

  const colorGanancia = data.ganancia >= 0 ? 'text-green-600' : 'text-red-600';

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto">
        <Link href="/finanzas" className="text-blue-600 text-sm">← Volver a Finanzas</Link>
        <h1 className="text-3xl font-bold text-gray-900 mt-1 mb-2">Inversiones</h1>
        <p className="text-gray-600 mb-6">
          Convierte tu flujo de caja liberado en activos. Diversifica en ETFs, fondos de deuda,
          bienes raíces y más.
        </p>

        {/* Resumen */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Invertido</div>
            <div className="text-xl font-bold text-gray-900 mt-1">{fmt(data.totalInvertido)}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Valor Actual</div>
            <div className="text-xl font-bold text-blue-600 mt-1">{fmt(data.valorActual)}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Ganancia/Pérdida</div>
            <div className={`text-xl font-bold ${colorGanancia} mt-1`}>{fmt(data.ganancia)}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Rendimiento</div>
            <div className={`text-xl font-bold ${colorGanancia} mt-1`}>
              {data.pctRendimiento.toFixed(2)}%
            </div>
          </div>
        </div>

        {/* Lista */}
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-xl font-bold text-gray-900">Cartera</h2>
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            + Nueva inversión
          </button>
        </div>

        <div className="bg-white rounded-lg shadow divide-y">
          {data.inversiones.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              Sin inversiones. Tu primera meta: completar fondo de emergencia y pagar deudas
              agresivas antes de invertir.
            </div>
          ) : (
            data.inversiones.map((inv: any) => {
              const ganancia = inv.valorActual - inv.montoInvertido;
              const pct = inv.montoInvertido > 0 ? (ganancia / inv.montoInvertido) * 100 : 0;
              return (
                <div key={inv.id} className="p-4 flex justify-between items-center">
                  <div>
                    <div className="font-semibold capitalize">
                      {inv.tipo.replace(/_/g, ' ')} · {inv.nombre}
                    </div>
                    <div className="text-xs text-gray-500">
                      Invertido: {fmt(inv.montoInvertido)} ·{' '}
                      {inv.rendimientoAnual ? `${inv.rendimientoAnual}% anual` : 'Sin rendimiento'}
                      {inv.plazoMeses ? ` · ${inv.plazoMeses} meses` : ''}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold">{fmt(inv.valorActual)}</div>
                    <div className={`text-xs ${ganancia >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {ganancia >= 0 ? '+' : ''}
                      {fmt(ganancia)} ({pct.toFixed(1)}%)
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold">Nueva inversión</h3>
                <button onClick={() => setShowForm(false)} className="text-gray-500">✕</button>
              </div>
              <form onSubmit={submit} className="space-y-3">
                <select
                  required
                  value={form.tipo || ''}
                  onChange={(e) => setForm({ ...form, tipo: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="">Tipo...</option>
                  {TIPOS.map((t) => (
                    <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>
                  ))}
                </select>
                <input
                  required
                  placeholder="Nombre (ej. ETF S&P 500)"
                  value={form.nombre || ''}
                  onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    required
                    type="number"
                    step="0.01"
                    placeholder="Monto invertido"
                    value={form.montoInvertido || ''}
                    onChange={(e) => setForm({ ...form, montoInvertido: e.target.value })}
                    className="border rounded px-3 py-2"
                  />
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Valor actual"
                    value={form.valorActual || ''}
                    onChange={(e) => setForm({ ...form, valorActual: e.target.value })}
                    className="border rounded px-3 py-2"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Rendimiento anual %"
                    value={form.rendimientoAnual || ''}
                    onChange={(e) => setForm({ ...form, rendimientoAnual: e.target.value })}
                    className="border rounded px-3 py-2"
                  />
                  <input
                    type="number"
                    placeholder="Plazo meses"
                    value={form.plazoMeses || ''}
                    onChange={(e) => setForm({ ...form, plazoMeses: e.target.value })}
                    className="border rounded px-3 py-2"
                  />
                </div>
                <textarea
                  placeholder="Descripción (opcional)"
                  value={form.descripcion || ''}
                  onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
                >
                  Guardar
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
