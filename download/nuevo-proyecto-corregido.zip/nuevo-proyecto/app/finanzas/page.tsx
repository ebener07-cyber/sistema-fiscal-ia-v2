'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

interface KPI {
  fecha: string;
  patrimonioNeto: number;
  activoTotal: number;
  pasivoTotal: number;
  tasaAhorro: number;
  ratioEndeudamiento: number;
  diasCoberturaCaja: number;
  progresoFondoEmergencia: number;
  totalDeudas: number;
  faseActual: 1 | 2 | 3;
  alertas: string[];
}

const fmt = (n: number) =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);
const pct = (n: number) => `${(n || 0).toFixed(1)}%`;

export default function FinanzasDashboard() {
  const [empresaId, setEmpresaId] = useState<string>('');
  const [kpi, setKpi] = useState<KPI | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const id = localStorage.getItem('empresaId') || '';
    if (!id) {
      setError('No hay empresa seleccionada. Ve a /empresas para elegir una.');
      setLoading(false);
      return;
    }
    setEmpresaId(id);
    fetch(`/api/finanzas/kpis?empresaId=${id}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) setError(d.error);
        else setKpi(d.actual);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-8">Cargando dashboard financiero...</div>;
  if (error) return <div className="p-8 text-red-600">{error}</div>;
  if (!kpi) return <div className="p-8">Sin datos.</div>;

  const faseColor =
    kpi.faseActual === 1
      ? 'bg-red-100 text-red-800 border-red-300'
      : kpi.faseActual === 2
      ? 'bg-yellow-100 text-yellow-800 border-yellow-300'
      : 'bg-green-100 text-green-800 border-green-300';

  const cards = [
    { label: 'Patrimonio Neto', value: fmt(kpi.patrimonioNeto), sub: 'Activo − Pasivo' },
    { label: 'Activo Total', value: fmt(kpi.activoTotal), sub: 'Bienes + líquido' },
    { label: 'Pasivo Total', value: fmt(kpi.pasivoTotal), sub: 'Deudas pendientes' },
    { label: 'Total Deudas Activas', value: fmt(kpi.totalDeudas), sub: 'Solo deudas en pago' },
    { label: 'Tasa de Ahorro', value: pct(kpi.tasaAhorro), sub: 'Meta ≥ 20%' },
    { label: 'Ratio Endeudamiento', value: pct(kpi.ratioEndeudamiento), sub: 'Meta < 36%' },
    { label: 'Cobertura de Caja', value: `${kpi.diasCoberturaCaja} días`, sub: 'Meta ≥ 60 días' },
    { label: 'Fondo de Emergencia', value: pct(kpi.progresoFondoEmergencia), sub: 'Meta $200K MXN' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Reestructura Financiera</h1>
            <p className="text-gray-600 mt-1">
              Plan integral en 3 fases: diagnóstico → pago de deudas → crecimiento
            </p>
          </div>
          <div className={`px-4 py-2 rounded-lg border ${faseColor} font-semibold`}>
            FASE {kpi.faseActual}{' '}
            {kpi.faseActual === 1
              ? '— Diagnóstico'
              : kpi.faseActual === 2
              ? '— Pago de Deudas'
              : '— Crecimiento'}
          </div>
        </div>

        {/* Alertas */}
        {kpi.alertas.length > 0 && (
          <div className="mb-6 bg-orange-50 border border-orange-300 rounded-lg p-4">
            <h2 className="font-bold text-orange-900 mb-2">⚠️ Alertas activas</h2>
            <ul className="list-disc list-inside space-y-1 text-sm text-orange-800">
              {kpi.alertas.map((a, i) => (
                <li key={i}>{a}</li>
              ))}
            </ul>
          </div>
        )}

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {cards.map((c) => (
            <div key={c.label} className="bg-white rounded-lg shadow p-4">
              <div className="text-xs uppercase text-gray-500 font-semibold">{c.label}</div>
              <div className="text-2xl font-bold text-gray-900 mt-1">{c.value}</div>
              <div className="text-xs text-gray-500 mt-1">{c.sub}</div>
            </div>
          ))}
        </div>

        {/* Navegación a submódulos */}
        <h2 className="text-xl font-bold text-gray-900 mb-4">Módulos</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <ModuloCard
            href="/finanzas/patrimonio"
            titulo="1. Diagnóstico y Patrimonio"
            desc="Calcula tu patrimonio neto: activos, pasivos, bienes y deudas. Audita tu situación actual."
            color="bg-blue-500"
          />
          <ModuloCard
            href="/finanzas/fondo-emergencia"
            titulo="2. Fondo de Emergencia"
            desc="Meta $200,000 MXN. Crea tu colchón de seguridad para no caer en espiral de endeudamiento."
            color="bg-emerald-500"
          />
          <ModuloCard
            href="/finanzas/flujo-caja"
            titulo="3. Flujo de Caja 50/30/20"
            desc="Clasifica movimientos en necesidades, deseos y ahorro. Calcula tu tasa de ahorro real."
            color="bg-purple-500"
          />
          <ModuloCard
            href="/finanzas/deudas"
            titulo="4. Avalancha de Deudas"
            desc="Estrategia de pago: ataca primero la deuda más cara. Proyección mes a mes."
            color="bg-red-500"
          />
          <ModuloCard
            href="/finanzas/inversiones"
            titulo="5. Inversiones"
            desc="Fondo de inversión, ETFs, bienes raíces. Diversifica y construye patrimonio."
            color="bg-amber-500"
          />
          <ModuloCard
            href="/finanzas/plan"
            titulo="6. Plan de Acción"
            desc="Las 9 metas de las 3 fases. Renegociación, seguros, testamento, diversificación."
            color="bg-indigo-500"
          />
        </div>

        {/* Guardar snapshot */}
        <div className="mt-8 flex gap-3">
          <button
            onClick={async () => {
              const r = await fetch('/api/finanzas/kpis', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ empresaId }),
              });
              const d = await r.json();
              if (d.error) alert('Error: ' + d.error);
              else alert('✅ Snapshot guardado');
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            📸 Guardar snapshot KPIs
          </button>
          <Link
            href="/dashboard"
            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
          >
            ← Volver al dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}

function ModuloCard({
  href,
  titulo,
  desc,
  color,
}: {
  href: string;
  titulo: string;
  desc: string;
  color: string;
}) {
  return (
    <Link
      href={href}
      className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow p-5 border-l-4"
      style={{ borderLeftColor: color.replace('bg-', '').includes('blue') ? '#3b82f6' : undefined }}
    >
      <div className={`w-10 h-10 ${color} rounded mb-3`} />
      <h3 className="font-bold text-gray-900">{titulo}</h3>
      <p className="text-sm text-gray-600 mt-1">{desc}</p>
    </Link>
  );
}
