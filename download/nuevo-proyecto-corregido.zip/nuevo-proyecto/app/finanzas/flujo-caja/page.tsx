'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

const fmt = (n: number) =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);
const pct = (n: number) => `${(n || 0).toFixed(1)}%`;

export default function FlujoCajaPage() {
  const [empresaId, setEmpresaId] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<any>({});

  useEffect(() => {
    const id = localStorage.getItem('empresaId') || '';
    if (!id) {
      setLoading(false);
      return;
    }
    setEmpresaId(id);
    cargar(id);
  }, []);

  const cargar = (id: string) => {
    fetch(`/api/finanzas/flujo-caja?empresaId=${id}`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await fetch('/api/finanzas/flujo-caja', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, ...form }),
    });
    const d = await r.json();
    if (d.error) alert(d.error);
    else {
      setShowForm(false);
      setForm({});
      cargar(empresaId);
    }
  };

  if (loading) return <div className="p-8">Cargando...</div>;
  if (!data) return <div className="p-8">Sin datos.</div>;

  const barColor = (real: number, objetivo: number) =>
    real <= objetivo + 5 ? 'bg-green-500' : real <= objetivo + 15 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <Link href="/finanzas" className="text-blue-600 text-sm">← Volver a Finanzas</Link>
        <h1 className="text-3xl font-bold text-gray-900 mt-1 mb-2">Flujo de Caja 50/30/20</h1>
        <p className="text-gray-600 mb-6">
          Clasifica tus movimientos en <strong>necesidades (50%)</strong>,{' '}
          <strong>deseos (30%)</strong> y <strong>ahorro/inversión (20%)</strong>.
        </p>

        {/* Resumen */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Ingresos del mes</div>
            <div className="text-2xl font-bold text-green-600 mt-1">{fmt(data.ingresos)}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Egresos totales</div>
            <div className="text-2xl font-bold text-red-600 mt-1">
              {fmt(data.necesidades + data.deseos + data.ahorroInversion)}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Tasa de ahorro real</div>
            <div
              className={`text-2xl font-bold mt-1 ${
                data.tasaAhorroReal >= 20
                  ? 'text-green-600'
                  : data.tasaAhorroReal >= 0
                  ? 'text-yellow-600'
                  : 'text-red-600'
              }`}
            >
              {pct(data.tasaAhorroReal)}
            </div>
            <div className="text-xs text-gray-500">Meta ≥ 20%</div>
          </div>
        </div>

        {/* Evaluación */}
        <div
          className={`rounded-lg p-4 mb-6 border ${
            data.evaluacion === 'sano'
              ? 'bg-green-50 border-green-300 text-green-900'
              : data.evaluacion === 'atenido'
              ? 'bg-yellow-50 border-yellow-300 text-yellow-900'
              : 'bg-red-50 border-red-300 text-red-900'
          }`}
        >
          <strong>Evaluación:</strong> {data.recomendacion}
        </div>

        {/* Barras de distribución */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="font-bold text-gray-900 mb-4">Distribución de egresos</h2>
          <Barra
            label="Necesidades"
            valor={data.necesidades}
            pct={data.pctNecesidades}
            objetivo={50}
            color={barColor(data.pctNecesidades, 50)}
          />
          <Barra
            label="Deseos"
            valor={data.deseos}
            pct={data.pctDeseos}
            objetivo={30}
            color={barColor(data.pctDeseos, 30)}
          />
          <Barra
            label="Ahorro/Inversión"
            valor={data.ahorroInversion}
            pct={data.pctAhorro}
            objetivo={20}
            color={data.pctAhorro >= 20 ? 'bg-emerald-600' : 'bg-orange-500'}
          />
        </div>

        <div className="flex justify-end">
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            + Registrar movimiento
          </button>
        </div>

        {/* Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold">Nuevo movimiento</h3>
                <button onClick={() => setShowForm(false)} className="text-gray-500">✕</button>
              </div>
              <form onSubmit={submit} className="space-y-3">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, tipo: 'ingreso' })}
                    className={`flex-1 py-2 rounded ${form.tipo === 'ingreso' ? 'bg-green-600 text-white' : 'bg-gray-200'}`}
                  >
                    Ingreso
                  </button>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, tipo: 'egreso' })}
                    className={`flex-1 py-2 rounded ${form.tipo === 'egreso' ? 'bg-red-600 text-white' : 'bg-gray-200'}`}
                  >
                    Egreso
                  </button>
                </div>
                <select
                  required
                  value={form.categoria || ''}
                  onChange={(e) => setForm({ ...form, categoria: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="">Categoría...</option>
                  <option value="necesidad">Necesidad (alquiler, nómina, deudas)</option>
                  <option value="deseo">Deseo (comidas, viajes, entretenimiento)</option>
                  <option value="ahorro_inversion">Ahorro/Inversión</option>
                </select>
                <input
                  required
                  placeholder="Concepto"
                  value={form.concepto || ''}
                  onChange={(e) => setForm({ ...form, concepto: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <input
                  required
                  type="number"
                  step="0.01"
                  placeholder="Monto MXN"
                  value={form.monto || ''}
                  onChange={(e) => setForm({ ...form, monto: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <textarea
                  placeholder="Descripción (opcional)"
                  value={form.descripcion || ''}
                  onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
                >
                  Guardar
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Barra({
  label,
  valor,
  pct,
  objetivo,
  color,
}: {
  label: string;
  valor: number;
  pct: number;
  objetivo: number;
  color: string;
}) {
  return (
    <div className="mb-4">
      <div className="flex justify-between text-sm mb-1">
        <span className="font-semibold">{label}</span>
        <span>
          {fmt(valor)} · {pct.toFixed(1)}% (objetivo {objetivo}%)
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded h-4 relative overflow-hidden">
        <div className={`${color} h-full transition-all`} style={{ width: `${Math.min(100, pct)}%` }} />
        <div
          className="absolute top-0 bottom-0 border-l-2 border-gray-700 border-dashed"
          style={{ left: `${objetivo}%` }}
        />
      </div>
    </div>
  );
}
