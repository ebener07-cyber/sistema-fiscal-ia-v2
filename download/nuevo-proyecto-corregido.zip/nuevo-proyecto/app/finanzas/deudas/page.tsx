'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

const fmt = (n: number) =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);

export default function DeudasPage() {
  const [empresaId, setEmpresaId] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<any>({});
  const [excedente, setExcedente] = useState('5000');

  useEffect(() => {
    const id = localStorage.getItem('empresaId') || '';
    if (!id) {
      setLoading(false);
      return;
    }
    setEmpresaId(id);
    cargar(id);
  }, []);

  const cargar = (id: string, exc?: string) => {
    const e = exc ?? excedente;
    fetch(`/api/finanzas/deudas?empresaId=${id}&excedente=${encodeURIComponent(e)}`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await fetch('/api/finanzas/deudas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, ...form }),
    });
    const d = await r.json();
    if (d.error) alert(d.error);
    else {
      setShowForm(false);
      setForm({});
      cargar(empresaId);
    }
  };

  if (loading) return <div className="p-8">Cargando...</div>;
  if (!data) return <div className="p-8">Sin datos.</div>;

  const deudas = data.deudas || [];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <Link href="/finanzas" className="text-blue-600 text-sm">← Volver a Finanzas</Link>
        <h1 className="text-3xl font-bold text-gray-900 mt-1 mb-2">Estrategia Avalancha de Deudas</h1>
        <p className="text-gray-600 mb-6">
          Paga el mínimo en todas las deudas y ataca la más cara (interés más alto) con TODO el excedente.
        </p>

        {/* Resumen */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Total Deudas</div>
            <div className="text-2xl font-bold text-red-600 mt-1">{fmt(data.totalDeudas)}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Interés Mensual Total</div>
            <div className="text-2xl font-bold text-orange-600 mt-1">
              {fmt(data.totalInteresMensual)}
            </div>
            <div className="text-xs text-gray-500">Lo que pierdes cada mes por no pagar</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-xs uppercase text-gray-500 font-semibold">Deudas Activas</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">{deudas.length}</div>
          </div>
        </div>

        {/* Calculadora avalancha */}
        <div className="bg-blue-50 border border-blue-300 rounded-lg p-5 mb-6">
          <h2 className="font-bold text-blue-900 mb-2">🎯 Presupuesto Avalancha recomendado</h2>
          <div className="flex gap-3 items-center mb-3">
            <label className="text-sm">Excedente mensual disponible:</label>
            <input
              type="number"
              value={excedente}
              onChange={(e) => {
                setExcedente(e.target.value);
                cargar(empresaId, e.target.value);
              }}
              className="border rounded px-3 py-1 w-40"
            />
            <span className="text-sm text-gray-600">MXN</span>
          </div>
          {data.presupuestoAvalancha && (
            <p className="text-sm text-blue-900">{data.presupuestoAvalancha.descripcion}</p>
          )}
        </div>

        {/* Lista de deudas ordenadas */}
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-xl font-bold text-gray-900">Deudas (ordenadas por prioridad)</h2>
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            + Nueva deuda
          </button>
        </div>

        <div className="space-y-3">
          {deudas.length === 0 && (
            <div className="bg-white rounded-lg shadow p-6 text-center text-gray-500">
              Sin deudas registradas. ¡Excelente! O agrega una para empezar el plan.
            </div>
          )}
          {deudas.map((d: any, i: number) => {
            const pctInteres = data.totalInteresMensual > 0
              ? ((d.saldoActual * d.tasaInteresMensual) / 100 / data.totalInteresMensual) * 100
              : 0;
            return (
              <div
                key={d.id}
                className={`bg-white rounded-lg shadow p-4 border-l-4 ${
                  i === 0 ? 'border-red-500 bg-red-50' : 'border-gray-300'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-gray-800 text-white text-xs px-2 py-1 rounded-full">
                        #{i + 1}
                      </span>
                      <h3 className="font-bold text-gray-900">{d.nombre}</h3>
                      {i === 0 && (
                        <span className="bg-red-600 text-white text-xs px-2 py-0.5 rounded">
                          ATACAR PRIMERO
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {d.acreedor} · {d.tasaInteresMensual.toFixed(2)}% mensual ·{' '}
                      Estrategia: {d.estrategia}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-red-600">{fmt(d.saldoActual)}</div>
                    <div className="text-xs text-gray-500">Pago mín: {fmt(d.pagoMensualMinimo)}/mes</div>
                  </div>
                </div>

                {/* Proyección */}
                {d.mesesParaPagar !== null && (
                  <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                    <div className="bg-gray-100 rounded p-2">
                      <div className="text-gray-500">Meses para pagar</div>
                      <div className="font-bold">{d.mesesParaPagar} meses</div>
                    </div>
                    <div className="bg-gray-100 rounded p-2">
                      <div className="text-gray-500">Interés total estimado</div>
                      <div className="font-bold text-orange-600">
                        {fmt(d.interesTotalEstimado)}
                      </div>
                    </div>
                    <div className="bg-gray-100 rounded p-2">
                      <div className="text-gray-500">Costo total</div>
                      <div className="font-bold">
                        {fmt(d.saldoActual + d.interesTotalEstimado)}
                      </div>
                    </div>
                  </div>
                )}
                {d.mesesParaPagar === null && d.saldoActual > 0 && (
                  <div className="mt-3 bg-red-100 border border-red-300 rounded p-2 text-xs text-red-800">
                    ⚠️ El pago mínimo no cubre el interés. Sube el pago mensual o esta deuda crecerá
                    indefinidamente.
                  </div>
                )}
                {d.notasRenegociacion && (
                  <div className="mt-2 text-xs text-blue-700 italic">
                    📝 {d.notasRenegociacion}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Modal formulario */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold">Nueva deuda</h3>
                <button onClick={() => setShowForm(false)} className="text-gray-500">✕</button>
              </div>
              <form onSubmit={submit} className="space-y-3">
                <input
                  required
                  placeholder="Nombre (ej. Préstamo Familiar)"
                  value={form.nombre || ''}
                  onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <input
                  required
                  placeholder="Acreedor (ej. Banco Santander)"
                  value={form.acreedor || ''}
                  onChange={(e) => setForm({ ...form, acreedor: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    required
                    type="number"
                    step="0.01"
                    placeholder="Saldo MXN"
                    value={form.saldoActual || ''}
                    onChange={(e) => setForm({ ...form, saldoActual: e.target.value })}
                    className="border rounded px-3 py-2"
                  />
                  <input
                    required
                    type="number"
                    step="0.01"
                    placeholder="Tasa mensual %"
                    value={form.tasaInteresMensual || ''}
                    onChange={(e) => setForm({ ...form, tasaInteresMensual: e.target.value })}
                    className="border rounded px-3 py-2"
                  />
                </div>
                <input
                  required
                  type="number"
                  step="0.01"
                  placeholder="Pago mínimo mensual MXN"
                  value={form.pagoMensualMinimo || ''}
                  onChange={(e) => setForm({ ...form, pagoMensualMinimo: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <select
                  value={form.estrategia || 'avalancha'}
                  onChange={(e) => setForm({ ...form, estrategia: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="avalancha">Avalancha (interés más alto primero)</option>
                  <option value="bola_nieve">Bola de nieve (saldo más bajo primero)</option>
                  <option value="personalizada">Personalizada</option>
                </select>
                <textarea
                  placeholder="Notas de renegociación (opcional)"
                  value={form.notasRenegociacion || ''}
                  onChange={(e) => setForm({ ...form, notasRenegociacion: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
                >
                  Guardar
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
