'use client';

import Link from 'next/link';

const fmt = (n: number) =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);

interface Paso {
  fase: number;
  paso: number;
  titulo: string;
  descripcion: string;
  acciones: string[];
  metrica?: string;
}

const PLAN: Paso[] = [
  // FASE 1
  {
    fase: 1,
    paso: 1,
    titulo: 'Auditoría Financiera Total',
    descripcion: 'Consolidar todos los estados de cuenta en una sola vista.',
    acciones: [
      'Registrar TODOS los activos (efectivo, cuentas, inversiones, bienes) en el módulo de Patrimonio',
      'Registrar TODOS los pasivos (banco, tarjetas, préstamo familiar, hipoteca)',
      'Calcular Patrimonio Neto = Activo − Pasivo',
      'Snapshot inicial de KPIs para histórico',
    ],
    metrica: 'Patrimonio Neto Real claro y honesto',
  },
  {
    fase: 1,
    paso: 2,
    titulo: 'Crear el Fondo de Emergencia',
    descripcion: 'Colchón de seguridad de $200,000 MXN en cuenta separada.',
    acciones: [
      'Abrir cuenta de ahorros separada (NO de operaciones)',
      'Configurar meta: $200,000 MXN',
      'Hacer primer depósito',
      'Automatizar depósitos mensuales',
    ],
    metrica: '$200,000 MXN acumulados',
  },
  {
    fase: 1,
    paso: 3,
    titulo: 'Análisis de Flujo de Caja',
    descripcion: 'Clasificar movimientos en necesidades (50%), deseos (30%), ahorro (20%).',
    acciones: [
      'Registrar todos los movimientos del mes',
      'Calcular Tasa de Ahorro Real = (Ingresos − Egresos) / Ingresos',
      'Identificar gastos recortables',
      'Objetivo inicial: 20% de tasa de ahorro',
    ],
    metrica: 'Tasa de Ahorro ≥ 20%',
  },
  // FASE 2
  {
    fase: 2,
    paso: 4,
    titulo: 'Estrategia Avalancha',
    descripcion: 'Pagar primero la deuda con interés más alto (Préstamo Familiar 4% mensual).',
    acciones: [
      'Registrar todas las deudas en el módulo',
      'Pagar mínimo en todas',
      'Destinar TODO el excedente a la deuda prioridad #1',
      'Meta: eliminar préstamo familiar en 3-4 meses',
    ],
    metrica: 'Liberar $46,000 MXN/mes de flujo de caja',
  },
  {
    fase: 2,
    paso: 5,
    titulo: 'Renegociación Ofensiva de Deudas',
    descripcion: 'Contactar bancos con plan, no como deudor desesperado.',
    acciones: [
      'Banorte (Credilínea $2.8M): solicitar reestructuración a plazo mayor',
      'Préstamo Familiar: liquidar y evitar nuevos',
      'Tarjetas Konfío: pedir reducción de tasa o unificar',
      'Documentar todas las negociaciones en el módulo',
    ],
    metrica: 'Reducir pago mensual total en 30%',
  },
  {
    fase: 2,
    paso: 6,
    titulo: 'Optimización Fiscal y de Facturación',
    descripcion: 'Profesionalizar relación con Tania y clientes.',
    acciones: [
      'Contrato formal por cada proyecto',
      'Facturación diversificada (asesoría, planos, supervisión)',
      'Plazos de pago claros (máx 15 días) con recargos',
      'Revisar régimen fiscal óptimo',
    ],
    metrica: 'Días de cobranza < 30',
  },
  // FASE 3
  {
    fase: 3,
    paso: 7,
    titulo: 'Construcción del Fondo de Inversión',
    descripcion: 'Convertir flujo liberado en activos que generen ingresos.',
    acciones: [
      'Regla 50/30/20 redefinida: 50% necesidades, 30% crecimiento, 20% seguridad',
      'Abrir cuenta de inversión (causi, ETF)',
      'Meta: Tasa de Inversión ≥ 20%',
      'DCA: aporte mensual automático',
    ],
    metrica: 'Tasa de Inversión ≥ 20%',
  },
  {
    fase: 3,
    paso: 8,
    titulo: 'Diversificación de Ingresos',
    descripcion: 'Reducir dependencia de 1-2 clientes/proyectos.',
    acciones: [
      'Buscar nuevos clientes y tipos de proyectos',
      'ETFs de Renta Variable (S&P 500, IPC)',
      'Bienes Raíces (apartamento para renta)',
      'Fondos de Deuda para rendimiento estable',
    ],
    metrica: 'Ningún cliente > 30% del ingreso',
  },
  {
    fase: 3,
    paso: 9,
    titulo: 'Protección del Patrimonio',
    descripcion: 'Asegurar lo construido.',
    acciones: [
      'Seguro de Gastos Médicos Mayores (familia)',
      'Seguro de auto y casa',
      'Testamento y poderes notariales',
      'Revisión anual de beneficiarios',
    ],
    metrica: 'Cobertura 100% bienes y salud',
  },
];

const KPI_TABLE = [
  { kpi: 'Tasa de Ahorro/Inversión', objetivo: '> 20%', formula: '(Ingresos − Egresos) / Ingresos' },
  { kpi: 'Ratio Endeudamiento/Ingresos', objetivo: '< 36%', formula: 'Total Deudas / Ingresos Mensuales' },
  { kpi: 'Días de Cobertura de Caja', objetivo: '> 60 días', formula: 'Saldo de Caja / Gastos Mensuales × 30' },
  { kpi: 'Progreso Eliminación Deuda', objetivo: '30% en 6m', formula: 'Reducción de saldo mensual' },
];

export default function PlanPage() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto">
        <Link href="/finanzas" className="text-blue-600 text-sm">← Volver a Finanzas</Link>
        <h1 className="text-3xl font-bold text-gray-900 mt-1 mb-2">
          Plan de Reestructura Financiera
        </h1>
        <p className="text-gray-600 mb-6">
          3 fases · 9 pasos · Disciplina y seguimiento son cruciales para el éxito.
        </p>

        {/* KPIs table */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="font-bold text-gray-900 mb-3">📊 KPIs a monitorear</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-100 text-left">
                  <th className="px-3 py-2">KPI</th>
                  <th className="px-3 py-2">Objetivo</th>
                  <th className="px-3 py-2">Fórmula</th>
                </tr>
              </thead>
              <tbody>
                {KPI_TABLE.map((k) => (
                  <tr key={k.kpi} className="border-b">
                    <td className="px-3 py-2 font-semibold">{k.kpi}</td>
                    <td className="px-3 py-2 text-green-700">{k.objetivo}</td>
                    <td className="px-3 py-2 text-gray-600 font-mono text-xs">{k.formula}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Fases */}
        {[1, 2, 3].map((fase) => {
          const pasosFase = PLAN.filter((p) => p.fase === fase);
          const titulos = {
            1: 'Fase 1: Diagnóstico Detallado y Creación de Colchón',
            2: 'Fase 2: Ejecución y Reducción de Deuda',
            3: 'Fase 3: Crecimiento y Construcción de Patrimonio',
          };
          const plazos = {
            1: 'Próximos 30 días',
            2: 'Meses 1 a 6',
            3: 'A partir del Mes 7',
          };
          const colores = {
            1: 'border-red-500 bg-red-50',
            2: 'border-yellow-500 bg-yellow-50',
            3: 'border-green-500 bg-green-50',
          };
          return (
            <div key={fase} className="mb-8">
              <div className={`rounded-lg p-4 border-l-4 ${colores[fase as 1 | 2 | 3]} mb-4`}>
                <h2 className="text-xl font-bold text-gray-900">{titulos[fase as 1 | 2 | 3]}</h2>
                <p className="text-sm text-gray-600">Plazo: {plazos[fase as 1 | 2 | 3]}</p>
              </div>
              <div className="space-y-3">
                {pasosFase.map((p) => (
                  <div key={p.paso} className="bg-white rounded-lg shadow p-5">
                    <div className="flex items-start gap-3">
                      <div className="bg-gray-800 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold flex-shrink-0">
                        {p.paso}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-900">{p.titulo}</h3>
                        <p className="text-sm text-gray-600 mt-1">{p.descripcion}</p>
                        <ul className="mt-2 space-y-1 text-sm">
                          {p.acciones.map((a, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <span className="text-blue-600 mt-1">▸</span>
                              <span>{a}</span>
                            </li>
                          ))}
                        </ul>
                        {p.metrica && (
                          <div className="mt-3 inline-block bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full">
                            🎯 Meta: {p.metrica}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
