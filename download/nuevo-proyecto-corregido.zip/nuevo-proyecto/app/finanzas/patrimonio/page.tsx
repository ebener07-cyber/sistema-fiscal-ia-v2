'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

const fmt = (n: number) =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);

const TIPOS_ACTIVO = ['efectivo', 'cuenta_bancaria', 'inversion', 'bien_raiz', 'vehiculo', 'otro'];
const TIPOS_PASIVO = [
  'prestamo_bancario',
  'tarjeta_credito',
  'prestamo_familiar',
  'credito_hipotecario',
  'otro',
];

export default function PatrimonioPage() {
  const [empresaId, setEmpresaId] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formType, setFormType] = useState<'activo' | 'pasivo'>('activo');
  const [form, setForm] = useState<any>({});

  useEffect(() => {
    const id = localStorage.getItem('empresaId') || '';
    if (!id) {
      setLoading(false);
      return;
    }
    setEmpresaId(id);
    cargar(id);
  }, []);

  const cargar = (id: string) => {
    fetch(`/api/finanzas/patrimonio?empresaId=${id}`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await fetch('/api/finanzas/patrimonio', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, tipo: formType, data: form }),
    });
    const d = await r.json();
    if (d.error) alert(d.error);
    else {
      setShowForm(false);
      setForm({});
      cargar(empresaId);
    }
  };

  if (loading) return <div className="p-8">Cargando...</div>;
  if (!data) return <div className="p-8">Sin datos. Selecciona una empresa.</div>;

  const colorPN = data.patrimonioNeto >= 0 ? 'text-green-600' : 'text-red-600';

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <Link href="/finanzas" className="text-blue-600 text-sm">← Volver a Finanzas</Link>
            <h1 className="text-3xl font-bold text-gray-900 mt-1">Patrimonio Neto</h1>
            <p className="text-gray-600">Activo Total − Pasivo Total</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            + Agregar
          </button>
        </div>

        {/* Resumen grande */}
        <div className="bg-white rounded-lg shadow p-6 mb-6 text-center">
          <div className="text-sm uppercase text-gray-500 font-semibold">Patrimonio Neto</div>
          <div className={`text-5xl font-bold ${colorPN} mt-2`}>{fmt(data.patrimonioNeto)}</div>
          <div className="flex justify-center gap-12 mt-4 text-sm">
            <div>
              <span className="text-gray-500">Activo:</span>{' '}
              <span className="font-semibold text-green-600">{fmt(data.activoTotal)}</span>
            </div>
            <div>
              <span className="text-gray-500">Pasivo:</span>{' '}
              <span className="font-semibold text-red-600">{fmt(data.pasivoTotal)}</span>
            </div>
          </div>
          <div className="flex justify-center gap-12 mt-2 text-xs text-gray-500">
            <span>Liquidable: {fmt(data.activosLiquidables)}</span>
            <span>Ilíquido: {fmt(data.activosIlliquidos)}</span>
          </div>
        </div>

        {/* Desglose por tipo */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow p-5">
            <h2 className="font-bold text-gray-900 mb-3">📈 Activos por tipo</h2>
            {data.desglosePorTipoActivo.length === 0 ? (
              <p className="text-sm text-gray-500">Sin activos registrados.</p>
            ) : (
              <ul className="space-y-2">
                {data.desglosePorTipoActivo.map((a: any) => (
                  <li key={a.tipo} className="flex justify-between text-sm">
                    <span className="capitalize">{a.tipo.replace(/_/g, ' ')} ({a.count})</span>
                    <span className="font-semibold">{fmt(a.total)}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="bg-white rounded-lg shadow p-5">
            <h2 className="font-bold text-gray-900 mb-3">📉 Pasivos por tipo</h2>
            {data.desglosePorTipoPasivo.length === 0 ? (
              <p className="text-sm text-gray-500">Sin pasivos registrados.</p>
            ) : (
              <ul className="space-y-2">
                {data.desglosePorTipoPasivo.map((p: any) => (
                  <li key={p.tipo} className="flex justify-between text-sm">
                    <span className="capitalize">{p.tipo.replace(/_/g, ' ')} ({p.count})</span>
                    <span className="font-semibold text-red-600">{fmt(p.total)}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Modal formulario */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold">
                  Nuevo {formType === 'activo' ? 'Activo' : 'Pasivo'}
                </h3>
                <button onClick={() => setShowForm(false)} className="text-gray-500">✕</button>
              </div>
              <div className="flex gap-2 mb-4">
                <button
                  type="button"
                  onClick={() => setFormType('activo')}
                  className={`flex-1 py-2 rounded ${formType === 'activo' ? 'bg-green-600 text-white' : 'bg-gray-200'}`}
                >
                  Activo
                </button>
                <button
                  type="button"
                  onClick={() => setFormType('pasivo')}
                  className={`flex-1 py-2 rounded ${formType === 'pasivo' ? 'bg-red-600 text-white' : 'bg-gray-200'}`}
                >
                  Pasivo
                </button>
              </div>
              <form onSubmit={submit} className="space-y-3">
                <select
                  required
                  value={form.tipo || ''}
                  onChange={(e) => setForm({ ...form, tipo: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="">Tipo...</option>
                  {(formType === 'activo' ? TIPOS_ACTIVO : TIPOS_PASIVO).map((t) => (
                    <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>
                  ))}
                </select>
                <input
                  required
                  placeholder="Nombre"
                  value={form.nombre || ''}
                  onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <input
                  required
                  type="number"
                  step="0.01"
                  placeholder={formType === 'activo' ? 'Valor MXN' : 'Saldo MXN'}
                  value={form.valor ?? form.saldo ?? ''}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      [formType === 'activo' ? 'valor' : 'saldo']: e.target.value,
                    })
                  }
                  className="w-full border rounded px-3 py-2"
                />
                {formType === 'activo' ? (
                  <label className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={form.esLiquidable || false}
                      onChange={(e) => setForm({ ...form, esLiquidable: e.target.checked })}
                    />
                    Es liquidable (efectivo, cuenta de ahorro)
                  </label>
                ) : (
                  <>
                    <input
                      type="number"
                      step="0.01"
                      placeholder="Tasa interés mensual %"
                      value={form.tasaInteresMensual || ''}
                      onChange={(e) => setForm({ ...form, tasaInteresMensual: e.target.value })}
                      className="w-full border rounded px-3 py-2"
                    />
                    <input
                      type="number"
                      step="0.01"
                      placeholder="Pago mínimo mensual MXN"
                      value={form.pagoMensualMinimo || ''}
                      onChange={(e) => setForm({ ...form, pagoMensualMinimo: e.target.value })}
                      className="w-full border rounded px-3 py-2"
                    />
                    <input
                      placeholder="Acreedor (banco, familiar...)"
                      value={form.acreedor || ''}
                      onChange={(e) => setForm({ ...form, acreedor: e.target.value })}
                      className="w-full border rounded px-3 py-2"
                    />
                  </>
                )}
                <textarea
                  placeholder="Descripción (opcional)"
                  value={form.descripcion || ''}
                  onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
                >
                  Guardar
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
