'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

const fmt = (n: number) =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);

export default function FondoEmergenciaPage() {
  const [empresaId, setEmpresaId] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [tipoMov, setTipoMov] = useState<'deposito' | 'retiro'>('deposito');
  const [monto, setMonto] = useState('');
  const [desc, setDesc] = useState('');
  const [editMeta, setEditMeta] = useState(false);
  const [nuevaMeta, setNuevaMeta] = useState('');

  useEffect(() => {
    const id = localStorage.getItem('empresaId') || '';
    if (!id) {
      setLoading(false);
      return;
    }
    setEmpresaId(id);
    cargar(id);
  }, []);

  const cargar = (id: string) => {
    fetch(`/api/finanzas/fondo-emergencia?empresaId=${id}`)
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await fetch('/api/finanzas/fondo-emergencia', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, tipo: tipoMov, monto: parseFloat(monto), descripcion: desc }),
    });
    const d = await r.json();
    if (d.error) alert(d.error);
    else {
      setShowForm(false);
      setMonto('');
      setDesc('');
      cargar(empresaId);
    }
  };

  const actualizarMeta = async () => {
    const r = await fetch('/api/finanzas/fondo-emergencia', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, meta: parseFloat(nuevaMeta) }),
    });
    const d = await r.json();
    if (d.error) alert(d.error);
    else {
      setEditMeta(false);
      cargar(empresaId);
    }
  };

  if (loading) return <div className="p-8">Cargando...</div>;
  if (!data) return <div className="p-8">Sin datos.</div>;

  const progreso = Math.min(100, data.progreso);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <Link href="/finanzas" className="text-blue-600 text-sm">← Volver a Finanzas</Link>
        <h1 className="text-3xl font-bold text-gray-900 mt-1 mb-2">Fondo de Emergencia</h1>
        <p className="text-gray-600 mb-6">
          Tu colchón de seguridad. Meta recomendada: <strong>$200,000 MXN</strong>.{' '}
          Guárdalo en cuenta separada, NO en tu cuenta de operaciones.
        </p>

        {/* Barra de progreso */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">Progreso</span>
            <span className="text-2xl font-bold text-blue-600">
              {progreso.toFixed(1)}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-6 overflow-hidden">
            <div
              className="bg-gradient-to-r from-green-400 to-emerald-600 h-full transition-all"
              style={{ width: `${progreso}%` }}
            />
          </div>
          <div className="flex justify-between mt-3 text-sm">
            <div>
              <span className="text-gray-500">Saldo actual:</span>{' '}
              <span className="font-bold text-green-600">{fmt(data.saldoActual)}</span>
            </div>
            <div>
              <span className="text-gray-500">Meta:</span>{' '}
              <span className="font-bold">{fmt(data.meta)}</span>
              <button
                onClick={() => {
                  setEditMeta(true);
                  setNuevaMeta(String(data.meta));
                }}
                className="ml-2 text-xs text-blue-600 underline"
              >
                cambiar
              </button>
            </div>
            <div>
              <span className="text-gray-500">Faltante:</span>{' '}
              <span className="font-bold text-red-600">{fmt(data.faltante)}</span>
            </div>
          </div>
          {editMeta && (
            <div className="flex gap-2 mt-3">
              <input
                type="number"
                value={nuevaMeta}
                onChange={(e) => setNuevaMeta(e.target.value)}
                className="border rounded px-3 py-1 flex-1"
              />
              <button
                onClick={actualizarMeta}
                className="px-3 py-1 bg-blue-600 text-white rounded text-sm"
              >
                Guardar
              </button>
              <button
                onClick={() => setEditMeta(false)}
                className="px-3 py-1 bg-gray-200 rounded text-sm"
              >
                Cancelar
              </button>
            </div>
          )}
        </div>

        {/* Botón nuevo movimiento */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900">Movimientos</h2>
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            + Nuevo movimiento
          </button>
        </div>

        <div className="bg-white rounded-lg shadow divide-y">
          {data.movimientos.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              Sin movimientos todavía. Empieza con tu primer depósito.
            </div>
          ) : (
            data.movimientos.map((m: any) => (
              <div key={m.id} className="p-4 flex justify-between items-center">
                <div>
                  <div className="font-semibold flex items-center gap-2">
                    {m.tipo === 'deposito' ? (
                      <span className="text-green-600">↗ Depósito</span>
                    ) : (
                      <span className="text-red-600">↙ Retiro</span>
                    )}
                    {m.descripcion && <span className="text-gray-500 text-sm">— {m.descripcion}</span>}
                  </div>
                  <div className="text-xs text-gray-500">
                    {new Date(m.fecha).toLocaleString('es-MX')}
                  </div>
                </div>
                <div className={`font-bold ${m.tipo === 'deposito' ? 'text-green-600' : 'text-red-600'}`}>
                  {m.tipo === 'deposito' ? '+' : '−'}
                  {fmt(m.monto)}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold">Nuevo movimiento</h3>
                <button onClick={() => setShowForm(false)} className="text-gray-500">✕</button>
              </div>
              <div className="flex gap-2 mb-4">
                <button
                  type="button"
                  onClick={() => setTipoMov('deposito')}
                  className={`flex-1 py-2 rounded ${tipoMov === 'deposito' ? 'bg-green-600 text-white' : 'bg-gray-200'}`}
                >
                  ↗ Depósito
                </button>
                <button
                  type="button"
                  onClick={() => setTipoMov('retiro')}
                  className={`flex-1 py-2 rounded ${tipoMov === 'retiro' ? 'bg-red-600 text-white' : 'bg-gray-200'}`}
                >
                  ↙ Retiro
                </button>
              </div>
              <form onSubmit={submit} className="space-y-3">
                <input
                  required
                  type="number"
                  step="0.01"
                  placeholder="Monto MXN"
                  value={monto}
                  onChange={(e) => setMonto(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                />
                <textarea
                  placeholder="Descripción (opcional)"
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
                >
                  Registrar
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
