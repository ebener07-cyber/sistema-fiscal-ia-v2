'use client';

import { useState } from 'react';
import { ERPLayout } from '@/components/ERPLayout';

export default function TributarioPage() {
  const [periodo, setPeriodo] = useState('2025-11');

  const declaraciones = [
    { id: 'DEC-001', tipo: 'ISR Mensual', periodo: 'Nov 2025', monto: 45230, status: 'Presentada', fecha: '2025-12-17', acuse: 'ACU-2025-11-001' },
    { id: 'DEC-002', tipo: 'IVA', periodo: 'Nov 2025', monto: 12840, status: 'Presentada', fecha: '2025-12-17', acuse: 'ACU-2025-11-002' },
    { id: 'DEC-003', tipo: 'DIOT', periodo: 'Nov 2025', monto: 0, status: 'Pendiente', fecha: null, acuse: null },
    { id: 'DEC-004', tipo: 'ISR Anual', periodo: '2024', monto: 523400, status: 'Presentada', fecha: '2025-04-30', acuse: 'ACU-2024-001' },
    { id: 'DEC-005', tipo: 'Contabilidad Electrónica', periodo: 'Nov 2025', monto: 0, status: 'En proceso', fecha: null, acuse: null },
  ];

  return (
    <ERPLayout moduleKey="tributario">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Tributario</h3>
            <p className="text-sm text-gray-500">Declaraciones ISR, IVA, DIOT generadas desde XML descargados y validados</p>
          </div>
          <div className="flex gap-2">
            <select 
              value={periodo}
              onChange={(e) => setPeriodo(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
            >
              <option value="2025-11">Noviembre 2025</option>
              <option value="2025-10">Octubre 2025</option>
              <option value="2025-09">Septiembre 2025</option>
            </select>
            <button className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700">
              ⚖️ Nueva Declaración
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white rounded-xl border-l-4 border-red-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">ISR por Pagar</p>
            <p className="text-2xl font-bold text-red-600 mt-1">$45,230</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-blue-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">IVA por Pagar</p>
            <p className="text-2xl font-bold text-blue-600 mt-1">$12,840</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-amber-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">DIOT Pendiente</p>
            <p className="text-2xl font-bold text-amber-600 mt-1">Pendiente</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-emerald-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Declaraciones Presentadas</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">3 de 5</p>
          </div>
        </div>

        {/* Declaraciones */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm">
          <div className="p-5 border-b border-gray-200">
            <h3 className="font-bold text-gray-900">Declaraciones Fiscales</h3>
            <p className="text-xs text-gray-500 mt-0.5">Historial de declaraciones presentadas al SAT</p>
          </div>
          <table className="w-full">
            <thead>
              <tr className="text-xs text-gray-500 border-b border-gray-200 bg-gray-50">
                <th className="text-left px-5 py-3 font-medium">ID</th>
                <th className="text-left px-3 py-3 font-medium">Tipo</th>
                <th className="text-left px-3 py-3 font-medium">Periodo</th>
                <th className="text-right px-3 py-3 font-medium">Monto</th>
                <th className="text-left px-3 py-3 font-medium">Fecha Presentación</th>
                <th className="text-left px-3 py-3 font-medium">Acuse</th>
                <th className="text-left px-5 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {declaraciones.map((dec) => (
                <tr key={dec.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                  <td className="px-5 py-3 font-mono text-red-600 font-semibold">{dec.id}</td>
                  <td className="px-3 py-3 text-gray-900 font-medium">{dec.tipo}</td>
                  <td className="px-3 py-3 text-gray-600">{dec.periodo}</td>
                  <td className="px-3 py-3 text-right font-semibold text-gray-900">
                    {dec.monto > 0 ? `$${dec.monto.toLocaleString('es-MX')}` : '-'}
                  </td>
                  <td className="px-3 py-3 text-gray-600 text-xs">{dec.fecha || '-'}</td>
                  <td className="px-3 py-3">
                    {dec.acuse ? (
                      <span className="text-xs font-mono text-red-600 bg-red-50 px-2 py-0.5 rounded">{dec.acuse}</span>
                    ) : (
                      <span className="text-xs text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-5 py-3">
                    <span className={`px-2 py-1 text-xs font-semibold rounded ${
                      dec.status === 'Presentada' ? 'bg-emerald-100 text-emerald-700' :
                      dec.status === 'Pendiente' ? 'bg-amber-100 text-amber-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {dec.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Alertas */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <span className="text-xl">️</span>
          <div className="text-sm">
            <p className="font-semibold text-amber-900">DIOT de Noviembre 2025 pendiente</p>
            <p className="text-amber-700 text-xs mt-1">
              La Declaración Informativa de Operaciones con Terceros debe presentarse antes del 15 de diciembre de 2025.
            </p>
          </div>
        </div>
      </div>
    </ERPLayout>
  );
}