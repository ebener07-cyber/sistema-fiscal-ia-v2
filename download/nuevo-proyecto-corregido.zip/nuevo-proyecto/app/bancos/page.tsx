'use client';

import { useState } from 'react';
import { ERPLayout } from '@/components/ERPLayout';

export default function BancosPage() {
  const [cuentaSeleccionada, setCuentaSeleccionada] = useState('BBVA-0123');
  const [showUpload, setShowUpload] = useState(false);

  const cuentas = [
    { id: 'BBVA-0123', banco: 'BBVA', numero: '****0123', saldo: 245680.50, conciliado: 89 },
    { id: 'BANORTE-4567', banco: 'Banorte', numero: '****4567', saldo: 128450.00, conciliado: 95 },
    { id: 'SANTANDER-8901', banco: 'Santander', numero: '****8901', saldo: 67230.75, conciliado: 72 },
  ];

  const movimientos = [
    { id: 'MOV-001', fecha: '2025-11-28', descripcion: 'Transferencia recibida - Cliente ABC', monto: 15600.00, tipo: 'ingreso', conciliado: true, factura: 'A-1234' },
    { id: 'MOV-002', fecha: '2025-11-27', descripcion: 'Pago proveedor - Telmex S.A.B.', monto: -4500.00, tipo: 'egreso', conciliado: true, factura: 'B-5678' },
    { id: 'MOV-003', fecha: '2025-11-27', descripcion: 'Comisión bancaria', monto: -250.00, tipo: 'egreso', conciliado: false, factura: null },
    { id: 'MOV-004', fecha: '2025-11-26', descripcion: 'Depósito en efectivo', monto: 8900.00, tipo: 'ingreso', conciliado: false, factura: null },
    { id: 'MOV-005', fecha: '2025-11-25', descripcion: 'Transferencia - Oficina Depot', monto: -1280.00, tipo: 'egreso', conciliado: true, factura: 'B-9012' },
  ];

  return (
    <ERPLayout moduleKey="bancos">
      <div className="space-y-6">
        {/* Header con acciones */}
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Conciliación Bancaria</h3>
            <p className="text-sm text-gray-500">Conciliación automática contra CFDIs de pagos y transferencias</p>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
              📊 Reporte
            </button>
            <button 
              onClick={() => setShowUpload(!showUpload)}
              className="px-4 py-2 bg-cyan-600 text-white rounded-lg text-sm font-medium hover:bg-cyan-700"
            >
               Subir Estado de Cuenta
            </button>
          </div>
        </div>

        {/* Cuentas */}
        <div className="grid grid-cols-3 gap-4">
          {cuentas.map((cuenta) => (
            <button
              key={cuenta.id}
              onClick={() => setCuentaSeleccionada(cuenta.id)}
              className={`text-left p-5 rounded-xl border transition ${
                cuentaSeleccionada === cuenta.id 
                  ? 'border-cyan-500 ring-2 ring-cyan-100 bg-cyan-50' 
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-gray-500">{cuenta.banco}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  cuenta.conciliado > 90 ? 'bg-emerald-100 text-emerald-700' :
                  cuenta.conciliado > 70 ? 'bg-amber-100 text-amber-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {cuenta.conciliado}% conciliado
                </span>
              </div>
              <p className="text-sm text-gray-600 font-mono">{cuenta.numero}</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                ${cuenta.saldo.toLocaleString('es-MX', { minimumFractionDigits: 2 })}
              </p>
            </button>
          ))}
        </div>

        {/* Upload Panel */}
        {showUpload && (
          <div className="bg-cyan-50 border border-cyan-200 rounded-xl p-6">
            <h4 className="font-semibold text-cyan-900 mb-3">Subir Estado de Cuenta</h4>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Banco</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option>BBVA</option>
                  <option>Banorte</option>
                  <option>Santander</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Cuenta</label>
                <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Número de cuenta" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Periodo</label>
                <input type="month" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
              </div>
            </div>
            <div className="border-2 border-dashed border-cyan-300 rounded-lg p-6 text-center bg-white">
              <p className="text-3xl mb-2">📄</p>
              <p className="text-sm text-gray-600">Arrastra tu archivo aquí o haz clic para seleccionar</p>
              <p className="text-xs text-gray-400 mt-1">Formatos: CSV, OFX, QFX, PDF</p>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <button onClick={() => setShowUpload(false)} className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg">
                Cancelar
              </button>
              <button className="px-4 py-2 bg-cyan-600 text-white text-sm font-semibold rounded-lg hover:bg-cyan-700">
                Procesar y Conciliar
              </button>
            </div>
          </div>
        )}

        {/* Movimientos */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm">
          <div className="p-5 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-gray-900">Movimientos Bancarios</h3>
              <p className="text-xs text-gray-500 mt-0.5">Cuenta: {cuentaSeleccionada}</p>
            </div>
            <div className="flex gap-2">
              <select className="px-3 py-1.5 text-xs border border-gray-200 rounded-lg">
                <option>Todos</option>
                <option>Conciliados</option>
                <option>Pendientes</option>
              </select>
            </div>
          </div>
          <table className="w-full">
            <thead>
              <tr className="text-xs text-gray-500 border-b border-gray-200 bg-gray-50">
                <th className="text-left px-5 py-3 font-medium">Fecha</th>
                <th className="text-left px-3 py-3 font-medium">Descripción</th>
                <th className="text-right px-3 py-3 font-medium">Monto</th>
                <th className="text-left px-3 py-3 font-medium">Factura</th>
                <th className="text-left px-5 py-3 font-medium">Estado</th>
                <th className="text-left px-5 py-3 font-medium">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {movimientos.map((mov) => (
                <tr key={mov.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                  <td className="px-5 py-3 text-gray-600 text-xs">{mov.fecha}</td>
                  <td className="px-3 py-3 text-gray-700">{mov.descripcion}</td>
                  <td className={`px-3 py-3 text-right font-mono font-semibold ${
                    mov.tipo === 'ingreso' ? 'text-emerald-600' : 'text-red-600'
                  }`}>
                    {mov.tipo === 'ingreso' ? '+' : ''}${Math.abs(mov.monto).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-3 py-3">
                    {mov.factura ? (
                      <span className="text-xs font-mono text-cyan-600 bg-cyan-50 px-2 py-0.5 rounded">{mov.factura}</span>
                    ) : (
                      <span className="text-xs text-gray-400">Sin conciliar</span>
                    )}
                  </td>
                  <td className="px-5 py-3">
                    <span className={`px-2 py-1 text-xs font-semibold rounded ${
                      mov.conciliado ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {mov.conciliado ? '✓ Conciliado' : '⏳ Pendiente'}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    {!mov.conciliado && (
                      <button className="text-xs text-cyan-600 hover:text-cyan-800 font-medium">
                        Conciliar →
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Resumen */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Total Ingresos</p>
            <p className="text-xl font-bold text-emerald-600 mt-1">$24,500.00</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Total Egresos</p>
            <p className="text-xl font-bold text-red-600 mt-1">$6,030.00</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Conciliados</p>
            <p className="text-xl font-bold text-cyan-600 mt-1">3 de 5</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Diferencia</p>
            <p className="text-xl font-bold text-amber-600 mt-1">$0.00</p>
          </div>
        </div>
      </div>
    </ERPLayout>
  );
}