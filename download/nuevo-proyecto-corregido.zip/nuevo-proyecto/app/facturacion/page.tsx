'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Upload, FileText, TrendingUp, TrendingDown, CheckCircle, 
  AlertTriangle, Plus, Search, Filter, Download, Eye,
  CreditCard, DollarSign, FileCheck, Clock, Loader2, X
} from 'lucide-react';

interface Factura {
  id: string;
  folio: string;
  serie?: string;
  fecha: string;
  monto: number;
  subtotal: number;
  totalImpuestos: number;
  moneda: string;
  tipoComprobante: string;
  metodoPago: string;
  formaPago: string;
  direccion: 'emitida' | 'recibida';
  estado: string;
  uuid?: string;
  receptorRfc?: string;
  receptorNombre?: string;
  emisorRfc?: string;
  emisorNombre?: string;
  cliente?: { nombre: string; rfc: string };
  empresa?: { nombre: string; rfc: string };
}

interface Stats {
  porCobrar: { monto: number; count: number };
  porPagar: { monto: number; count: number };
  timbradas: { count: number };
  pendientes: { count: number };
  emitidas: { monto: number; count: number };
  recibidas: { monto: number; count: number };
  nomina: { monto: number; count: number };
}

export default function FacturacionPage() {
  const router = useRouter();
  const [facturasRecientes, setFacturasRecientes] = useState<Factura[]>([]);
  const [facturasEmitidas, setFacturasEmitidas] = useState<Factura[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modales
  const [showModalEmitida, setShowModalEmitida] = useState(false);
  const [showModalRecibida, setShowModalRecibida] = useState(false);
  const [showModalMovimiento, setShowModalMovimiento] = useState(false);

  useEffect(() => {
    fetchFacturas();
    fetchStats();
  }, []);

  const fetchFacturas = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/facturas?limit=100');
      const data = await res.json();
      const facturas = data.data || [];
      
      setFacturasRecientes(facturas.filter((f: Factura) => f.direccion === 'recibida').slice(0, 5));
      setFacturasEmitidas(facturas.filter((f: Factura) => f.direccion === 'emitida').slice(0, 5));
    } catch (error) {
      console.error('Error fetching facturas:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/facturas/stats');
      const data = await res.json();
      if (data.success) {
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-MX', { 
      style: 'currency', 
      currency: 'MXN',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('es-MX', { 
      day: 'numeric', 
      month: 'short',
      year: 'numeric'
    });
  };

  const getEstadoColor = (estado: string) => {
    const colors: Record<string, string> = {
      'timbrada': 'bg-emerald-100 text-emerald-800',
      'cargada': 'bg-blue-100 text-blue-800',
      'vigente': 'bg-blue-100 text-blue-800',
      'pagada': 'bg-green-100 text-green-800',
      'vencida': 'bg-red-100 text-red-800',
      'pendiente': 'bg-amber-100 text-amber-800',
      'cancelada': 'bg-gray-100 text-gray-800',
    };
    return `px-2 py-1 rounded-full text-xs font-medium ${colors[estado] || 'bg-gray-100 text-gray-800'}`;
  };

  const getEstadoLabel = (estado: string) => {
    const labels: Record<string, string> = {
      'timbrada': 'Timbrada',
      'cargada': 'Cargada',
      'vigente': 'Vigente',
      'pagada': 'Pagada',
      'vencida': 'Vencida',
      'pendiente': 'Pendiente',
      'cancelada': 'Cancelada',
    };
    return labels[estado] || estado;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Hola, Alejandro!</h1>
            <p className="text-sm text-gray-600">Bienvenido a tu panel de facturación</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Buscar facturas, RFC..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-80"
              />
            </div>
            <button className="relative p-2 text-gray-600 hover:text-gray-900">
              <AlertTriangle size={20} />
              <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
              A
            </div>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-slate-900 min-h-screen px-4 py-6">
          <div className="flex items-center gap-2 mb-8 px-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <span className="text-white font-bold text-lg">Abbax-IA ERP</span>
          </div>

          <nav className="space-y-1">
            <NavItem icon={<TrendingUp size={20} />} label="Dashboard" onClick={() => router.push('/dashboard')} />
            <NavItem icon={<FileText size={20} />} label="Empresas" onClick={() => router.push('/empresas')} />
            <NavItem icon={<CreditCard size={20} />} label="Clientes" onClick={() => router.push('/crm')} />
            <NavItem icon={<FileCheck size={20} />} label="Facturación" active />
            <NavItem icon={<DollarSign size={20} />} label="Gastos" onClick={() => router.push('/compras')} />
            <NavItem icon={<Filter size={20} />} label="Impuestos" onClick={() => router.push('/tributario')} />
            <NavItem icon={<Clock size={20} />} label="Nómina" onClick={() => router.push('/nomina')} />
            <NavItem icon={<TrendingUp size={20} />} label="Reportes" onClick={() => router.push('/reportes')} />
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          {/* Action Buttons */}
          <div className="flex gap-3 mb-6">
            <button 
              onClick={() => setShowModalEmitida(true)}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition font-medium cursor-pointer"
            >
              <Plus size={20} />
              Factura Emitida
            </button>
            <button 
              onClick={() => setShowModalRecibida(true)}
              className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition font-medium cursor-pointer"
            >
              <Upload size={20} />
              Factura Recibida
            </button>
            <button 
              onClick={() => setShowModalMovimiento(true)}
              className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition font-medium cursor-pointer"
            >
              <Upload size={20} />
              Movimiento Bancario
            </button>
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-5 gap-4 mb-6">
            <KPICard
              title="Por Cobrar"
              amount={stats?.porCobrar.monto || 0}
              count={stats?.porCobrar.count || 0}
              subtitle="facturas emitidas"
              icon={<TrendingUp size={24} />}
              color="blue"
            />
            <KPICard
              title="Por Pagar"
              amount={stats?.porPagar.monto || 0}
              count={stats?.porPagar.count || 0}
              subtitle="facturas recibidas"
              icon={<TrendingDown size={24} />}
              color="orange"
            />
            <KPICard
              title="Total Nómina"
              amount={stats?.nomina?.monto || 0}
              count={stats?.nomina?.count || 0}
              subtitle="CFDI de nómina"
              icon={<Clock size={24} />}
              color="purple"
            />
            <KPICard
              title="Timbradas"
              amount={stats?.timbradas.count || 0}
              count={0}
              subtitle="CFDI 4.0"
              icon={<CheckCircle size={24} />}
              color="green"
              isCurrency={false}
            />
            <KPICard
              title="Pendientes"
              amount={stats?.pendientes.count || 0}
              count={0}
              subtitle="Requieren acción"
              icon={<AlertTriangle size={24} />}
              color="red"
              isCurrency={false}
              warning
            />
          </div>

          {/* Tables */}
          <div className="grid grid-cols-3 gap-6">
            {/* Facturas Recientes (Recibidas) */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="font-semibold text-gray-900">Facturas Recibidas</h3>
                <p className="text-sm text-gray-600">Últimas 5 facturas recibidas</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Folio</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Emisor</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Monto</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {loading ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                          <Loader2 className="animate-spin mx-auto" size={24} />
                        </td>
                      </tr>
                    ) : facturasRecientes.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                          No hay facturas recibidas
                        </td>
                      </tr>
                    ) : (
                      facturasRecientes.map((factura) => (
                        <tr key={factura.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm font-medium text-blue-600">{factura.folio}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{formatDate(factura.fecha)}</td>
                          <td className="px-6 py-4 text-sm text-gray-900">{factura.emisorNombre || 'N/A'}</td>
                          <td className="px-6 py-4 text-sm font-medium text-gray-900">
                            {formatCurrency(factura.monto)}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Facturas Emitidas */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="font-semibold text-gray-900">Facturas Emitidas</h3>
                <p className="text-sm text-gray-600">Últimas 5 facturas emitidas</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Folio</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Receptor</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Monto</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {loading ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                          <Loader2 className="animate-spin mx-auto" size={24} />
                        </td>
                      </tr>
                    ) : facturasEmitidas.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                          No hay facturas emitidas
                        </td>
                      </tr>
                    ) : (
                      facturasEmitidas.map((factura) => (
                        <tr key={factura.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm font-medium text-blue-600">{factura.folio}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{formatDate(factura.fecha)}</td>
                          <td className="px-6 py-4 text-sm text-gray-900">{factura.receptorNombre || 'N/A'}</td>
                          <td className="px-6 py-4 text-sm font-medium text-gray-900">
                            {formatCurrency(factura.monto)}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Nóminas Emitidas */}
            <div className="bg-white rounded-lg shadow border-2 border-purple-100">
              <div className="px-6 py-4 border-b border-purple-200 bg-purple-50">
                <h3 className="font-semibold text-purple-900">Nóminas Emitidas</h3>
                <p className="text-sm text-purple-600">CFDI de nómina</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-purple-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase">Folio</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase">Fecha</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase">Empleado</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase">Monto</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-purple-100">
                    {loading ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                          <Loader2 className="animate-spin mx-auto" size={24} />
                        </td>
                      </tr>
                    ) : (
                      <>
                        {facturasEmitidas
                          .filter(f => f.tipoComprobante === 'N')
                          .slice(0, 5)
                          .map((factura) => (
                            <tr key={factura.id} className="hover:bg-purple-50">
                              <td className="px-6 py-4 text-sm font-medium text-purple-600">{factura.folio}</td>
                              <td className="px-6 py-4 text-sm text-gray-600">{formatDate(factura.fecha)}</td>
                              <td className="px-6 py-4 text-sm text-gray-900">{factura.receptorNombre || 'N/A'}</td>
                              <td className="px-6 py-4 text-sm font-medium text-gray-900">
                                {formatCurrency(factura.monto)}
                              </td>
                            </tr>
                          ))}
                        {!facturasEmitidas.some(f => f.tipoComprobante === 'N') && (
                          <tr>
                            <td colSpan={4} className="px-6 py-8 text-center text-purple-400">
                              No hay nóminas registradas
                            </td>
                          </tr>
                        )}
                      </>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal Factura Emitida */}
      {showModalEmitida && (
        <ModalWrapper onClose={() => setShowModalEmitida(false)} title="Nueva Factura Emitida">
          <div className="space-y-4">
            <p className="text-gray-600">Aquí irá el formulario para crear facturas emitidas.</p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Cliente</label>
                <input type="text" className="w-full border rounded-lg px-3 py-2" placeholder="Nombre del cliente" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">RFC</label>
                <input type="text" className="w-full border rounded-lg px-3 py-2" placeholder="RFC del cliente" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Concepto</label>
                <input type="text" className="w-full border rounded-lg px-3 py-2" placeholder="Descripción" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Monto</label>
                <input type="number" className="w-full border rounded-lg px-3 py-2" placeholder="0.00" />
              </div>
            </div>
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
              Crear Factura
            </button>
          </div>
        </ModalWrapper>
      )}

      {/* Modal Factura Recibida (Upload) */}
      {showModalRecibida && (
        <ModalWrapper onClose={() => setShowModalRecibida(false)} title="Subir Factura Recibida">
          <div className="space-y-4">
            <p className="text-gray-600">Sube tus archivos XML o PDF de facturas recibidas.</p>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition cursor-pointer">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <p className="mt-2 text-sm text-gray-600">
                Arrastra tus archivos aquí o haz clic para seleccionar
              </p>
              <p className="text-xs text-gray-500 mt-1">XML, PDF (máx. 10MB)</p>
              <input type="file" multiple accept=".xml,.pdf" className="hidden" />
            </div>
            <button className="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700">
              Procesar Facturas
            </button>
          </div>
        </ModalWrapper>
      )}

      {/* Modal Movimiento Bancario */}
      {showModalMovimiento && (
        <ModalWrapper onClose={() => setShowModalMovimiento(false)} title="Subir Movimiento Bancario">
          <div className="space-y-4">
            <p className="text-gray-600">Sube tu estado de cuenta bancario para conciliación.</p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Banco</label>
                <select className="w-full border rounded-lg px-3 py-2">
                  <option>Seleccionar banco</option>
                  <option>BBVA</option>
                  <option>Banorte</option>
                  <option>Santander</option>
                  <option>Bancomer</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Cuenta</label>
                <input type="text" className="w-full border rounded-lg px-3 py-2" placeholder="Número de cuenta" />
              </div>
            </div>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-green-500 transition cursor-pointer">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <p className="mt-2 text-sm text-gray-600">
                Arrastra tu estado de cuenta aquí
              </p>
              <p className="text-xs text-gray-500 mt-1">CSV, OFX, QFX, PDF</p>
              <input type="file" accept=".csv,.ofx,.qfx,.pdf" className="hidden" />
            </div>
            <button className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">
              Procesar y Conciliar
            </button>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
}

// Componente NavItem
function NavItem({ icon, label, active = false, onClick }: { icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition cursor-pointer ${
        active 
          ? 'bg-blue-600 text-white' 
          : 'text-slate-300 hover:bg-slate-800 hover:text-white'
      }`}
    >
      {icon}
      <span className="font-medium">{label}</span>
    </button>
  );
}

// Componente KPICard
function KPICard({ 
  title, amount, count, subtitle, icon, color, isCurrency = true, warning = false 
}: {
  title: string; amount: number; count: number; subtitle?: string;
  icon: React.ReactNode; color: 'blue' | 'orange' | 'green' | 'red' | 'purple';
  isCurrency?: boolean; warning?: boolean;
}) {
  const colors = {
    blue: 'border-blue-500',
    orange: 'border-orange-500',
    green: 'border-green-500',
    red: 'border-red-500',
    purple: 'border-purple-500',
  };
  const textColors = {
    blue: 'text-blue-600',
    orange: 'text-orange-600',
    green: 'text-green-600',
    red: 'text-red-600',
    purple: 'text-purple-600',
  };

  return (
    <div className={`border-l-4 ${colors[color]} bg-white rounded-lg p-4 shadow-sm`}>
      <div className="flex items-start justify-between mb-2">
        <div>
          <p className="text-sm text-gray-600 font-medium">{title}</p>
          <p className={`text-2xl font-bold ${textColors[color]} mt-1`}>
            {isCurrency ? new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(amount) : amount.toLocaleString('es-MX')}
          </p>
          {count > 0 && <p className="text-xs text-gray-500 mt-1">{count} facturas</p>}
          {subtitle && <p className="text-xs text-gray-600 mt-1">{subtitle}</p>}
        </div>
        <div className="p-2 rounded-lg bg-gray-50">{icon}</div>
      </div>
      {warning && (
        <div className="mt-2 flex items-center gap-1 text-xs text-red-600">
          <AlertTriangle size={14} />
          <span>Requieren acción</span>
        </div>
      )}
    </div>
  );
}

// Componente ModalWrapper
function ModalWrapper({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-900">{title}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 cursor-pointer">
            <X size={24} />
          </button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}