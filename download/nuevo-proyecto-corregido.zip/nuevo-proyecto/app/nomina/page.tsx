'use client';

import { useState, useEffect, useCallback } from 'react';
import { ERPLayout } from '@/components/ERPLayout';
import { useApi } from '@/hooks/useApi';
import { useEmpresa } from '@/providers/EmpresaProvider';
import { Download, Upload, Plus, Users, FileText, Building2, RefreshCw, Eye, X, ChevronDown } from 'lucide-react';

interface Empleado {
  id: string;
  nombre: string;
  rfc: string;
  curp?: string;
  nss?: string;
  puesto?: string;
  departamento?: string;
  salarioMensual?: number;
  status: string;
  _count?: { recibos: number };
}

interface ReciboNomina {
  id: string;
  folio: string;
  serie?: string;
  fecha: string;
  anio: number;
  mes: number;
  quincena: number;
  periodo: string;
  neto: number;
  totalPercepciones: number;
  totalDeducciones: number;
  sdoBase: number;
  sdoIntegrado: number;
  horasExtra: number;
  primaDominical: number;
  primaVacacional: number;
  gratificacion: number;
  otros: number;
  isr: number;
  imss: number;
  infonavit: number;
  pensionAlimenticia: number;
  otrosDeducciones: number;
  uuid: string;
  estado: string;
  empleado?: Empleado;
  empleadoId: string;
}

interface NominaStats {
  totalEmpleados: number;
  totalRecibos: number;
  totalNeto: number;
  totalIsr: number;
  totalImss: number;
}

export default function NominaPage() {
  const [tab, setTab] = useState<'empleados' | 'recibos' | 'importar'>('recibos');
  const { empresas, empresaSeleccionada, setEmpresaSeleccionada } = useEmpresa();
  const [empleados, setEmpleados] = useState<Empleado[]>([]);
  const [recibos, setRecibos] = useState<ReciboNomina[]>([]);
  const [stats, setStats] = useState<NominaStats>({ totalEmpleados: 0, totalRecibos: 0, totalNeto: 0, totalIsr: 0, totalImss: 0 });
  const [loading, setLoading] = useState(true);
  const [importing, setImporting] = useState(false);
  const [selectedRecibo, setSelectedRecibo] = useState<ReciboNomina | null>(null);
  const [showEmpleadoModal, setShowEmpleadoModal] = useState(false);
  const [filterYear, setFilterYear] = useState(new Date().getFullYear().toString());
  const [filterMonth, setFilterMonth] = useState<string>('all');
  const [filterEmpleado, setFilterEmpleado] = useState<string>('all');

  const { execute } = useApi();

  // Cargar datos de nómina
  const loadNominaData = useCallback(async () => {
    if (!empresaSeleccionada?.id) return;
    
    setLoading(true);
    try {
      const params = new URLSearchParams({ empresaId: empresaSeleccionada.id });
      if (filterYear) params.append('anio', filterYear);
      if (filterMonth !== 'all') params.append('mes', filterMonth);
      if (filterEmpleado !== 'all') params.append('empleadoId', filterEmpleado);

      const [recibosRes, empleadosRes] = await Promise.all([
        execute(`/api/nomina?${params.toString()}`),
        execute(`/api/empleados?empresaId=${empresaSeleccionada.id}`)
      ]);

      if (recibosRes?.success) {
        setRecibos(recibosRes.data || []);
        if (recibosRes.resumen) {
          setStats({
            totalEmpleados: empleadosRes?.data?.length || 0,
            totalRecibos: recibosRes.data?.length || 0,
            totalNeto: recibosRes.data?.reduce((s: number, r: ReciboNomina) => s + (r.neto || 0), 0),
            totalIsr: recibosRes.data?.reduce((s: number, r: ReciboNomina) => s + (r.isr || 0), 0),
            totalImss: recibosRes.data?.reduce((s: number, r: ReciboNomina) => s + (r.imss || 0), 0),
          });
        } else {
          setStats(prev => ({
            ...prev,
            totalRecibos: recibosRes.data?.length || 0,
            totalNeto: recibosRes.data?.reduce((s: number, r: ReciboNomina) => s + (r.neto || 0), 0) || prev.totalNeto,
            totalIsr: recibosRes.data?.reduce((s: number, r: ReciboNomina) => s + (r.isr || 0), 0) || prev.totalIsr,
            totalImss: recibosRes.data?.reduce((s: number, r: ReciboNomina) => s + (r.imss || 0), 0) || prev.totalImss,
          }));
        }
      } else {
        setRecibos([]);
      }

      if (empleadosRes?.success) {
        setEmpleados(empleadosRes.data || []);
        setStats(prev => ({ ...prev, totalEmpleados: empleadosRes.data?.length || 0 }));
      }
    } catch (error) {
      console.error('Error cargando datos de nómina:', error);
    } finally {
      setLoading(false);
    }
  }, [empresaSeleccionada, filterYear, filterMonth, filterEmpleado, execute]);

  useEffect(() => {
    if (empresaSeleccionada?.id) {
      loadNominaData();
    }
  }, [empresaSeleccionada, filterYear, filterMonth, filterEmpleado, loadNominaData]);

  // Importar CFDIs existentes
  const handleImportar = async () => {
    if (!empresaSeleccionada?.id) return;
    setImporting(true);
    try {
      const res = await execute(`/api/nomina/importar?empresaId=${empresaSeleccionada.id}`, 'POST', {});
      if (res?.success) {
        alert(`Importación completada: ${res.importados} recibos importados, ${res.errores} errores`);
        loadNominaData();
      } else {
        alert('Error en la importación: ' + (res?.error || 'Error desconocido'));
      }
    } catch (error: any) {
      alert('Error: ' + error.message);
    } finally {
      setImporting(false);
    }
  };

  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);
  const months = [
    { value: 'all', label: 'Todos' },
    { value: '1', label: 'Enero' }, { value: '2', label: 'Febrero' }, { value: '3', label: 'Marzo' },
    { value: '4', label: 'Abril' }, { value: '5', label: 'Mayo' }, { value: '6', label: 'Junio' },
    { value: '7', label: 'Julio' }, { value: '8', label: 'Agosto' }, { value: '9', label: 'Septiembre' },
    { value: '10', label: 'Octubre' }, { value: '11', label: 'Noviembre' }, { value: '12', label: 'Diciembre' },
  ];

  const tabs = [
    { key: 'recibos', label: '📄 Recibos', icon: FileText },
    { key: 'empleados', label: '👥 Empleados', icon: Users },
    { key: 'importar', label: '📥 Importar', icon: Download },
  ];

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(value || 0);

  const formatDate = (date: string) => new Date(date).toLocaleDateString('es-MX', {
    day: '2-digit', month: 'short', year: 'numeric'
  });

  if (loading && !empresaSeleccionada) {
    return (
      <ERPLayout moduleKey="nomina">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
        </div>
      </ERPLayout>
    );
  }

  return (
    <ERPLayout moduleKey="nomina">
      <div className="space-y-6">
        {/* Header con selector de empresa */}
        <div className="flex flex-wrap justify-between items-start gap-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-purple-600" />
              <select
                value={empresaSeleccionada?.id || ''}
                onChange={(e) => {
                  const empresa = empresas.find(emp => emp.id === e.target.value);
                  if (empresa) setEmpresaSeleccionada(empresa);
                }}
                className="border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium bg-white focus:ring-2 focus:ring-purple-500 outline-none min-w-[200px]"
              >
                {empresas.map(emp => (
                  <option key={emp.id} value={emp.id}>{emp.nombre}</option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-lg border border-gray-200">
              <select value={filterYear} onChange={(e) => setFilterYear(e.target.value)} className="bg-white text-xs font-medium border-none rounded px-2 py-1 outline-none">
                {years.map(y => <option key={y} value={y}>{y}</option>)}
              </select>
              <select value={filterMonth} onChange={(e) => setFilterMonth(e.target.value)} className="bg-white text-xs font-medium border-none rounded px-2 py-1 outline-none">
                {months.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
            </div>
            <button onClick={loadNominaData} className="p-2 hover:bg-gray-100 rounded-lg" title="Actualizar">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
          <div className="flex gap-2">
            <button onClick={handleImportar} disabled={importing || !empresaSeleccionada} className="px-4 py-2 border border-purple-600 text-purple-600 rounded-lg text-sm font-medium hover:bg-purple-50 disabled:opacity-50 flex items-center gap-2">
              {importing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              {importing ? 'Importando...' : 'Importar CFDIs'}
            </button>
            <button onClick={() => setShowEmpleadoModal(true)} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 flex items-center gap-2">
              <Plus className="w-4 h-4" /> Nuevo Empleado
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Empleados</p>
            <p className="text-2xl font-bold text-purple-600">{stats.totalEmpleados}</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Recibos</p>
            <p className="text-2xl font-bold text-blue-600">{stats.totalRecibos}</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Total Neto</p>
            <p className="text-xl font-bold text-emerald-600">{formatCurrency(stats.totalNeto)}</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Total ISR</p>
            <p className="text-xl font-bold text-red-600">{formatCurrency(stats.totalIsr)}</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-xs text-gray-500">Total IMSS</p>
            <p className="text-xl font-bold text-orange-600">{formatCurrency(stats.totalImss)}</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-gray-200">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key as typeof tab)}
                className={`px-4 py-2 text-sm font-medium border-b-2 transition flex items-center gap-2 ${
                  tab === t.key ? 'border-purple-600 text-purple-700' : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <Icon className="w-4 h-4" /> {t.label}
              </button>
            );
          })}
        </div>

        {/* Contenido Principal */}
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
          </div>
        ) : (
          <>
            {/* Tab Recibos */}
            {tab === 'recibos' && (
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr className="text-xs text-gray-500 border-b border-gray-200">
                      <th className="text-left px-4 py-3 font-medium">Folio</th>
                      <th className="text-left px-3 py-3 font-medium">Empleado</th>
                      <th className="text-left px-3 py-3 font-medium">Periodo</th>
                      <th className="text-right px-3 py-3 font-medium">Percepciones</th>
                      <th className="text-right px-3 py-3 font-medium">Deducciones</th>
                      <th className="text-right px-3 py-3 font-medium">Neto</th>
                      <th className="text-center px-3 py-3 font-medium">Estado</th>
                      <th className="text-center px-4 py-3 font-medium">Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recibos.map((rec) => (
                      <tr key={rec.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                        <td className="px-4 py-3">
                          <div className="font-mono text-purple-600 font-semibold text-xs">{rec.folio || rec.uuid?.slice(0, 8)}</div>
                          <div className="text-xs text-gray-400">{rec.serie || ''}</div>
                        </td>
                        <td className="px-3 py-3">
                          <div className="font-medium text-gray-900">{rec.empleado?.nombre || 'N/A'}</div>
                          <div className="text-xs text-gray-500 font-mono">{rec.empleado?.rfc || 'S/RFC'}</div>
                        </td>
                        <td className="px-3 py-3">
                          <div className="text-gray-700">{rec.periodo}</div>
                          <div className="text-xs text-gray-400">{formatDate(rec.fecha)}</div>
                        </td>
                        <td className="px-3 py-3 text-right text-emerald-600 font-medium">{formatCurrency(rec.totalPercepciones)}</td>
                        <td className="px-3 py-3 text-right text-red-600 font-medium">{formatCurrency(rec.totalDeducciones)}</td>
                        <td className="px-3 py-3 text-right font-bold text-gray-900">{formatCurrency(rec.neto)}</td>
                        <td className="px-3 py-3 text-center">
                          <span className={`px-2 py-1 text-xs font-semibold rounded ${
                            rec.estado === 'timbrado' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {rec.estado === 'timbrado' ? 'Timbrado' : rec.estado}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <button onClick={() => setSelectedRecibo(rec)} className="p-1.5 hover:bg-purple-50 rounded text-purple-600" title="Ver detalle">
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {recibos.length === 0 && (
                      <tr>
                        <td colSpan={8} className="px-4 py-12 text-center text-gray-500">
                          <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                          <p>No hay recibos de nómina para este periodo</p>
                          <p className="text-sm text-gray-400 mt-1">Usa "Importar CFDIs" para cargar recibos existentes</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Tab Empleados */}
            {tab === 'empleados' && (
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr className="text-xs text-gray-500 border-b border-gray-200">
                      <th className="text-left px-4 py-3 font-medium">ID</th>
                      <th className="text-left px-3 py-3 font-medium">Nombre</th>
                      <th className="text-left px-3 py-3 font-medium">RFC</th>
                      <th className="text-left px-3 py-3 font-medium">Puesto</th>
                      <th className="text-right px-3 py-3 font-medium">Salario Mensual</th>
                      <th className="text-center px-3 py-3 font-medium">Recibos</th>
                      <th className="text-center px-4 py-3 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {empleados.map((emp) => (
                      <tr key={emp.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                        <td className="px-4 py-3 font-mono text-purple-600 font-semibold">{emp.id.slice(-6).toUpperCase()}</td>
                        <td className="px-3 py-3 font-medium text-gray-900">{emp.nombre}</td>
                        <td className="px-3 py-3 font-mono text-xs text-gray-600">{emp.rfc}</td>
                        <td className="px-3 py-3 text-gray-700">{emp.puesto || '-'}</td>
                        <td className="px-3 py-3 text-right font-medium">{emp.salarioMensual ? formatCurrency(emp.salarioMensual) : '-'}</td>
                        <td className="px-3 py-3 text-center text-gray-700">{emp._count?.recibos || 0}</td>
                        <td className="px-4 py-3 text-center">
                          <span className={`px-2 py-1 text-xs font-semibold rounded ${
                            emp.status === 'activo' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600'
                          }`}>
                            {emp.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                    {empleados.length === 0 && (
                      <tr>
                        <td colSpan={7} className="px-4 py-12 text-center text-gray-500">
                          <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                          <p>No hay empleados registrados</p>
                          <p className="text-sm text-gray-400 mt-1">Crea empleados o importa CFDIs de nómina</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Tab Importar */}
            {tab === 'importar' && (
              <div className="bg-white rounded-2xl border border-gray-200 p-8 text-center">
                <Upload className="w-16 h-16 mx-auto mb-4 text-purple-400" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Importar Recibos de Nómina</h3>
                <p className="text-gray-500 mb-6 max-w-md mx-auto">
                  Esta función importa los CFDIs de nómina (tipo N) existentes en el sistema y los convierte en recibos de nómina estructurados.
                </p>
                <div className="bg-gray-50 rounded-xl p-4 mb-6 text-left max-w-lg mx-auto">
                  <h4 className="font-medium text-gray-700 mb-2">Lo que hace la importación:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Busca facturas tipo "N" (nómina) en la empresa seleccionada</li>
                    <li>• Extrae datos del complemento nómina 1.2 del XML</li>
                    <li>• Crea/actualiza empleados automáticamente</li>
                    <li>• Genera recibos de nómina con percepciones y deducciones</li>
                  </ul>
                </div>
                <button
                  onClick={handleImportar}
                  disabled={importing || !empresaSeleccionada}
                  className="px-6 py-3 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2 mx-auto"
                >
                  {importing ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
                  {importing ? 'Importando...' : 'Iniciar Importación'}
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Modal Detalle Recibo */}
      {selectedRecibo && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-xl">
            <div className="flex justify-between items-center p-4 border-b border-gray-200">
              <h3 className="font-semibold text-gray-900">Detalle Recibo de Nómina</h3>
              <button onClick={() => setSelectedRecibo(null)} className="p-1 hover:bg-gray-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-60px)]">
              {/* Info General */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <p className="text-xs text-gray-500">Folio</p>
                  <p className="font-semibold text-purple-600">{selectedRecibo.folio || selectedRecibo.uuid?.slice(0, 8)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Periodo</p>
                  <p className="font-semibold">{selectedRecibo.periodo}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Empleado</p>
                  <p className="font-medium">{selectedRecibo.empleado?.nombre}</p>
                  <p className="text-xs text-gray-500">{selectedRecibo.empleado?.rfc}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Fecha</p>
                  <p className="font-medium">{formatDate(selectedRecibo.fecha)}</p>
                </div>
              </div>

              {/* Percepciones */}
              <div className="mb-6">
                <h4 className="font-semibold text-emerald-700 mb-3 flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" /> Percepciones
                </h4>
                <div className="bg-emerald-50 rounded-xl p-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Sueldo Base</span>
                    <span className="font-medium">{formatCurrency(selectedRecibo.sdoBase)}</span>
                  </div>
                  {selectedRecibo.sdoIntegrado > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Sueldo Integrado</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.sdoIntegrado)}</span>
                    </div>
                  )}
                  {selectedRecibo.horasExtra > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Horas Extra</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.horasExtra)}</span>
                    </div>
                  )}
                  {selectedRecibo.primaVacacional > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Prima Vacacional</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.primaVacacional)}</span>
                    </div>
                  )}
                  {selectedRecibo.primaDominical > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Prima Dominical</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.primaDominical)}</span>
                    </div>
                  )}
                  {selectedRecibo.gratificacion > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Gratificación</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.gratificacion)}</span>
                    </div>
                  )}
                  {selectedRecibo.otros > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Otros</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.otros)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-semibold border-t border-emerald-200 pt-2 mt-2">
                    <span>Total Percepciones</span>
                    <span>{formatCurrency(selectedRecibo.totalPercepciones)}</span>
                  </div>
                </div>
              </div>

              {/* Deducciones */}
              <div className="mb-6">
                <h4 className="font-semibold text-red-700 mb-3 flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" /> Deducciones
                </h4>
                <div className="bg-red-50 rounded-xl p-4 space-y-2">
                  {selectedRecibo.isr > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>ISR</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.isr)}</span>
                    </div>
                  )}
                  {selectedRecibo.imss > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>IMSS</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.imss)}</span>
                    </div>
                  )}
                  {selectedRecibo.infonavit > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>INFONAVIT</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.infonavit)}</span>
                    </div>
                  )}
                  {selectedRecibo.pensionAlimenticia > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Pensión Alimenticia</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.pensionAlimenticia)}</span>
                    </div>
                  )}
                  {selectedRecibo.otrosDeducciones > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>Otras Deducciones</span>
                      <span className="font-medium">{formatCurrency(selectedRecibo.otrosDeducciones)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-semibold border-t border-red-200 pt-2 mt-2">
                    <span>Total Deducciones</span>
                    <span>{formatCurrency(selectedRecibo.totalDeducciones)}</span>
                  </div>
                </div>
              </div>

              {/* Total Neto */}
              <div className="bg-purple-100 rounded-xl p-4 flex justify-between items-center">
                <span className="font-semibold text-purple-900">NETO A PAGAR</span>
                <span className="text-2xl font-bold text-purple-700">{formatCurrency(selectedRecibo.neto)}</span>
              </div>

              {/* UUID */}
              <p className="text-xs text-gray-400 mt-4 text-center font-mono">{selectedRecibo.uuid}</p>
            </div>
          </div>
        </div>
      )}

      {/* Modal Nuevo Empleado (simplificado) */}
      {showEmpleadoModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-xl">
            <div className="flex justify-between items-center p-4 border-b border-gray-200">
              <h3 className="font-semibold text-gray-900">Nuevo Empleado</h3>
              <button onClick={() => setShowEmpleadoModal(false)} className="p-1 hover:bg-gray-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6">
              <p className="text-gray-500 text-sm mb-4">El formulario de registro completo estará disponible pronto. Por ahora puedes importar empleados desde los CFDIs de nómina.</p>
              <div className="flex gap-2">
                <button onClick={() => setShowEmpleadoModal(false)} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">
                  Cerrar
                </button>
                <button onClick={() => { setShowEmpleadoModal(false); setTab('importar'); }} className="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700">
                  Importar CFDIs
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </ERPLayout>
  );
}