'use client';

import { useState } from 'react';
import { ERPLayout } from '@/components/ERPLayout';

export default function CRMPage() {
  const [tab, setTab] = useState<'clientes' | 'proveedores'>('clientes');
  const [searchTerm, setSearchTerm] = useState('');

  const clientes = [
    { id: 'CLI-001', nombre: 'Grupo Modelo S.A.B.', rfc: 'GMO910101ABC', email: 'contacto@modelo.com', facturas: 24, monto: 456780, ultimoContacto: '2025-11-20' },
    { id: 'CLI-002', nombre: 'OXXO / FEMSA', rfc: 'OXX970101XYZ', email: 'pagos@oxxo.com', facturas: 18, monto: 234560, ultimoContacto: '2025-11-15' },
    { id: 'CLI-003', nombre: 'Walmart de México', rfc: 'WAL910101DEF', email: 'proveedores@walmart.com', facturas: 32, monto: 892340, ultimoContacto: '2025-11-25' },
    { id: 'CLI-004', nombre: 'Liverpool', rfc: 'LIV850101GHI', email: 'compras@liverpool.com', facturas: 12, monto: 178900, ultimoContacto: '2025-11-10' },
  ];

  const proveedores = [
    { id: 'PRO-001', nombre: 'Telmex S.A.B.', rfc: 'TLM910101ABC', email: 'facturacion@telmex.com', facturas: 12, monto: 54000, ultimoContacto: '2025-11-18' },
    { id: 'PRO-002', nombre: 'Office Depot', rfc: 'OFD910101XYZ', email: 'ventas@officedepot.mx', facturas: 8, monto: 12800, ultimoContacto: '2025-11-22' },
    { id: 'PRO-003', nombre: 'Amazon México', rfc: 'AME170101DEF', email: 'facturas@amazon.com.mx', facturas: 45, monto: 87500, ultimoContacto: '2025-11-28' },
    { id: 'PRO-004', nombre: 'CFE', rfc: 'CFE370101GHI', email: 'cobranza@cfe.mx', facturas: 12, monto: 23400, ultimoContacto: '2025-11-05' },
  ];

  const datos = tab === 'clientes' ? clientes : proveedores;
  const datosFiltrados = datos.filter(d => 
    d.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.rfc.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <ERPLayout moduleKey="crm">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-gray-900">CRM / Clientes</h3>
            <p className="text-sm text-gray-500">Clientes y proveedores identificados automáticamente por RFC en los CFDIs</p>
          </div>
          <button className="px-4 py-2 bg-pink-600 text-white rounded-lg text-sm font-medium hover:bg-pink-700">
            + Nuevo Contacto
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-gray-200">
          <button
            onClick={() => setTab('clientes')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition ${
              tab === 'clientes' ? 'border-pink-600 text-pink-700' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            👥 Clientes ({clientes.length})
          </button>
          <button
            onClick={() => setTab('proveedores')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition ${
              tab === 'proveedores' ? 'border-pink-600 text-pink-700' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            📦 Proveedores ({proveedores.length})
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <input
            type="text"
            placeholder="Buscar por nombre o RFC..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
        </div>

        {/* Tabla */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm">
          <table className="w-full">
            <thead>
              <tr className="text-xs text-gray-500 border-b border-gray-200 bg-gray-50">
                <th className="text-left px-5 py-3 font-medium">ID</th>
                <th className="text-left px-3 py-3 font-medium">Nombre</th>
                <th className="text-left px-3 py-3 font-medium">RFC</th>
                <th className="text-left px-3 py-3 font-medium">Email</th>
                <th className="text-right px-3 py-3 font-medium">Facturas</th>
                <th className="text-right px-3 py-3 font-medium">Monto Total</th>
                <th className="text-left px-5 py-3 font-medium">Último Contacto</th>
              </tr>
            </thead>
            <tbody>
              {datosFiltrados.map((item) => (
                <tr key={item.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                  <td className="px-5 py-3 font-mono text-pink-600 font-semibold">{item.id}</td>
                  <td className="px-3 py-3 text-gray-900 font-medium">{item.nombre}</td>
                  <td className="px-3 py-3 text-gray-600 font-mono text-xs">{item.rfc}</td>
                  <td className="px-3 py-3 text-gray-600">{item.email}</td>
                  <td className="px-3 py-3 text-right">
                    <span className="bg-pink-100 text-pink-800 px-2 py-0.5 rounded-full text-xs font-medium">
                      {item.facturas}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-right font-semibold text-gray-900">
                    ${item.monto.toLocaleString('es-MX')}
                  </td>
                  <td className="px-5 py-3 text-gray-500 text-xs">{item.ultimoContacto}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white rounded-xl border-l-4 border-pink-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Total Contactos</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{clientes.length + proveedores.length}</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-emerald-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Ingresos Clientes</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">${clientes.reduce((s, c) => s + c.monto, 0).toLocaleString('es-MX')}</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-amber-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Gastos Proveedores</p>
            <p className="text-2xl font-bold text-amber-600 mt-1">${proveedores.reduce((s, p) => s + p.monto, 0).toLocaleString('es-MX')}</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-blue-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">CFDIs Totales</p>
            <p className="text-2xl font-bold text-blue-600 mt-1">
              {clientes.reduce((s, c) => s + c.facturas, 0) + proveedores.reduce((s, p) => s + p.facturas, 0)}
            </p>
          </div>
        </div>
      </div>
    </ERPLayout>
  );
}