'use client';

import { useState } from 'react';
import { ERPLayout } from '@/components/ERPLayout';

export default function ReportesPage() {
  const [tipoReporte, setTipoReporte] = useState('ventas');

  const reportes = [
    { id: 'REP-001', nombre: 'Reporte de Ventas', periodo: 'Nov 2025', formato: 'PDF', tamaño: '2.4 MB', fecha: '2025-11-28' },
    { id: 'REP-002', nombre: 'Reporte de Gastos', periodo: 'Nov 2025', formato: 'Excel', tamaño: '1.8 MB', fecha: '2025-11-28' },
    { id: 'REP-003', nombre: 'XML Masivo', periodo: '2024 Completo', formato: 'ZIP', tamaño: '45.2 MB', fecha: '2025-11-25' },
    { id: 'REP-004', nombre: 'Balance General', periodo: 'Nov 2025', formato: 'PDF', tamaño: '890 KB', fecha: '2025-11-27' },
    { id: 'REP-005', nombre: 'Estado de Resultados', periodo: 'Nov 2025', formato: 'PDF', tamaño: '1.2 MB', fecha: '2025-11-27' },
  ];

  return (
    <ERPLayout moduleKey="reportes">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Reportes</h3>
            <p className="text-sm text-gray-500">Reportes fiscales, ventas, gastos, XML masivos y BI</p>
          </div>
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700">
             Generar Reporte
          </button>
        </div>

        {/* Tipos de Reportes */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { key: 'ventas', label: ' Reporte Ventas', color: 'emerald' },
            { key: 'gastos', label: '💳 Reporte Gastos', color: 'red' },
            { key: 'xml', label: '📄 Reporte XML', color: 'blue' },
            { key: 'bi', label: '📈 BI Dashboard', color: 'purple' },
          ].map((r) => (
            <button
              key={r.key}
              onClick={() => setTipoReporte(r.key)}
              className={`p-4 rounded-xl border text-left transition ${
                tipoReporte === r.key 
                  ? 'border-indigo-500 ring-2 ring-indigo-100 bg-indigo-50' 
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              <p className="text-sm font-semibold text-gray-900">{r.label}</p>
              <p className="text-xs text-gray-500 mt-1">Generar y descargar</p>
            </button>
          ))}
        </div>

        {/* Lista de Reportes */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm">
          <div className="p-5 border-b border-gray-200">
            <h3 className="font-bold text-gray-900">Reportes Generados</h3>
            <p className="text-xs text-gray-500 mt-0.5">Historial de reportes disponibles para descarga</p>
          </div>
          <table className="w-full">
            <thead>
              <tr className="text-xs text-gray-500 border-b border-gray-200 bg-gray-50">
                <th className="text-left px-5 py-3 font-medium">ID</th>
                <th className="text-left px-3 py-3 font-medium">Nombre</th>
                <th className="text-left px-3 py-3 font-medium">Periodo</th>
                <th className="text-left px-3 py-3 font-medium">Formato</th>
                <th className="text-left px-3 py-3 font-medium">Tamaño</th>
                <th className="text-left px-3 py-3 font-medium">Fecha</th>
                <th className="text-left px-5 py-3 font-medium">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {reportes.map((rep) => (
                <tr key={rep.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                  <td className="px-5 py-3 font-mono text-indigo-600 font-semibold">{rep.id}</td>
                  <td className="px-3 py-3 text-gray-900 font-medium">{rep.nombre}</td>
                  <td className="px-3 py-3 text-gray-600">{rep.periodo}</td>
                  <td className="px-3 py-3">
                    <span className={`px-2 py-0.5 text-xs font-medium rounded ${
                      rep.formato === 'PDF' ? 'bg-red-100 text-red-700' :
                      rep.formato === 'Excel' ? 'bg-emerald-100 text-emerald-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {rep.formato}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-gray-600">{rep.tamaño}</td>
                  <td className="px-3 py-3 text-gray-600 text-xs">{rep.fecha}</td>
                  <td className="px-5 py-3">
                    <button className="text-xs text-indigo-600 hover:text-indigo-800 font-medium">
                      ⬇ Descargar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* BI Preview */}
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200 rounded-2xl p-6">
          <h4 className="font-bold text-indigo-900 mb-2">📈 Dashboard BI</h4>
          <p className="text-sm text-indigo-700 mb-4">Visualización interactiva de datos fiscales y financieros</p>
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-lg">
              <p className="text-xs text-gray-500">Ingresos Anuales</p>
              <p className="text-xl font-bold text-emerald-600">$2,450,000</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-xs text-gray-500">Egresos Anuales</p>
              <p className="text-xl font-bold text-red-600">$1,230,000</p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-xs text-gray-500">Utilidad Neta</p>
              <p className="text-xl font-bold text-indigo-600">$1,220,000</p>
            </div>
          </div>
        </div>
      </div>
    </ERPLayout>
  );
}