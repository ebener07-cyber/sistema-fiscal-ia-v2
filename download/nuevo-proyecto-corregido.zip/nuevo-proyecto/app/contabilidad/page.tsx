'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ERPLayout } from '@/components/ERPLayout';
import { useEmpresa } from '@/providers/EmpresaProvider';
import { 
  BookOpen, TrendingUp, TrendingDown, FileText, 
  Download, Trash2, AlertTriangle, CheckCircle, X,
  Calendar, Building2, Loader2, DollarSign, Receipt, Users,
  CreditCard, RotateCcw
} from 'lucide-react';

const MESES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

interface Factura {
  id: string;
  folio: string;
  serie?: string;
  fecha: string;
  monto: number;
  subtotal: number;
  totalImpuestos: number;
  direccion: string;
  estado: string;
  tipoComprobante: string;
  complementoNomina?: boolean;
  emisorRfc?: string;
  emisorNombre?: string;
  receptorRfc?: string;
  receptorNombre?: string;
  uuid?: string;
  empresaId: string;
}

export default function ContabilidadPage() {
  const router = useRouter();
  const { empresaSeleccionada, empresas } = useEmpresa();
  const [loading, setLoading] = useState(true);
  const [facturas, setFacturas] = useState<Factura[]>([]);
  const [totalNetoNomina, setTotalNetoNomina] = useState(0);
  const [selectedMes, setSelectedMes] = useState<string | null>(null);
  const [limpiando, setLimpiando] = useState(false);
  const [borrandoTodo, setBorrandoTodo] = useState(false);
  const [generandoExcel, setGenerandoExcel] = useState(false);

  useEffect(() => {
    if (empresaSeleccionada) {
      cargarFacturas();
      cargarTotalNomina();
    }
  }, [empresaSeleccionada, selectedMes]);


  const cargarTotalNomina = async () => {
    if (!empresaSeleccionada) return;

    // Contabilidad siempre muestra 2026 (título del módulo). Se filtra nómina con el mismo mes seleccionado.
    const anio = '2026';
    const mes = selectedMes === null ? null : String(parseInt(selectedMes) + 1); // 0..11 -> 1..12

    try {
      const params = new URLSearchParams({
        empresaId: empresaSeleccionada.id,
        resumen: 'true',
      });

      if (mes) {
        params.append('anio', anio);
        params.append('mes', mes);
      }

      const res = await fetch(`/api/nomina?${params.toString()}`);
      const data = await res.json();
      if (data.totalNeto !== undefined) {
        setTotalNetoNomina(data.totalNeto || 0);
      }
    } catch (error) {
      console.error('Error cargando total nómina:', error);
    }
  };


  const cargarFacturas = async () => {
    if (!empresaSeleccionada) return;
    
    try {
      setLoading(true);
      const res = await fetch(`/api/facturas?empresaId=${empresaSeleccionada.id}&limit=10000`);
      const data = await res.json();
      if (data.data) {
        setFacturas(data.data);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const facturasFiltradas = facturas.filter(f => {
    if (selectedMes === null) return true;
    const mesFactura = new Date(f.fecha).getMonth();
    return mesFactura === parseInt(selectedMes);
  });

  const totalEmitidas = facturasFiltradas
    .filter(f => f.direccion === 'emitida' || f.direccion === 'emitidos')
    .reduce((sum, f) => sum + (f.monto || 0), 0);

  const totalRecibidas = facturasFiltradas
    .filter(f => f.direccion === 'recibida' || f.direccion === 'recibidos')
    .reduce((sum, f) => sum + (f.monto || 0), 0);

  const totalImpuestos = facturasFiltradas
    .reduce((sum, f) => sum + (f.totalImpuestos || 0), 0);

  // El total de nómina ahora viene de la tabla reciboNomina (vía API de nómina)
  const totalNominas = totalNetoNomina;

  const totalNotasCredito = facturasFiltradas
    .filter(f => f.tipoComprobante === 'E')
    .reduce((sum, f) => sum + (f.monto || 0), 0);

  const formatCurrency = (n: number) => 
    new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n);

  const handleLimpiarMes = async () => {
    if (!empresaSeleccionada || selectedMes === null) {
      alert('Selecciona una empresa y un mes específico para limpiar.');
      return;
    }
    
    const nombreMes = MESES[parseInt(selectedMes)];
    if (!confirm(`⚠️ ¿Estás seguro de BORRAR TODAS las facturas de ${nombreMes}?\n\nEsta acción no se puede deshacer.`)) {
      return;
    }

    setLimpiando(true);
    try {
      const res = await fetch('/api/facturas/limpiar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          empresaId: empresaSeleccionada.id,
          mes: `2026-${(parseInt(selectedMes) + 1).toString().padStart(2, '0')}`,
          tipo: 'todos' 
        }),
      });
      
      const data = await res.json();
      if (data.success) {
        alert(`✅ ${data.message}`);
        cargarFacturas();
      } else {
        alert(`❌ ${data.error}`);
      }
    } catch (error) {
      alert('Error al limpiar');
    } finally {
      setLimpiando(false);
    }
  };

  const handleBorrarTodo = async () => {
    if (!empresaSeleccionada) {
      alert('Selecciona una empresa primero');
      return;
    }
    
    if (!confirm('⚠️ ¿ESTÁS SEGURO? Esto BORRARÁ TODAS las facturas de la empresa seleccionada.\n\nEsta acción no se puede deshacer.')) return;
    
    setBorrandoTodo(true);
    try {
      const res = await fetch('/api/facturas/limpiar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          empresaId: empresaSeleccionada.id,
          mes: 'todos',
          tipo: 'todos' 
        }),
      });
      
      const data = await res.json();
      if (data.success) {
        alert(`✅ ${data.message}`);
        cargarFacturas();
      } else {
        alert(`❌ ${data.error}`);
      }
    } catch (error) {
      alert('Error al borrar');
    } finally {
      setBorrandoTodo(false);
    }
  };

  const generarExcel = async () => {
    if (!empresaSeleccionada) {
      alert('Selecciona una empresa primero');
      return;
    }
    
    setGenerandoExcel(true);
    try {
      const res = await fetch(`/api/generar-excel?empresaId=${empresaSeleccionada.id}`);
      
      if (!res.ok) {
        throw new Error('Error al generar Excel');
      }
      
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Concentrado_CFDI_2026_${new Date().getTime()}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      alert('Error al generar Excel');
    } finally {
      setGenerandoExcel(false);
    }
  };

  const getEstadoColor = (estado: string) => {
    const colores: Record<string, string> = {
      'timbrada': 'bg-emerald-100 text-emerald-700',
      'cargada': 'bg-blue-100 text-blue-700',
      'vigente': 'bg-blue-100 text-blue-700',
      'pagada': 'bg-green-100 text-green-700',
      'vencida': 'bg-red-100 text-red-700',
      'pendiente': 'bg-amber-100 text-amber-700',
      'cancelada': 'bg-gray-100 text-gray-700',
    };
    return colores[estado] || 'bg-gray-100 text-gray-700';
  };

  const getEstadoIcon = (estado: string) => {
    if (estado === 'cancelada' || estado === 'baja') {
      return <X size={12} />;
    }
    return <CheckCircle size={12} />;
  };

  return (
    <ERPLayout moduleKey="contabilidad">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Contabilidad 2026</h1>
            <p className="text-gray-500">Gestión mensual de facturas</p>
          </div>
          <div className="flex gap-3 items-center">
            {empresaSeleccionada && (
              <span className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg font-medium">
                {empresaSeleccionada.nombre}
              </span>
            )}
            <button 
              onClick={handleBorrarTodo}
              disabled={borrandoTodo}
              className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 disabled:opacity-50"
            >
              {borrandoTodo ? <Loader2 size={18} className="animate-spin" /> : <Trash2 size={18} />}
              Borrar Todo
            </button>
            <button 
              onClick={generarExcel}
              disabled={generandoExcel}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50"
            >
              {generandoExcel ? <Loader2 size={18} className="animate-spin" /> : <Download size={18} />}
              Descargar Excel
            </button>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-6 gap-4">
          <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 border-l-4 border-l-blue-500">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Emitidas</p>
                <p className="text-2xl font-bold text-blue-600 mt-1">{formatCurrency(totalEmitidas)}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {facturasFiltradas.filter(f => f.direccion === 'emitida' || f.direccion === 'emitidos').length} facturas
                </p>
              </div>
              <TrendingUp className="text-blue-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 border-l-4 border-l-purple-500">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Recibidas</p>
                <p className="text-2xl font-bold text-purple-600 mt-1">{formatCurrency(totalRecibidas)}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {facturasFiltradas.filter(f => f.direccion === 'recibida' || f.direccion === 'recibidos').length} facturas
                </p>
              </div>
              <TrendingDown className="text-purple-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 border-l-4 border-l-amber-500">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500">Impuestos</p>
                <p className="text-2xl font-bold text-amber-600 mt-1">{formatCurrency(totalImpuestos)}</p>
                <p className="text-xs text-gray-400 mt-1">IVA Trasladado</p>
              </div>
              <Receipt className="text-amber-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 border-l-4 border-l-emerald-500">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500">Balance</p>
                <p className={`text-2xl font-bold mt-1 ${totalEmitidas - totalRecibidas - totalNotasCredito >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {formatCurrency(totalEmitidas - totalRecibidas - totalNotasCredito)}
                </p>
                <p className="text-xs text-gray-400 mt-1">Emitidas - Recibidas - Notas</p>
              </div>
              <DollarSign className="text-emerald-500" size={24} />
            </div>
          </div>

          <div 
            className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 border-l-4 border-l-rose-500 cursor-pointer hover:bg-rose-50 transition"
            onClick={() => router.push('/nomina')}
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500">Nómina</p>
                <p className="text-2xl font-bold text-rose-600 mt-1">{formatCurrency(totalNominas)}</p>
                <p className="text-xs text-gray-400 mt-1">Ver nóminas →</p>
              </div>
              <Users className="text-rose-500" size={24} />
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 border-l-4 border-l-orange-500">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500">Notas Crédito</p>
                <p className="text-2xl font-bold text-orange-600 mt-1">{formatCurrency(totalNotasCredito)}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {facturasFiltradas.filter(f => f.tipoComprobante === 'E').length} notas
                </p>
              </div>
              <RotateCcw className="text-orange-500" size={24} />
            </div>
          </div>
        </div>

        {/* Pestañas de Meses */}
        <div className="bg-white p-2 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex overflow-x-auto gap-2 flex-1">
              <button
                onClick={() => setSelectedMes(null)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition ${
                  selectedMes === null ? 'bg-blue-600 text-white shadow-sm' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                Todos
              </button>
              {MESES.map((mes, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedMes(idx.toString())}
                  className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition ${
                    selectedMes === idx.toString() ? 'bg-blue-600 text-white shadow-sm' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {mes}
                </button>
              ))}
            </div>
            
            {selectedMes !== null && (
              <button
                onClick={handleLimpiarMes}
                disabled={limpiando}
                className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 text-sm ml-4 disabled:opacity-50"
              >
                {limpiando ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                {limpiando ? 'Limpiando...' : `Limpiar ${MESES[parseInt(selectedMes)]}`}
              </button>
            )}
          </div>
        </div>

        {/* Tabla */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
            <h2 className="font-bold text-lg flex items-center gap-2">
              <FileText size={20} className="text-gray-600" />
              {selectedMes !== null ? `Facturas de ${MESES[parseInt(selectedMes)]}` : 'Todas las Facturas'}
            </h2>
            <span className="text-sm text-gray-500 bg-white px-3 py-1 rounded-full border">
              {facturasFiltradas.length} registros
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Folio</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dirección</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Comprobante</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Emisor</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Receptor</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {loading ? (
                  <tr>
                    <td colSpan={8} className="p-12 text-center text-gray-500">
                      <Loader2 className="animate-spin mx-auto mb-2" size={32} />
                      Cargando facturas...
                    </td>
                  </tr>
                ) : facturasFiltradas.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-12 text-center text-gray-500">
                      <FileText size={48} className="mx-auto mb-4 text-gray-300" />
                      <p>No hay facturas en este mes</p>
                      <p className="text-xs mt-2">Sube XMLs desde el módulo de Descarga SAT</p>
                    </td>
                  </tr>
                ) : (
                  facturasFiltradas.map((f) => (
                    <tr key={f.id} className="hover:bg-gray-50 transition">
                      <td className="px-4 py-3 font-mono text-blue-600 font-medium">
                        {f.serie ? `${f.serie}-${f.folio}` : f.folio}
                      </td>
                      <td className="px-4 py-3 text-gray-600">
                        {new Date(f.fecha).toLocaleDateString('es-MX', { 
                          day: '2-digit', 
                          month: 'short', 
                          year: 'numeric' 
                        })}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          f.direccion === 'emitida' || f.direccion === 'emitidos'
                            ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'
                        }`}>
                          {f.direccion === 'emitida' || f.direccion === 'emitidos' ? '📤' : '📨'} {f.direccion}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          f.tipoComprobante === 'E' ? 'bg-orange-100 text-orange-700' :
                          f.tipoComprobante === 'N' ? 'bg-rose-100 text-rose-700' :
                          f.tipoComprobante === 'P' ? 'bg-cyan-100 text-cyan-700' :
                          'bg-gray-100 text-gray-700'
                        }`}>
                          {f.tipoComprobante === 'E' ? '📑 Nota Crédito' :
                           f.tipoComprobante === 'N' ? '👤 Nómina' :
                           f.tipoComprobante === 'P' ? '💰 Pago' :
                           '📄 Factura'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="truncate max-w-[180px]" title={f.emisorNombre}>
                          <div className="font-medium text-gray-900 truncate">{f.emisorNombre || '-'}</div>
                          <div className="text-xs text-gray-500 font-mono">{f.emisorRfc || '-'}</div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="truncate max-w-[180px]" title={f.receptorNombre}>
                          <div className="font-medium text-gray-900 truncate">{f.receptorNombre || '-'}</div>
                          <div className="text-xs text-gray-500 font-mono">{f.receptorRfc || '-'}</div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right font-bold text-gray-900">
                        {formatCurrency(f.monto)}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getEstadoColor(f.estado)}`}>
                          {getEstadoIcon(f.estado)}
                          {f.estado}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <BookOpen className="text-blue-600 mt-0.5 flex-shrink-0" size={20} />
            <div className="text-sm text-blue-800">
              <p className="font-semibold mb-1">Módulo de Contabilidad</p>
              <ul className="space-y-1 text-xs">
                <li>• Los totales se calculan solo de las facturas activas del mes seleccionado</li>
                <li>• Usa "Limpiar Mes" para borrar facturas de un mes específico antes de subir nuevas</li>
                <li>• El Excel descargado incluye concentrado mensual y detalle por mes</li>
                <li>• Las facturas se cargan automáticamente desde el módulo de Descarga SAT</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </ERPLayout>
  );
}