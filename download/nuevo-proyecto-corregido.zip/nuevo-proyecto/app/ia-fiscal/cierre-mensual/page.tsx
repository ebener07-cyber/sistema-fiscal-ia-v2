export default function CierreMensualPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white">Cierre Mensual Fiscal</h1>
      <p className="mt-4 text-gray-400">Página de cierre mensual en desarrollo.</p>
    </div>
  );
}