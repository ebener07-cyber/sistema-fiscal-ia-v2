export default function RecomendacionesPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white">Recomendaciones Fiscales</h1>
      <p className="mt-4 text-gray-400">Página de recomendaciones en desarrollo.</p>
    </div>
  );
}