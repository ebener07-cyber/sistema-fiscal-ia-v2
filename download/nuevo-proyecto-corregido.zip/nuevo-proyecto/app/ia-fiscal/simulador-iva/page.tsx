export default function SimuladorIVAPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white">Simulador IVA</h1>
      <p className="mt-4 text-gray-400">Página del simulador IVA en desarrollo.</p>
    </div>
  );
}