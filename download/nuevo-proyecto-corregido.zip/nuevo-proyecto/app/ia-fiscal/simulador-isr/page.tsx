export default function SimuladorISRPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white">Simulador ISR</h1>
      <p className="mt-4 text-gray-400">Página del simulador ISR en desarrollo.</p>
    </div>
  );
}