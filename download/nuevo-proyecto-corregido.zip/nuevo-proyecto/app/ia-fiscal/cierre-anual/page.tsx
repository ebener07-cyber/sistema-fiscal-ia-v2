export default function CierreAnualPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-white">Cierre Anual Fiscal</h1>
      <p className="mt-4 text-gray-400">Página de cierre anual en desarrollo.</p>
    </div>
  );
}