"use client";

import { useState } from 'react';

import FiscalAlert from "../../components/FiscalAlert";
import RiskGauge from "../../components/RiskGauge";
import QuickSimulation from "../../components/QuickSimulation";

interface Alert {
  id: string;
  title: string;
  description: string;
  severity: "Baja" | "Media" | "Alta";
  module: string;
}

interface Message {
  sender: "user" | "assistant";
  text: string;
}

export default function IaFiscalPage() {
  const alerts: Alert[] = [
    {
      id: "1",
      title: "Factura sin timbrar",
      description: "La factura #123 lleva 45 días sin timbrar",
      severity: "Media",
      module: "SAT",
    },
    {
      id: "2",
      title: "RFC no válido",
      description: "El proveedor 'XYZ' tiene RFC con formato incorrecto",
      severity: "Alta",
      module: "SAT",
    },
  ];

  const riskLevel: "Bajo" | "Medio" | "Alto" = "Medio";
  const percentage = 65;

  const handleSimulate = (monto: number) => {
    return {
      iva: monto * 0.16,
      isr: monto * 0.10,
    };
  };

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const newUserMessage: Message = { sender: "user", text: input };
    setMessages((prevMessages) => [...prevMessages, newUserMessage]);
    setInput("");
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/ia-fiscal/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: input }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const newAssistantMessage: Message = { sender: "assistant", text: data.reply };
      setMessages((prevMessages) => [...prevMessages, newAssistantMessage]);
    } catch (err: any) {
      console.error("Error sending message:", err);
      setError("No se pudo enviar el mensaje. Inténtalo de nuevo.");
      // Optionally add an error message to the chat
      // setMessages((prevMessages) => [...prevMessages, { sender: "assistant", text: "Error: No se pudo enviar el mensaje. Inténtalo de nuevo." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Asistente Fiscal IA</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <FiscalAlert alerts={alerts} />
        </div>
        <div>
          <RiskGauge riskLevel={riskLevel} percentage={percentage} />
        </div>
        <div className="md:col-span-2">
          <QuickSimulation onSimulate={handleSimulate} />
        </div>
      </div>

      {/* Chat Section */}
      <div className="mt-8 p-6 bg-white rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Chat con Asistente Fiscal</h2>
        <div className="h-64 overflow-y-auto mb-4 p-4 border rounded-md bg-gray-50">
          {messages.map((msg, index) => (
            <div key={index} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"} mb-3`}>
              <div className={`max-w-xs md:max-w-md p-3 rounded-lg ${msg.sender === "user" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-800"}`}>
                {msg.text}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start mb-3">
              <div className="max-w-xs md:max-w-md p-3 rounded-lg bg-gray-200 text-gray-800 animate-pulse">
                Cargando...
              </div>
            </div>
          )}
          {error && (
            <div className="flex justify-start mb-3">
              <div className="max-w-xs md:max-w-md p-3 rounded-lg bg-red-500 text-white">
                {error}
              </div>
            </div>
          )}
        </div>
        <div className="flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSendMessage();
              }
            }}
            placeholder="Escribe tu mensaje..."
            className="flex-grow p-3 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleSendMessage}
            disabled={!input.trim() || isLoading}
            className="p-3 bg-blue-600 text-white rounded-r-md hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed"
          >
            Enviar
          </button>
        </div>
      </div>
    </div>
  );
}