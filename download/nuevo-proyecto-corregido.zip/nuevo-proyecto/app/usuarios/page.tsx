'use client';

import { useState } from 'react';
import { ERPLayout } from '@/components/ERPLayout';

export default function UsuariosPage() {
  const [tab, setTab] = useState<'usuarios' | 'roles' | 'credenciales'>('usuarios');

  const usuarios = [
    { id: 'USR-001', nombre: 'Alejandro García', email: 'alejandro@empresa.com', rol: 'Admin', rfc: 'GARA850101ABC', status: 'Activo', ultimoAcceso: '2025-11-28 14:23' },
    { id: 'USR-002', nombre: 'María López', email: 'maria@empresa.com', rol: 'Contador', rfc: 'LOMA900515XYZ', status: 'Activo', ultimoAcceso: '2025-11-27 09:15' },
    { id: 'USR-003', nombre: 'Carlos Ramírez', email: 'carlos@empresa.com', rol: 'Auditor', rfc: 'RATC880920DEF', status: 'Activo', ultimoAcceso: '2025-11-25 16:40' },
    { id: 'USR-004', nombre: 'Ana Martínez', email: 'ana@empresa.com', rol: 'Consulta', rfc: 'MARA920310GHI', status: 'Inactivo', ultimoAcceso: '2025-10-15 11:20' },
  ];

  const roles = [
    { id: 'ROL-001', nombre: 'Admin', permisos: ['Todas las funciones', 'Gestión de usuarios', 'Credenciales SAT'], usuarios: 1 },
    { id: 'ROL-002', nombre: 'Contador', permisos: ['Contabilidad', 'Tributario', 'Reportes', 'Descarga SAT'], usuarios: 1 },
    { id: 'ROL-003', nombre: 'Auditor', permisos: ['Consulta', 'Reportes', 'Descarga SAT'], usuarios: 1 },
    { id: 'ROL-004', nombre: 'Consulta', permisos: ['Solo lectura'], usuarios: 1 },
  ];

  return (
    <ERPLayout moduleKey="usuarios">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Usuarios</h3>
            <p className="text-sm text-gray-500">Control de acceso por RFC, roles, permisos y credenciales SAT</p>
          </div>
          <button className="px-4 py-2 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-900">
            + Nuevo Usuario
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-gray-200">
          {[
            { key: 'usuarios', label: ' Usuarios' },
            { key: 'roles', label: '🔐 Roles y Permisos' },
            { key: 'credenciales', label: '🟢 Credenciales SAT' },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key as typeof tab)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition ${
                tab === t.key ? 'border-slate-800 text-slate-900' : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Usuarios */}
        {tab === 'usuarios' && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm">
            <table className="w-full">
              <thead>
                <tr className="text-xs text-gray-500 border-b border-gray-200 bg-gray-50">
                  <th className="text-left px-5 py-3 font-medium">ID</th>
                  <th className="text-left px-3 py-3 font-medium">Nombre</th>
                  <th className="text-left px-3 py-3 font-medium">Email</th>
                  <th className="text-left px-3 py-3 font-medium">RFC</th>
                  <th className="text-left px-3 py-3 font-medium">Rol</th>
                  <th className="text-left px-3 py-3 font-medium">Último Acceso</th>
                  <th className="text-left px-5 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {usuarios.map((usr) => (
                  <tr key={usr.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                    <td className="px-5 py-3 font-mono text-slate-600 font-semibold">{usr.id}</td>
                    <td className="px-3 py-3 text-gray-900 font-medium">{usr.nombre}</td>
                    <td className="px-3 py-3 text-gray-600">{usr.email}</td>
                    <td className="px-3 py-3 text-gray-600 font-mono text-xs">{usr.rfc}</td>
                    <td className="px-3 py-3">
                      <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-xs font-medium">
                        {usr.rol}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-gray-500 text-xs">{usr.ultimoAcceso}</td>
                    <td className="px-5 py-3">
                      <span className={`px-2 py-1 text-xs font-semibold rounded ${
                        usr.status === 'Activo' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'
                      }`}>
                        {usr.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Roles */}
        {tab === 'roles' && (
          <div className="grid grid-cols-2 gap-4">
            {roles.map((rol) => (
              <div key={rol.id} className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-bold text-gray-900">{rol.nombre}</h4>
                  <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-xs font-medium">
                    {rol.usuarios} usuario(s)
                  </span>
                </div>
                <p className="text-xs text-gray-500 mb-3">Permisos asignados:</p>
                <div className="space-y-1">
                  {rol.permisos.map((p, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-gray-700">
                      <span className="text-emerald-500">✓</span>
                      {p}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Credenciales SAT */}
        {tab === 'credenciales' && (
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h4 className="font-bold text-gray-900 mb-4">🟢 Credenciales SAT Activas</h4>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">RFC: GARA850101ABC</p>
                  <p className="text-sm text-gray-600">Alejandro García · CIEC válida hasta 31/12/2026</p>
                </div>
                <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  Activa
                </span>
              </div>
              <div className="flex items-center justify-between p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">RFC: LOMA900515XYZ</p>
                  <p className="text-sm text-gray-600">María López · CIEC expira en 15 días</p>
                </div>
                <span className="flex items-center gap-1.5 px-3 py-1 bg-amber-100 text-amber-700 text-xs font-semibold rounded-full">
                  ️ Por expirar
                </span>
              </div>
            </div>
            <button className="mt-4 px-4 py-2 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-900">
              + Agregar Credencial SAT
            </button>
          </div>
        )}
      </div>
    </ERPLayout>
  );
}