'use client';

import { useState, useEffect } from 'react';
import DashboardLayout from '@/components/DashboardLayout';
import { ClienteForm } from '@/components/forms/ClienteForm';
import { Card, CardHeader, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { useApi } from '@/hooks/useApi';
import { Edit2, Trash2, Plus } from 'lucide-react';

export default function ClientesPage() {
  const [clientes, setClientes] = useState<any[]>([]);
  const [empresas, setEmpresas] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedEmpresa, setSelectedEmpresa] = useState('');
  const [editingCliente, setEditingCliente] = useState<any>(null);
  const [deleteModal, setDeleteModal] = useState<any>(null);

  const { loading, execute } = useApi({
    onSuccess: () => {
      setShowForm(false);
      setEditingCliente(null);
      loadClientes();
    },
  });

  const { execute: executeDelete } = useApi({
    onSuccess: () => {
      setDeleteModal(null);
      loadClientes();
    },
  });

  const loadClientes = async () => {
    const params = selectedEmpresa ? `?empresaId=${selectedEmpresa}` : '';
    const result = await execute(`/api/clientes${params}`, 'GET');
    if (result?.data) {
      setClientes(result.data);
    }
  };

  const loadEmpresas = async () => {
    const result = await execute('/api/empresas', 'GET');
    if (result?.data) {
      setEmpresas(result.data);
      if (result.data.length > 0 && !selectedEmpresa) {
        setSelectedEmpresa(result.data[0].id);
      }
    }
  };

  useEffect(() => {
    loadEmpresas();
  }, []);

  useEffect(() => {
    if (selectedEmpresa || !showForm) {
      loadClientes();
    }
  }, [selectedEmpresa, !showForm]);

  const handleDeleteClick = (cliente: any) => {
    setDeleteModal(cliente);
  };

  const handleConfirmDelete = async () => {
    if (deleteModal?.id) {
      await executeDelete(`/api/clientes/${deleteModal.id}`, 'DELETE');
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Clientes</h1>
            <p className="text-gray-600 mt-1">Gestiona los clientes de tus empresas</p>
          </div>
          {selectedEmpresa && (
            <Button
              onClick={() => {
                setEditingCliente(null);
                setShowForm(!showForm);
              }}
              className="flex items-center gap-2"
            >
              <Plus size={20} />
              Nuevo Cliente
            </Button>
          )}
        </div>

        {/* Selector de Empresa */}
        {empresas.length > 0 && (
          <Card>
            <CardHeader>
              <h3 className="font-semibold">Selecciona una Empresa</h3>
            </CardHeader>
            <CardContent>
              <select
                value={selectedEmpresa}
                onChange={(e) => {
                  setSelectedEmpresa(e.target.value);
                  setShowForm(false);
                  setEditingCliente(null);
                }}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Selecciona una empresa...</option>
                {empresas.map((empresa) => (
                  <option key={empresa.id} value={empresa.id}>
                    {empresa.nombre} ({empresa.rfc})
                  </option>
                ))}
              </select>
            </CardContent>
          </Card>
        )}

        {/* Form */}
        {showForm && selectedEmpresa && (
          <ClienteForm
            empresaId={selectedEmpresa}
            initialData={editingCliente}
            onSuccess={() => {
              setShowForm(false);
              setEditingCliente(null);
              loadClientes();
            }}
          />
        )}

        {/* Tabla de Clientes */}
        {selectedEmpresa && (
          <Card>
            <CardHeader>
              <h2 className="text-xl font-bold">
                Listado de Clientes ({clientes.length})
              </h2>
            </CardHeader>
            <CardContent>
              {loading && clientes.length === 0 ? (
                <div className="text-center py-8 text-gray-500">Cargando clientes...</div>
              ) : clientes.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No hay clientes registrados. ¡Crea uno nuevo!
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          Nombre
                        </th>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          RFC
                        </th>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          Email
                        </th>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          Empresa
                        </th>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          Acciones
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {clientes.map((cliente) => (
                        <tr key={cliente.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm font-medium text-gray-900">
                            {cliente.nombre}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">{cliente.rfc}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{cliente.correo}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {cliente.empresa?.nombre}
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <div className="flex gap-2">
                              <button
                                onClick={() => {
                                  setEditingCliente(cliente);
                                  setShowForm(true);
                                }}
                                className="text-blue-600 hover:text-blue-900"
                              >
                                <Edit2 size={18} />
                              </button>
                              <button
                                onClick={() => handleDeleteClick(cliente)}
                                className="text-red-600 hover:text-red-900"
                              >
                                <Trash2 size={18} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Modal de confirmación de eliminación */}
        <Modal
          isOpen={!!deleteModal}
          onClose={() => setDeleteModal(null)}
          title="Eliminar Cliente"
          confirmText="Eliminar"
          isDangerous={true}
          onConfirm={handleConfirmDelete}
        >
          <p>
            ¿Estás seguro de que deseas eliminar <strong>{deleteModal?.nombre}</strong>?
          </p>
        </Modal>
      </div>
    </DashboardLayout>
  );
}