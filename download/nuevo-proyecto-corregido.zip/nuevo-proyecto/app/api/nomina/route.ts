import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// GET /api/nomina?empresaId=xxx&anio=2026&mes=5&resumen=true
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const empresaId = searchParams.get('empresaId');
    const anio = searchParams.get('anio');
    const mes = searchParams.get('mes');
    const empleadoId = searchParams.get('empleadoId');
    const resumen = searchParams.get('resumen') === 'true';

    if (!empresaId) {
      return NextResponse.json({ error: 'empresaId es requerido' }, { status: 400 });
    }

    // ============================================================
    // RESUMEN DE NÓMINA (para Contabilidad / Concentrado Excel)
    // ============================================================
    if (resumen) {
      const donde: any = { empresaId };
      if (anio) donde.anio = parseInt(anio);
      if (mes) donde.mes = parseInt(mes);

      const recibos = await prisma.reciboNomina.findMany({
        where: donde,
        select: { 
          neto: true, 
          xmlContent: true, 
          uuid: true, 
          folio: true,
          estado: true,
          fecha: true,
          anio: true,
          mes: true,
        },
      });

      console.log(`\n📊 RESUMEN NÓMINA - Total recibos en BD: ${recibos.length}`);

      // ✅ FILTRO CORREGIDO - Versión definitiva
      const filtrados = recibos.filter(r => {
        const xml = r.xmlContent || '';
        const uuid = (r.uuid || '').toLowerCase();
        const folio = (r.folio || '').toLowerCase();
        const estado = (r.estado || '').toLowerCase();

        // 1. Detectar si está CANCELADO
        const estaCancelado = 
          uuid.includes('cancelado') ||
          folio.includes('cancelado') ||
          estado === 'cancelado' ||
          estado === 'anulado' ||
          xml.includes('Estado="Cancelado"') ||
          xml.includes('Estatus="Cancelado"');

        if (estaCancelado) {
          return false;
        }

        // 2. Detectar si es COMPLEMENTO de nómina (ajuste)
        // Los complementos tienen <nomina12:Complemento>
        const tieneComplementoNomina = 
          xml.includes('nomina12:Complemento');

        if (tieneComplementoNomina) {
          return false;
        }

        // 3. Detectar si es recibo PRINCIPAL de nómina
        // Debe tener <nomina12:Nomina> o TipoNomina
        const esReciboPrincipal = 
          xml.includes('nomina12:Nomina') ||
          xml.includes('TipoNomina=') ||
          xml.includes('<Nomina');

        // ✅ Solo incluir recibos principales de nómina (NO cancelados, NO complementos)
        return esReciboPrincipal;
      });

      const totalNeto = filtrados.reduce((s, r) => s + (r.neto || 0), 0);

      console.log(`✅ Recibos incluidos: ${filtrados.length}`);
      console.log(`💰 Total neto: $${totalNeto.toFixed(2)}`);
      
      // Log detallado por mes
      const porMes = new Map<string, { count: number; total: number }>();
      filtrados.forEach(r => {
        const key = `${r.anio}-${String(r.mes).padStart(2, '0')}`;
        if (!porMes.has(key)) {
          porMes.set(key, { count: 0, total: 0 });
        }
        const data = porMes.get(key)!;
        data.count++;
        data.total += r.neto || 0;
      });
      
      console.log(`\n📅 Desglose por mes:`);
      Array.from(porMes.entries())
        .sort()
        .forEach(([mes, data]) => {
          console.log(`  ${mes}: ${data.count} recibos, $${data.total.toFixed(2)}`);
        });

      return NextResponse.json({
        success: true,
        totalNeto,
        totalRecibos: filtrados.length,
        totalBruto: totalNeto,
      });
    }

    // ============================================================
    // LISTADO COMPLETO DE RECIBOS DE NÓMINA
    // ============================================================
    const where: any = { empresaId };

    if (anio) where.anio = parseInt(anio);
    if (mes) where.mes = parseInt(mes);
    if (empleadoId) where.empleadoId = empleadoId;

    const recibos = await prisma.reciboNomina.findMany({
      where,
      orderBy: [{ anio: 'desc' }, { mes: 'desc' }, { quincena: 'desc' }],
      include: {
        empleado: {
          select: { id: true, nombre: true, rfc: true, puesto: true },
        },
      },
    });

    // Resumen por empleado
    const resumenEmpleados = await prisma.reciboNomina.groupBy({
      by: ['empleadoId'],
      where: { empresaId },
      _sum: {
        neto: true,
        totalPercepciones: true,
        totalDeducciones: true,
        isr: true,
        imss: true,
        infonavit: true,
      },
      _count: true,
    });

    // Obtener datos de empleados
    const empleadoIds = resumenEmpleados.map((r) => r.empleadoId);
    const empleadosData = await prisma.empleado.findMany({
      where: { id: { in: empleadoIds } },
      select: { id: true, nombre: true, rfc: true, puesto: true, status: true },
    });

    const empleadosMap = new Map(empleadosData.map((e) => [e.id, e]));

    const resumenData = resumenEmpleados.map((r) => ({
      ...empleadosMap.get(r.empleadoId),
      totalRecibos: r._count,
      totalNeto: r._sum.neto || 0,
      totalPercepciones: r._sum.totalPercepciones || 0,
      totalDeducciones: r._sum.totalDeducciones || 0,
      totalISR: r._sum.isr || 0,
      totalIMSS: r._sum.imss || 0,
      totalINFONAVIT: r._sum.infonavit || 0,
    }));

    return NextResponse.json({
      success: true,
      data: recibos,
      resumen: resumenData,
      total: recibos.length,
    });
  } catch (error: any) {
    console.error('Error GET /api/nomina:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// ============================================================
// POST /api/nomina - Crear/importar recibo de nómina desde XML
// ============================================================
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      folio, serie, fecha, fechaPago, periodo,
      anio, mes, quincena,
      salarioPercibido, totalPercepciones, totalDeducciones, neto,
      sdoBase, sdoIntegrado, horasExtra, primaDominical, primaVacacional, gratificacion, otros,
      isr, imss, infonavit, pensionAlimenticia, otrosDeducciones,
      uuid, xmlContent, pdfContent, estado,
      empleadoId, empresaId,
    } = body;

    if (!empleadoId || !empresaId || !folio || !anio || !mes) {
      return NextResponse.json(
        { error: 'empleadoId, empresaId, folio, anio y mes son requeridos' },
        { status: 400 }
      );
    }

    // Si ya existe un recibo con el mismo uuid, actualizarlo
    if (uuid) {
      const existing = await prisma.reciboNomina.findUnique({ where: { uuid } });
      if (existing) {
        const updated = await prisma.reciboNomina.update({
          where: { uuid },
          data: {
            folio, serie,
            fecha: new Date(fecha),
            fechaPago: fechaPago ? new Date(fechaPago) : null,
            periodo, anio, mes, quincena,
            salarioPercibido: parseFloat(salarioPercibido) || 0,
            totalPercepciones: parseFloat(totalPercepciones) || 0,
            totalDeducciones: parseFloat(totalDeducciones) || 0,
            neto: parseFloat(neto) || 0,
            sdoBase: parseFloat(sdoBase) || 0,
            sdoIntegrado: parseFloat(sdoIntegrado) || 0,
            horasExtra: parseFloat(horasExtra) || 0,
            primaDominical: parseFloat(primaDominical) || 0,
            primaVacacional: parseFloat(primaVacacional) || 0,
            gratificacion: parseFloat(gratificacion) || 0,
            otros: parseFloat(otros) || 0,
            isr: parseFloat(isr) || 0,
            imss: parseFloat(imss) || 0,
            infonavit: parseFloat(infonavit) || 0,
            pensionAlimenticia: parseFloat(pensionAlimenticia) || 0,
            otrosDeducciones: parseFloat(otrosDeducciones) || 0,
            xmlContent, pdfContent,
            estado: estado || 'timbrado',
          },
        });
        return NextResponse.json({ success: true, data: updated });
      }
    }

    const recibo = await prisma.reciboNomina.create({
      data: {
        folio, serie,
        fecha: new Date(fecha),
        fechaPago: fechaPago ? new Date(fechaPago) : null,
        periodo, anio, mes, quincena: quincena ? parseInt(quincena) : null,
        salarioPercibido: parseFloat(salarioPercibido) || 0,
        totalPercepciones: parseFloat(totalPercepciones) || 0,
        totalDeducciones: parseFloat(totalDeducciones) || 0,
        neto: parseFloat(neto) || 0,
        sdoBase: parseFloat(sdoBase) || 0,
        sdoIntegrado: parseFloat(sdoIntegrado) || 0,
        horasExtra: parseFloat(horasExtra) || 0,
        primaDominical: parseFloat(primaDominical) || 0,
        primaVacacional: parseFloat(primaVacacional) || 0,
        gratificacion: parseFloat(gratificacion) || 0,
        otros: parseFloat(otros) || 0,
        isr: parseFloat(isr) || 0,
        imss: parseFloat(imss) || 0,
        infonavit: parseFloat(infonavit) || 0,
        pensionAlimenticia: parseFloat(pensionAlimenticia) || 0,
        otrosDeducciones: parseFloat(otrosDeducciones) || 0,
        uuid, xmlContent, pdfContent,
        estado: estado || 'timbrado',
        tipoComprobante: 'N',
        empleadoId, empresaId,
      },
    });

    return NextResponse.json({ success: true, data: recibo });
  } catch (error: any) {
    console.error('Error POST /api/nomina:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}