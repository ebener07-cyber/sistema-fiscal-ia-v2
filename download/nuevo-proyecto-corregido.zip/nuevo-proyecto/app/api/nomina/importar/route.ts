import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { parseCFDIXML } from '@/lib/cfdi-parser';

// POST /api/nomina/importar - Importa recibos de nómina desde facturas CFDI tipo 'N'
export async function POST(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const empresaId = searchParams.get('empresaId');

    if (!empresaId) {
      return NextResponse.json({ error: 'empresaId es requerido' }, { status: 400 });
    }

    // 1. Obtener todas las facturas tipo 'N' (nómina) de la empresa
    const facturas = await prisma.factura.findMany({
      where: {
        empresaId,
        tipoComprobante: 'N',
      },
      include: {
        empresa: { select: { id: true, nombre: true, rfc: true } },
      },
    });

    console.log(`📋 Encontradas ${facturas.length} facturas de nómina para empresa ${empresaId}`);

    let importados = 0;
    let errores = 0;
    const results: any[] = [];

    for (const factura of facturas) {
      try {
        // Si ya tiene xmlTimbrado, parsear para extraer datos del complemento
        if (factura.xmlTimbrado) {
          const cfdiData = parseCFDIXML(factura.xmlTimbrado);
          
          if (cfdiData && cfdiData.esNomina) {
            // Extraer datos del complemento nómina
            const nominaData = extractNominaData(factura.xmlTimbrado);
            
            // Neto del recibo = Total percepciones - Total deducciones (del complemento nómina).
            // En tu parser no existe `totalNeto`, así que lo calculamos.
            const neto = (nominaData?.totalPercepciones ?? 0) - (nominaData?.totalDeducciones ?? 0);

            
            // Buscar o crear empleado


            let empleado = await prisma.empleado.findUnique({
              where: { empresaId_rfc: { empresaId, rfc: cfdiData.receptor.rfc } },
            });

            if (!empleado) {
              empleado = await prisma.empleado.create({
                data: {
                  nombre: cfdiData.receptor.nombre,
                  rfc: cfdiData.receptor.rfc,
                  empresaId,
                  status: 'activo',
                },
              });
            }

            // Determinar periodo
            const fecha = new Date(cfdiData.fecha);
            const anio = fecha.getFullYear();
            const mes = fecha.getMonth() + 1;
            const dia = fecha.getDate();
            const quincena = dia <= 15 ? 1 : 2;

            // Crear o actualizar recibo
            const reciboData: any = {
              folio: cfdiData.folio || factura.folio,
              serie: cfdiData.serie || factura.serie,
              fecha: fecha,
              anio,
              mes,
              quincena,
              periodo: `${anio}-${String(mes).padStart(2, '0')} Q${quincena}`,
              neto, // NETO del complemento nómina
              salarioPercibido: nominaData.salarioPercibido || cfdiData.subtotal,
              totalPercepciones: nominaData.totalPercepciones || cfdiData.subtotal,
              totalDeducciones: nominaData.totalDeducciones || 0,
              sdoBase: nominaData.sdoBase || 0,
              sdoIntegrado: nominaData.sdoIntegrado || 0,
              horasExtra: nominaData.horasExtra || 0,
              primaDominical: nominaData.primaDominical || 0,
              primaVacacional: nominaData.primaVacacional || 0,
              gratificacion: nominaData.gratificacion || 0,
              otros: nominaData.otros || 0,
              isr: nominaData.isr || 0,
              imss: nominaData.imss || 0,
              infonavit: nominaData.infonavit || 0,
              pensionAlimenticia: nominaData.pensionAlimenticia || 0,
              otrosDeducciones: nominaData.otrosDeducciones || 0,
              uuid: cfdiData.uuid,
              xmlContent: factura.xmlTimbrado,
              estado: factura.estado === 'Vigente' ? 'timbrado' : 'cancelado',
              tipoComprobante: 'N',
              empleadoId: empleado.id,
              empresaId,
            };


            const existing = cfdiData.uuid
              ? await prisma.reciboNomina.findUnique({ where: { uuid: cfdiData.uuid } })
              : null;

            let recibo;
            if (existing) {
              recibo = await prisma.reciboNomina.update({
                where: { id: existing.id },
                data: reciboData,
              });
            } else {
              recibo = await prisma.reciboNomina.create({ data: reciboData });
            }

            importados++;
            results.push({ uuid: cfdiData.uuid, folio: recibo.folio, status: 'ok' });
          }
        } else {
          // Factura sin XML timbrado - crear con datos básicos
          const fecha = new Date(factura.fecha);
          const anio = fecha.getFullYear();
          const mes = fecha.getMonth() + 1;
          const dia = fecha.getDate();
          const quincena = dia <= 15 ? 1 : 2;

          let empleado = await prisma.empleado.findUnique({
            where: { empresaId_rfc: { empresaId, rfc: factura.receptorRfc || 'SINRFC' } },
          });

          if (!empleado && factura.receptorNombre) {
            empleado = await prisma.empleado.create({
              data: {
                nombre: factura.receptorNombre,
                rfc: factura.receptorRfc || 'SINRFC',
                empresaId,
                status: 'activo',
              },
            });
          }

          if (empleado) {
            const existing = await prisma.reciboNomina.findFirst({
              where: { empleadoId: empleado.id, anio, mes, quincena },
            });

            if (!existing) {
              const recibo = await prisma.reciboNomina.create({
                data: {
                  folio: factura.folio,
                  serie: factura.serie,
                  fecha,
                  anio,
                  mes,
                  quincena,
                  periodo: `${anio}-${String(mes).padStart(2, '0')} Q${quincena}`,
                  neto: factura.monto,
                  salarioPercibido: factura.monto,
                  totalPercepciones: factura.monto,
                  totalDeducciones: 0,
                  uuid: factura.uuid,
                  xmlContent: factura.xmlTimbrado,
                  estado: factura.estado === 'Vigente' ? 'timbrado' : 'cancelado',
                  tipoComprobante: 'N',
                  empleadoId: empleado.id,
                  empresaId,
                },
              });
              importados++;
              results.push({ uuid: factura.uuid, folio: recibo.folio, status: 'ok' });
            }
          }
        }
      } catch (err: any) {
        errores++;
        console.error(`Error procesando factura ${factura.id}:`, err.message);
        results.push({ id: factura.id, folio: factura.folio, status: 'error', error: err.message });
      }
    }

    return NextResponse.json({
      success: true,
      message: `Importados ${importados} recibos, ${errores} errores`,
      importados,
      errores,
      results,
    });
  } catch (error: any) {
    console.error('Error POST /api/nomina/importar:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

/**
 * Extrae los datos del complemento de nómina 1.2 del XML
 */
function extractNominaData(xml: string): any {
  try {
    const parser = new (require('fast-xml-parser')).XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
    });
    const result = parser.parse(xml);
    
    const nomina = result['cfdi:Comprobante']?.['cfdi:Complemento']?.['nomina12:Nomina']
      || result['cfdi:Comprobante']?.['cfdi:Complemento']?.['Nomina']
      || result['Comprobante']?.['Complemento']?.['nomina12:Nomina'];

    if (!nomina) return {};

    const nominaAttrs = nomina['@_'] || nomina;
    const percepciones = nomina['nomina12:Percepciones'] || nomina['Percepciones'] || {};
    const deducciones = nomina['nomina12:Deducciones'] || nomina['Deducciones'] || {};
    const incapacidades = nomina['nomina12:Incapacidades'] || nomina['Incapacidades'] || {};

    // Extraer percepciones
    const percList = Array.isArray(percepciones['nomina12:Percepcion'])
      ? percepciones['nomina12:Percepcion']
      : percepciones['nomina12:Percepcion'] ? [percepciones['nomina12:Percepcion']] : [];

    let sdoBase = 0, horasExtra = 0, primaDominical = 0, primaVacacional = 0, gratificacion = 0, otros = 0;
    for (const p of percList) {
      const tipo = p['@_TipoPercepcion'] || '';
      const impExento = parseFloat(p['@_ImporteExento'] || '0') || 0;
      const impGravado = parseFloat(p['@_ImporteGravado'] || '0') || 0;
      const imp = impExento + impGravado;
      const total = parseFloat(p['@_ImporteTotal'] || '0') || imp;
      if (tipo === '001') sdoBase += total;
      else if (tipo === '019') horasExtra += total;
      else if (tipo === '010') primaDominical += total;
      else if (tipo === '011') primaVacacional += total;
      else if (tipo === '014') gratificacion += total;
      else otros += total;
    }

    // Extraer deducciones
    const dedList = Array.isArray(deducciones['nomina12:Deduccion'])
      ? deducciones['nomina12:Deduccion']
      : deducciones['nomina12:Deduccion'] ? [deducciones['nomina12:Deduccion']] : [];

    let isr = 0, imss = 0, infonavit = 0, pensionAlimenticia = 0, otrosDeducciones = 0;
    for (const d of dedList) {
      const tipo = d['@_TipoDeduccion'] || '';
      const imp = parseFloat(d['@_Importe'] || '0') || 0;
      if (tipo === '001') isr += imp; // ISR
      else if (tipo === '002') imss += imp; // IMSS
      else if (tipo === '023') infonavit += imp; // INFONAVIT
      else if (tipo === '025') pensionAlimenticia += imp; // Pensión alimenticia
      else otrosDeducciones += imp;
    }

    return {
      salarioPercibido: parseFloat(nominaAttrs['@_NumDiasPagado'] || '0') * (parseFloat(nominaAttrs['@_TotalPercepciones'] || '0') / parseFloat(nominaAttrs['@_NumDiasPagado'] || '1')),
      totalPercepciones: parseFloat(nominaAttrs['@_TotalPercepciones'] || '0') || 0,
      totalDeducciones: parseFloat(nominaAttrs['@_TotalDeducciones'] || '0') || 0,
      sdoBase, horasExtra, primaDominical, primaVacacional, gratificacion, otros,
      isr, imss, infonavit, pensionAlimenticia, otrosDeducciones,
    };
  } catch (e) {
    return {};
  }
}