import { NextRequest, NextResponse } from 'next/server';
import { createSATService } from '@/lib/sat';
import prisma from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { descargaId, rfc, password } = body;

    if (!descargaId || !rfc || !password) {
      return NextResponse.json(
        { error: 'Faltan parámetros: descargaId, rfc, password' },
        { status: 400 }
      );
    }

    // Obtener descarga de la base de datos
    const descarga = await prisma.descargaSAT.findUnique({
      where: { id: descargaId },
    });

    if (!descarga) {
      return NextResponse.json(
        { error: 'Descarga no encontrada' },
        { status: 404 }
      );
    }

    // Crear servicio SAT
    const satService = createSATService({ rfc, password });

    // Verificar estado
    const estado = await satService.verificarEstado(descarga.solicitudId ?? '');

    // Actualizar en base de datos
    const descargaActualizada = await prisma.descargaSAT.update({
      where: { id: descargaId },
      data: {
        estado: estado.estado,
        // codigoEstado no existe en schema; se omite
        // codigoEstado: estado.codigoEstado,
        // mensajeEstado no existe en schema; se omite
        // mensajeEstado: estado.mensaje,
        numeroCFDIs: estado.numeroCFDIs || 0,
        // numeroPaquetes no existe en schema; se omite
        // numeroPaquetes: estado.paquetes?.length || 0,
        // fechaUltimaActualizacion no existe en schema; se omite
        // fechaUltimaActualizacion: new Date(),

      },
    });

    return NextResponse.json({
      success: true,
      descarga: descargaActualizada,
      estadoSAT: estado,
    });
  } catch (error: any) {
    console.error('Error en verificar estado:', error);
    return NextResponse.json(
      { error: error.message || 'Error al verificar estado de descarga' },
      { status: 500 }
    );
  }
}