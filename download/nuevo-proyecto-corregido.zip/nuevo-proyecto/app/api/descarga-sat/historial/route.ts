import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const empresaId = searchParams.get('empresaId');
    const limit = parseInt(searchParams.get('limit') || '50');

    if (!empresaId) {
      return NextResponse.json(
        { error: 'Falta el parámetro empresaId' },
        { status: 400 }
      );
    }

    const descargas = await prisma.descargaSAT.findMany({
      where: { empresaId },
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: {
        _count: {
          select: { facturas: true },
        },
      },
    });

    return NextResponse.json({
      success: true,
      descargas,
      total: descargas.length,
    });
  } catch (error: any) {
    console.error('Error en obtener historial:', error);
    return NextResponse.json(
      { error: error.message || 'Error al obtener historial' },
      { status: 500 }
    );
  }
}