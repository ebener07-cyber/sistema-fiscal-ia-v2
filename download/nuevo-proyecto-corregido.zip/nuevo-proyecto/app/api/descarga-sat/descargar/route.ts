import { NextRequest, NextResponse } from 'next/server';
import { createSATService } from '@/lib/sat';
import prisma from '@/lib/prisma';
import * as fs from 'fs';
import * as path from 'path';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { descargaId, rfc, password } = body;

    if (!descargaId || !rfc || !password) {
      return NextResponse.json(
        { error: 'Faltan parámetros: descargaId, rfc, password' },
        { status: 400 }
      );
    }

    // Obtener descarga
    const descarga = await prisma.descargaSAT.findUnique({
      where: { id: descargaId },
    });

    if (!descarga) {
      return NextResponse.json(
        { error: 'Descarga no encontrada' },
        { status: 404 }
      );
    }

    if (descarga.estado !== 'terminada') {
      return NextResponse.json(
        { error: 'La descarga no está terminada. Estado actual: ' + descarga.estado },
        { status: 400 }
      );
    }

    // Crear servicio SAT
    const satService = createSATService({ rfc, password });

    // Descargar paquetes
    const paquetes = descarga.paquetes ? JSON.parse(descarga.paquetes) : [];
    const downloadedFiles: string[] = [];

    if (!descarga.solicitudId) {
      return NextResponse.json({ error: 'Solicitud ID no disponible' }, { status: 400 });
    }

    for (const paqueteId of paquetes) {
      const zipBuffer = await satService.descargarPaquete(descarga.solicitudId, paqueteId);
      
      // Guardar archivo ZIP
      const uploadsDir = path.join(process.cwd(), 'uploads', 'descargas-sat');
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      const filePath = path.join(uploadsDir, `${descarga.id}_${paqueteId}`);
      fs.writeFileSync(filePath, zipBuffer);
      downloadedFiles.push(filePath);
    }

    // Actualizar descarga con archivos
    await prisma.descargaSAT.update({
      where: { id: descargaId },
      data: {
        archivosZipPath: downloadedFiles.join(','),
      },
    });

    return NextResponse.json({
      success: true,
      archivosDescargados: downloadedFiles.length,
      message: 'Paquetes descargados exitosamente',
    });
  } catch (error: any) {
    console.error('Error en descargar paquetes:', error);
    return NextResponse.json(
      { error: error.message || 'Error al descargar paquetes' },
      { status: 500 }
    );
  }
}