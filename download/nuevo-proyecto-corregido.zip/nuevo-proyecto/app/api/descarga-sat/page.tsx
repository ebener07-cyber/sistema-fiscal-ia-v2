'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ERPLayout } from '@/components/ERPLayout';
import { 
  Download, CheckCircle, AlertCircle, Calendar, FileText, 
  RefreshCw, Play, Pause, XCircle, Clock, Package,
  Loader2, Database, FileUp, Eye, Trash2
} from 'lucide-react';

interface DescargaSAT {
  id: string;
  solicitudId: string;
  rfc: string;
  fechaInicial: string;
  fechaFinal: string;
  tipo: 'emitidos' | 'recibidos' | 'ambos';
  estado: 'pendiente' | 'en_proceso' | 'terminada' | 'error' | 'rechazada';
  codigoEstado?: number;
  mensajeEstado?: string;
  numeroCFDIs: number;
  numeroPaquetes: number;
  fechaSolicitud: string;
  fechaUltimaActualizacion?: string;
  fechaCompletado?: string;
  archivosZipPath?: string;
  archivosProcesados: boolean;
  empresaId: string;
  empresa?: {
    nombre: string;
    rfc: string;
  };
}

export default function DescargaSATPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState<string | null>(null);
  const [descargando, setDescargando] = useState<string | null>(null);
  const [procesando, setProcesando] = useState<string | null>(null);
  const [descargas, setDescargas] = useState<DescargaSAT[]>([]);
  const [selectedEmpresa, setSelectedEmpresa] = useState('');
  
  // Form state
  const [formData, setFormData] = useState({
    rfc: '',
    password: '',
    fechaInicial: '',
    fechaFinal: '',
    tipoSolicitud: 'recibidos' as 'emitidos' | 'recibidos',
  });

  // Cargar empresas y descargas al montar
  useEffect(() => {
    cargarEmpresas();
    cargarDescargas();
  }, []);

  // Auto-refresh para descargas pendientes
  useEffect(() => {
    const interval = setInterval(() => {
      const pendientes = descargas.filter(d => 
        d.estado === 'pendiente' || d.estado === 'en_proceso'
      );
      
      if (pendientes.length > 0) {
        console.log('Verificando descargas pendientes...', pendientes.length);
      }
    }, 30000); // Cada 30 segundos

    return () => clearInterval(interval);
  }, [descargas]);

  const cargarEmpresas = async () => {
    try {
      const res = await fetch('/api/empresas');
      const data = await res.json();
      if (data.data && data.data.length > 0) {
        setSelectedEmpresa(data.data[0].id);
        setFormData(prev => ({ ...prev, rfc: data.data[0].rfc }));
      }
    } catch (error) {
      console.error('Error cargando empresas:', error);
    }
  };

  const cargarDescargas = async () => {
    if (!selectedEmpresa) return;

    try {
      const res = await fetch(`/api/descarga-sat/historial?empresaId=${selectedEmpresa}&limit=50`);
      const data = await res.json();
      if (data.success) {
        setDescargas(data.descargas);
      }
    } catch (error) {
      console.error('Error cargando descargas:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/descarga-sat/solicitar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          empresaId: selectedEmpresa,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Error al solicitar descarga');
      }

      alert(`✅ Solicitud enviada exitosamente\n\nID de solicitud: ${data.solicitudId}\n\nPuedes verificar el estado en la tabla de abajo.`);
      
      // Limpiar formulario
      setFormData({
        rfc: formData.rfc,
        password: '',
        fechaInicial: '',
        fechaFinal: '',
        tipoSolicitud: 'recibidos',
      });

      // Recargar descargas
      await cargarDescargas();
    } catch (error: any) {
      alert(`❌ Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const verificarEstado = async (descargaId: string) => {
    setVerifying(descargaId);

    try {
      const res = await fetch('/api/descarga-sat/verificar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          descargaId,
          rfc: formData.rfc,
          password: formData.password,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Error al verificar estado');
      }

      alert(`📊 Estado: ${data.estadoSAT.estado}\n\n${data.estadoSAT.mensaje}\n\nCFDIs encontrados: ${data.estadoSAT.numeroCFDIs || 'N/A'}`);
      
      await cargarDescargas();
    } catch (error: any) {
      alert(`❌ Error: ${error.message}`);
    } finally {
      setVerifying(null);
    }
  };

  const descargarPaquetes = async (descargaId: string) => {
    setDescargando(descargaId);

    try {
      const res = await fetch('/api/descarga-sat/descargar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          descargaId,
          rfc: formData.rfc,
          password: formData.password,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Error al descargar paquetes');
      }

      alert(`✅ Descarga completada\n\nArchivos descargados: ${data.archivosDescargados}`);
      
      await cargarDescargas();
    } catch (error: any) {
      alert(`❌ Error: ${error.message}`);
    } finally {
      setDescargando(null);
    }
  };

  const procesarXMLs = async (descargaId: string) => {
    setProcesando(descargaId);

    try {
      const res = await fetch('/api/descarga-sat/procesar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ descargaId }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Error al procesar XMLs');
      }

      alert(`✅ Procesamiento completado\n\nFacturas creadas: ${data.facturasCreadas}\nTotal procesados: ${data.totalProcesados}\nErrores: ${data.totalErrores}`);
      
      await cargarDescargas();
    } catch (error: any) {
      alert(`❌ Error: ${error.message}`);
    } finally {
      setProcesando(null);
    }
  };

  const getEstadoColor = (estado: string) => {
    const colors: Record<string, string> = {
      pendiente: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      en_proceso: 'bg-blue-100 text-blue-800 border-blue-200',
      terminada: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      error: 'bg-red-100 text-red-800 border-red-200',
      rechazada: 'bg-gray-100 text-gray-800 border-gray-200',
    };
    return colors[estado] || 'bg-gray-100 text-gray-800';
  };

  const getEstadoIcon = (estado: string) => {
    const icons: Record<string, React.ReactNode> = {
      pendiente: <Clock size={16} />,
      en_proceso: <RefreshCw size={16} className="animate-spin" />,
      terminada: <CheckCircle size={16} />,
      error: <XCircle size={16} />,
      rechazada: <AlertCircle size={16} />,
    };
    return icons[estado] || <Clock size={16} />;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('es-MX', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <ERPLayout moduleKey="descarga">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Descarga SAT</h1>
            <p className="text-gray-600">Descarga masiva de CFDIs directamente del portal del SAT</p>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            SAT Conectado
          </div>
        </div>

        {/* Formulario de Solicitud */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Download className="text-rose-600" size={20} />
            Nueva Solicitud de Descarga
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">RFC *</label>
                <input
                  type="text"
                  required
                  value={formData.rfc}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contraseña CIEC *</label>
                <input
                  type="password"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
                  placeholder="Contraseña del SAT"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Fecha Inicial *</label>
                <input
                  type="date"
                  required
                  value={formData.fechaInicial}
                  onChange={(e) => setFormData({ ...formData, fechaInicial: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Fecha Final *</label>
                <input
                  type="date"
                  required
                  value={formData.fechaFinal}
                  onChange={(e) => setFormData({ ...formData, fechaFinal: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Tipo de Comprobante</label>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, tipoSolicitud: 'recibidos' })}
                  className={`flex-1 px-4 py-3 rounded-lg border-2 font-medium transition ${
                    formData.tipoSolicitud === 'recibidos'
                      ? 'border-rose-500 bg-rose-50 text-rose-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  📨 Recibidas
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, tipoSolicitud: 'emitidos' })}
                  className={`flex-1 px-4 py-3 rounded-lg border-2 font-medium transition ${
                    formData.tipoSolicitud === 'emitidos'
                      ? 'border-rose-500 bg-rose-50 text-rose-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  📤 Emitidas
                </button>
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <button
                type="submit"
                disabled={loading}
                className="flex items-center gap-2 px-6 py-3 bg-rose-600 text-white rounded-lg hover:bg-rose-700 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 size={20} className="animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    <Play size={20} />
                    Solicitar Descarga
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Historial de Descargas */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-gray-900">Historial de Descargas</h2>
              <p className="text-sm text-gray-500 mt-0.5">Últimas 50 solicitudes</p>
            </div>
            <button
              onClick={cargarDescargas}
              className="flex items-center gap-2 px-3 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg"
            >
              <RefreshCw size={16} />
              Actualizar
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Solicitud</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Período</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">CFDIs</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {descargas.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                      <Database size={48} className="mx-auto mb-4 text-gray-300" />
                      <p>No hay descargas registradas</p>
                      <p className="text-sm mt-1">Solicita tu primera descarga usando el formulario de arriba</p>
                    </td>
                  </tr>
                ) : (
                  descargas.map((descarga) => (
                    <tr key={descarga.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="font-mono text-sm text-gray-900">{descarga.solicitudId}</div>
                        <div className="text-xs text-gray-500">RFC: {descarga.rfc}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
                          descarga.tipo === 'emitidos' ? 'bg-blue-100 text-blue-800' :
                          descarga.tipo === 'recibidos' ? 'bg-purple-100 text-purple-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {descarga.tipo === 'emitidos' ? '📤' : descarga.tipo === 'recibidos' ? '📨' : ''}
                          {descarga.tipo.charAt(0).toUpperCase() + descarga.tipo.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          {formatDate(descarga.fechaInicial)}
                        </div>
                        <div className="text-xs text-gray-500">
                          a {formatDate(descarga.fechaFinal)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${getEstadoColor(descarga.estado)}`}>
                          {getEstadoIcon(descarga.estado)}
                          {descarga.estado.replace('_', ' ').toUpperCase()}
                        </span>
                        {descarga.mensajeEstado && (
                          <div className="text-xs text-gray-500 mt-1">{descarga.mensajeEstado}</div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-gray-900">
                          {descarga.numeroCFDIs || '-'}
                        </div>
                        {descarga.numeroPaquetes > 0 && (
                          <div className="text-xs text-gray-500 flex items-center gap-1">
                            <Package size={12} />
                            {descarga.numeroPaquetes} paquete(s)
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-xs text-gray-900">
                          {formatDate(descarga.fechaSolicitud)}
                        </div>
                        {descarga.fechaCompletado && (
                          <div className="text-xs text-emerald-600 mt-1">
                            Completado: {formatDate(descarga.fechaCompletado)}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-wrap gap-2">
                          {(descarga.estado === 'pendiente' || descarga.estado === 'en_proceso') && (
                            <button
                              onClick={() => verificarEstado(descarga.id)}
                              disabled={verifying === descarga.id}
                              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded-lg disabled:opacity-50"
                            >
                              {verifying === descarga.id ? (
                                <Loader2 size={14} className="animate-spin" />
                              ) : (
                                <RefreshCw size={14} />
                              )}
                              Verificar
                            </button>
                          )}
                          
                          {descarga.estado === 'terminada' && !descarga.archivosZipPath && (
                            <button
                              onClick={() => descargarPaquetes(descarga.id)}
                              disabled={descargando === descarga.id}
                              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-emerald-600 hover:bg-emerald-50 rounded-lg disabled:opacity-50"
                            >
                              {descargando === descarga.id ? (
                                <Loader2 size={14} className="animate-spin" />
                              ) : (
                                <Download size={14} />
                              )}
                              Descargar
                            </button>
                          )}
                          
                          {descarga.archivosZipPath && !descarga.archivosProcesados && (
                            <button
                              onClick={() => procesarXMLs(descarga.id)}
                              disabled={procesando === descarga.id}
                              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-purple-600 hover:bg-purple-50 rounded-lg disabled:opacity-50"
                            >
                              {procesando === descarga.id ? (
                                <Loader2 size={14} className="animate-spin" />
                              ) : (
                                <FileUp size={14} />
                              )}
                              Procesar
                            </button>
                          )}
                          
                          {descarga.archivosProcesados && (
                            <button
                              onClick={() => router.push('/facturacion')}
                              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 rounded-lg"
                            >
                              <Eye size={14} />
                              Ver Facturas
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Información Importante */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="text-amber-600 mt-0.5 flex-shrink-0" size={20} />
            <div className="text-sm text-amber-800">
              <p className="font-semibold mb-1">Información Importante</p>
              <ul className="space-y-1 text-xs">
                <li>• Las descargas pueden tardar desde unos minutos hasta varias horas dependiendo del volumen de CFDIs</li>
                <li>• El SAT permite descargar hasta 6 meses de CFDIs por solicitud</li>
                <li>• Necesitas tener tu e.firma o CIEC (Contraseña) vigente</li>
                <li>• Los XMLs descargados se procesarán automáticamente y se crearán las facturas en el sistema</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </ERPLayout>
  );
}