import { NextRequest, NextResponse } from 'next/server';
import puppeteer from 'puppeteer-core';
import prisma from '@/lib/prisma';
import * as fs from 'fs';
import * as path from 'path';

export async function POST(req: NextRequest) {
  let browser;
  
  try {
    const body = await req.json();
    const { rfc, certificatePath, keyPath, password, fechaInicial, fechaFinal, tipoSolicitud, empresaId } = body;

    console.log(' Solicitud de descarga:', { rfc, fechaInicial, fechaFinal, tipoSolicitud });
    console.log('📄 Certificado:', certificatePath);
    console.log('🔑 Llave:', keyPath);

    // Verificar que los archivos existan
    if (!certificatePath || !fs.existsSync(certificatePath)) {
      return NextResponse.json({ error: 'Certificado no encontrado' }, { status: 400 });
    }
    if (!keyPath || !fs.existsSync(keyPath)) {
      return NextResponse.json({ error: 'Llave privada no encontrada' }, { status: 400 });
    }

    // Lanzar Puppeteer
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    });

    const page = await browser.newPage();

    console.log(' Navegador iniciado, yendo al SAT...');

    // Ir al portal de descarga masiva
    await page.goto('https://cfdidescargamasivasolicitud.clouda.sat.gob.mx/', {
      waitUntil: 'networkidle2',
      timeout: 60000,
    });

    console.log('📄 Portal cargado, buscando formulario...');

    // Esperar a que cargue el formulario
    await page.waitForSelector('input[name="Rfc"]', { timeout: 15000 }).catch(async () => {
      // Si no encuentra, intentar con otros selectores
      await page.waitForSelector('#Rfc', { timeout: 10000 });
    });

    console.log('✍️  Llenando formulario...');

    // Llenar RFC
    const rfcInput = await page.$('input[name="Rfc"]') || await page.$('#Rfc');
    if (rfcInput) {
      await rfcInput.click();
      await rfcInput.type(rfc);
      console.log('✅ RFC ingresado');
    }

    // Subir certificado .cer
    const certInput = await page.$('input[type="file"][accept=".cer"]') || 
                      await page.$('input[type="file"][accept*="cer"]');
    if (certInput) {
      await certInput.uploadFile(certificatePath);
      console.log('✅ Certificado subido');
    } else {
      console.log('⚠️  No se encontró input para .cer');
    }

    // Subir llave .key
    const keyInput = await page.$('input[type="file"][accept=".key"]') || 
                     await page.$('input[type="file"][accept*="key"]');
    if (keyInput) {
      await keyInput.uploadFile(keyPath);
      console.log('✅ Llave subida');
    } else {
      console.log('⚠️  No se encontró input para .key');
    }

    // Ingresar contraseña
    const passwordInput = await page.$('input[name="Contrasena"]') || 
                          await page.$('#Contrasena') ||
                          await page.$('input[type="password"]');
    if (passwordInput) {
      await passwordInput.click();
      await passwordInput.type(password);
      console.log('✅ Contraseña ingresada');
    }

    // Tomar screenshot para debug
    const screenshotPath = path.join(process.cwd(), 'uploads', 'sat-debug.png');
    await page.screenshot({ path: screenshotPath, fullPage: true });
    console.log('📸 Screenshot guardado en:', screenshotPath);

    // Esperar a que el usuario resuelva CAPTCHA (30 segundos)
    console.log('⏳ Esperando resolución de CAPTCHA...');
    await new Promise(resolve => setTimeout(resolve, 30000));

    // Click en enviar
    const submitBtn = await page.$('button[type="submit"]') || 
                      await page.$('input[type="submit"]') ||
                      await page.$('#btnEnviar');
    
    if (submitBtn) {
      await submitBtn.click();
      console.log('✅ Formulario enviado');
    }

    // Esperar navegación
    await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 }).catch(() => {
      console.log('⚠️  No hubo navegación, continuando...');
    });

    // Tomar screenshot después de enviar
    const screenshotPath2 = path.join(process.cwd(), 'uploads', 'sat-debug2.png');
    await page.screenshot({ path: screenshotPath2, fullPage: true });
    console.log('📸 Screenshot 2 guardado');

    // Generar ID de solicitud simulado (en producción, extraer del HTML real)
    const solicitudId = `SAT-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    // Guardar en BD
    const descarga = await prisma.descargaSAT.create({
      data: {
        solicitudId,
        rfc,
        fechaInicio: new Date(fechaInicial),
        fechaFin: new Date(fechaFinal),
        tipo: tipoSolicitud || 'recibidos',
        estado: 'pendiente',
        empresaId,
        // fechaSolicitud no existe en schema; se omite

      },
    });

    console.log('✅ Descarga registrada:', descarga.id);

    return NextResponse.json({
      success: true,
      descargaId: descarga.id,
      solicitudId,
      message: 'Solicitud enviada al SAT',
    });
  } catch (error: any) {
    console.error('❌ Error:', error);
    return NextResponse.json(
      { error: error.message || 'Error al solicitar descarga' },
      { status: 500 }
    );
  } finally {
    if (browser) {
      await browser.close();
      console.log(' Navegador cerrado');
    }
  }
}