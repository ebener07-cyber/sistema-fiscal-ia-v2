import { NextRequest, NextResponse } from 'next/server';
import { parseCFDIXML, validateCFDI } from '@/lib/cfdi-parser';
import prisma from '@/lib/prisma';
import * as fs from 'fs';
import { extractXMLsFromZIP } from '@/src/lib/extractXMLsFromZIP';

/**
 * POST /api/descarga-sat/procesar
 *
 * Procesa los ZIPs descargados del SAT asociados a una `DescargaSAT`, parsea
 * cada XML como CFDI, lo valida y lo inserta en la base de datos junto con
 * sus conceptos e impuestos individuales.
 *
 * Body: { "descargaId": string }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { descargaId } = body;

    if (!descargaId || typeof descargaId !== 'string') {
      return NextResponse.json(
        { error: 'Falta el parámetro descargaId o no es un string válido' },
        { status: 400 }
      );
    }

    // 1. Obtener descarga
    const descarga = await prisma.descargaSAT.findUnique({
      where: { id: descargaId },
    });

    if (!descarga) {
      return NextResponse.json(
        { error: 'Descarga no encontrada' },
        { status: 404 }
      );
    }

    if (!descarga.archivosZipPath) {
      return NextResponse.json(
        { error: 'No hay archivos ZIP descargados para esta descarga' },
        { status: 400 }
      );
    }

    // Bug fix #2: validar empresaId antes de empezar — si es null, abortar
    // temprano en lugar de meter string vacío y romper la FK más adelante.
    if (!descarga.empresaId) {
      return NextResponse.json(
        {
          error:
            'La descarga no tiene una empresa asociada (empresaId es null). ' +
            'Asigna una empresa a la descarga antes de procesarla.',
        },
        { status: 400 }
      );
    }
    const empresaId = descarga.empresaId;

    // Bug fix #6: si descarga.tipo es null, no podemos inferir la dirección
    // correctamente. Abortamos pidiendo al usuario que lo especifique.
    if (!descarga.tipo) {
      return NextResponse.json(
        {
          error:
            'La descarga no tiene tipo (emitidos/recibidos). ' +
            'Especifica el tipo antes de procesar.',
        },
        { status: 400 }
      );
    }
    const direccion: 'emitida' | 'recibida' =
      descarga.tipo === 'emitidos' ? 'emitida' : 'recibida';

    const zipFiles = descarga.archivosZipPath
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    let totalProcesados = 0;
    let totalErrores = 0;
    let totalDuplicados = 0; // Bug fix #5: contar duplicados
    let totalXMLs = 0;
    const facturasCreadas: string[] = [];
    const erroresDetallados: string[] = [];

    // 2. Procesar cada ZIP
    for (const zipFile of zipFiles) {
      if (!fs.existsSync(zipFile)) {
        const msg = `Archivo ZIP no encontrado: ${zipFile}`;
        console.error(msg);
        erroresDetallados.push(msg);
        totalErrores++;
        continue;
      }

      const zipBuffer = fs.readFileSync(zipBuffer_safe(zipFile));
      const xmls = await extractXMLsFromZIP(zipBuffer);

      // 3. Procesar cada XML
      for (const xml of xmls) {
        totalXMLs++;
        try {
          const cfdi = parseCFDIXML(xml.content.toString('utf8'));
          if (!cfdi) {
            const msg = `${xml.name}: no se pudo parsear el CFDI`;
            console.error(msg);
            erroresDetallados.push(msg);
            totalErrores++;
            continue;
          }

          // Validar estructura del CFDI
          const validation = validateCFDI(cfdi);
          if (!validation.valid) {
            const msg = `${xml.name} (UUID ${cfdi.uuid}): ${validation.errors.join('; ')}`;
            console.error(`CFDI inválido: ${msg}`);
            erroresDetallados.push(msg);
            totalErrores++;
            continue;
          }

          // Verificar si ya existe por UUID
          const existente = await prisma.factura.findUnique({
            where: { uuid: cfdi.uuid },
            select: { id: true },
          });
          if (existente) {
            console.log(`CFDI duplicado, se omite: ${cfdi.uuid}`);
            totalDuplicados++;
            continue;
          }

          // Bug fix #3 + #4: incluir todos los campos disponibles del CFDI
          // y crear conceptos + impuestos individuales en una transacción
          // atómica (si algo falla, no queda factura huérfana sin conceptos).
          const factura = await prisma.$transaction(async (tx) => {
            const nuevaFactura = await tx.factura.create({
              data: {
                folio: cfdi.folio,
                serie: cfdi.serie ?? null,
                fecha: new Date(cfdi.fecha),
                monto: cfdi.total,
                subtotal: cfdi.subtotal,
                descuento: cfdi.descuento || 0, // Bug fix #3
                totalImpuestos: cfdi.impuestos.totalTrasladados || 0,
                moneda: cfdi.moneda,
                tipoComprobante: cfdi.tipoComprobante,
                metodoPago: cfdi.metodoPago,
                formaPago: cfdi.formaPago,
                lugarExpedicion: cfdi.lugarExpedicion || null,
                uuid: cfdi.uuid,
                direccion, // Bug fix #6
                estado: 'timbrada',
                empresaId, // Bug fix #2 — siempre string válido aquí
                receptorRfc: cfdi.receptor.rfc,
                receptorNombre: cfdi.receptor.nombre,
                receptorUsoCfdi: cfdi.receptor.usoCFDI,
                emisorRfc: cfdi.emisor.rfc,
                emisorNombre: cfdi.emisor.nombre,
                emisorRegimen: cfdi.emisor.regimenFiscal || null, // Bug fix #3
                complementoNomina: cfdi.esNomina, // Bug fix #3
                xmlOriginal: xml.content.toString('utf8'),
                descargaSATId: descarga.id,
              },
            });

            // Bug fix #1: se eliminó `noIdentificacion` (no existe en el schema)
            if (cfdi.conceptos && cfdi.conceptos.length > 0) {
              await tx.concepto.createMany({
                data: cfdi.conceptos.map((c) => ({
                  facturaId: nuevaFactura.id,
                  claveProdServ: c.claveProdServ,
                  claveUnidad: c.claveUnidad,
                  unidad: c.unidad || 'Pieza',
                  descripcion: c.descripcion,
                  cantidad: c.cantidad,
                  valorUnitario: c.valorUnitario,
                  importe: c.importe,
                  objetoImpuesto: '02',
                })),
              });
            }

            // Bug fix #4: crear registros individuales de Impuesto.
            // El parser CFDI actual sólo expone los totales (trasladados /
            // retenidos), no el desglose por tasa. Para no perder el dato
            // creamos un registro agregado por cada tipo.
            const impuestosACrear: Array<{
              tipo: string;
              base: number;
              tipoFactor: string;
              tasaOCuota: number;
              importe: number;
              facturaId: string;
            }> = [];

            if (cfdi.impuestos.totalTrasladados > 0) {
              impuestosACrear.push({
                tipo: 'IVA Trasladado',
                base: cfdi.subtotal - (cfdi.descuento || 0),
                tipoFactor: 'Tasa',
                tasaOCuota: 0.16, // Aproximación; en producción parsear del XML
                importe: cfdi.impuestos.totalTrasladados,
                facturaId: nuevaFactura.id,
              });
            }
            if (cfdi.impuestos.totalRetenidos > 0) {
              impuestosACrear.push({
                tipo: 'Retenciones',
                base: cfdi.subtotal - (cfdi.descuento || 0),
                tipoFactor: 'Tasa',
                tasaOCuota: 0,
                importe: cfdi.impuestos.totalRetenidos,
                facturaId: nuevaFactura.id,
              });
            }

            if (impuestosACrear.length > 0) {
              await tx.impuesto.createMany({ data: impuestosACrear });
            }

            return nuevaFactura;
          });

          facturasCreadas.push(factura.id);
          totalProcesados++;
        } catch (error: any) {
          const msg = `${xml.name}: ${error?.message || 'Error desconocido'}`;
          console.error(`Error procesando XML: ${msg}`, error);
          erroresDetallados.push(msg);
          totalErrores++;
        }
      }
    }

    // 4. Actualizar la descarga con los resultados
    await prisma.descargaSAT.update({
      where: { id: descargaId },
      data: {
        archivosProcesados: true,
        numeroCFDIs: totalProcesados,
      },
    });

    // Bug fix #8: incluir los IDs de las facturas creadas y el detalle de errores
    return NextResponse.json({
      success: true,
      descargaId,
      totalXMLs,
      totalProcesados,
      totalDuplicados,
      totalErrores,
      facturasCreadasIds: facturasCreadas,
      erroresDetallados: erroresDetallados.slice(0, 50), // Limitar tamaño de respuesta
      message: `Procesamiento completado — ${totalProcesados} creadas, ${totalDuplicados} duplicadas, ${totalErrores} errores de ${totalXMLs} XMLs totales`,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Error al procesar XMLs';
    console.error('Error en /api/descarga-sat/procesar:', error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/**
 * Helper defensivo: si por algún motivo el path llega vacío o con caracteres
 * inválidos, lanza un error claro en lugar de hacer que fs.readFileSync
 * devuelva algo confuso.
 */
function zipBuffer_safe(zipFile: string): string {
  if (!zipFile || typeof zipFile !== 'string' || zipFile.trim().length === 0) {
    throw new Error(`Path de ZIP inválido: "${zipFile}"`);
  }
  return zipFile;
}
