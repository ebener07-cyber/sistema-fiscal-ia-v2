import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import ExcelJS from 'exceljs';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const empresaId = searchParams.get('empresaId');

    if (!empresaId) {
      return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
    }

    // Obtener todas las facturas del año 2026
    const facturas = await prisma.factura.findMany({
      where: {
        empresaId,
        fecha: {
          gte: new Date('2026-01-01'),
          lt: new Date('2027-01-01'),
        },
      },
      orderBy: { fecha: 'asc' },
      include: {
        conceptos: true,
        impuestos: true,
      },
    });

    // Separar emitidas, recibidas y nómina
    const emitidas = facturas.filter(f => f.direccion === 'emitida' || f.direccion === 'emitidos');
    const recibidas = facturas.filter(f => f.direccion === 'recibida' || f.direccion === 'recibidos');
    const nominas = facturas.filter(f => f.tipoComprobante === 'N');

    // Crear workbook
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Abbax-IA ERP';
    workbook.created = new Date();

    // ========== HOJA CONCENTRADO ==========
    const concentradoSheet = workbook.addWorksheet('Concentrado');
    
    concentradoSheet.mergeCells('A1:K1');
    const titleCell = concentradoSheet.getCell('A1');
    titleCell.value = 'ELECTRONICMA S.A. DE C.V. - Facturación 2026';
    titleCell.font = { bold: true, size: 14 };
    titleCell.alignment = { horizontal: 'center' };

    const headers = ['Mes/2026', 'Facturas Emitidas', '', '', '', '', 'Facturas Recibidas', '', '', '', '', 'NOMINA'];
    const subHeaders = ['', 'Sub Total', 'Descuentos', 'Impuesto', 'Imp. Retenido', 'Total', 'Sub Total', 'Descuentos', 'Impuesto', 'Imp. Retenido', 'Total', 'Total'];
    
    concentradoSheet.getRow(3).values = headers;
    concentradoSheet.getRow(4).values = subHeaders;
    
    for (let col = 1; col <= 12; col++) {
      const cell1 = concentradoSheet.getCell(3, col);
      const cell2 = concentradoSheet.getCell(4, col);
      cell1.font = { bold: true };
      cell2.font = { bold: true };
      cell1.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
      cell2.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
      cell1.alignment = { horizontal: 'center' };
      cell2.alignment = { horizontal: 'center' };
    }

    concentradoSheet.mergeCells('B3:F3');
    concentradoSheet.mergeCells('G3:K3');

    const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Sept', 'Oct', 'Nov', 'Dic'];
    let row = 5;

    const totales = {
      emitidas: { sub: 0, desc: 0, imp: 0, ret: 0, total: 0 },
      recibidas: { sub: 0, desc: 0, imp: 0, ret: 0, total: 0 },
      nomina: 0,
    };

    for (let mes = 0; mes < 12; mes++) {
      const mesEmitidas = emitidas.filter(f => f.fecha.getMonth() === mes);
      const mesRecibidas = recibidas.filter(f => f.fecha.getMonth() === mes);
      const mesNominas = nominas.filter(f => f.fecha.getMonth() === mes);

      const calcTotals = (facturasList: any[]) => ({
        sub: facturasList.reduce((sum, f) => sum + (f.subtotal || 0), 0),
        desc: facturasList.reduce((sum, f) => sum + (f.descuento || 0), 0),
        imp: facturasList.reduce((sum, f) => sum + (f.totalImpuestos || 0), 0),
        ret: 0,
        total: facturasList.reduce((sum, f) => sum + (f.monto || 0), 0),
      });

      const emitTotals = calcTotals(mesEmitidas);
      const recTotals = calcTotals(mesRecibidas);
      const nomTotal = mesNominas.reduce((sum, f) => sum + (f.monto || 0), 0);

      totales.emitidas.sub += emitTotals.sub;
      totales.emitidas.desc += emitTotals.desc;
      totales.emitidas.imp += emitTotals.imp;
      totales.emitidas.total += emitTotals.total;
      totales.recibidas.sub += recTotals.sub;
      totales.recibidas.desc += recTotals.desc;
      totales.recibidas.imp += recTotals.imp;
      totales.recibidas.total += recTotals.total;
      totales.nomina += nomTotal;

      concentradoSheet.getRow(row).values = [
        meses[mes],
        emitTotals.sub, emitTotals.desc, emitTotals.imp, emitTotals.ret, emitTotals.total,
        recTotals.sub, recTotals.desc, recTotals.imp, recTotals.ret, recTotals.total,
        nomTotal,
      ];

      for (let col = 2; col <= 12; col++) {
        concentradoSheet.getCell(row, col).numFmt = '$#,##0.00';
      }

      row++;
    }

    // Fila de totales
    concentradoSheet.getRow(row).values = [
      'TOTAL',
      totales.emitidas.sub, totales.emitidas.desc, totales.emitidas.imp, totales.emitidas.ret, totales.emitidas.total,
      totales.recibidas.sub, totales.recibidas.desc, totales.recibidas.imp, totales.recibidas.ret, totales.recibidas.total,
      totales.nomina,
    ];

    for (let col = 2; col <= 12; col++) {
      const cell = concentradoSheet.getCell(row, col);
      cell.numFmt = '$#,##0.00';
      cell.font = { bold: true };
    }

    concentradoSheet.getCell(row, 1).font = { bold: true };

    concentradoSheet.columns = [
      { width: 12 }, { width: 15 }, { width: 12 }, { width: 12 }, { width: 14 }, { width: 15 },
      { width: 15 }, { width: 12 }, { width: 12 }, { width: 14 }, { width: 15 }, { width: 15 },
    ];

    // ========== HOJAS POR MES - EMITIDAS ==========
    for (let mes = 0; mes < 12; mes++) {
      const mesEmitidas = emitidas.filter(f => f.fecha.getMonth() === mes);
      if (mesEmitidas.length === 0) continue;

      const sheet = workbook.addWorksheet(`Emitidas ${meses[mes]}`);
      
      const colHeaders = [
        'XML', 'Rfc Emisor', 'Nombre Emisor', 'Régimen Fiscal', 'Rfc Receptor', 'Nombre Receptor',
        'Tipo', 'Serie', 'Folio', 'Fecha', 'Sub Total', 'Descuento', 
        'Impuesto Trasladado', 'Impuesto Retenido', 'Total', 'UUID',
        'Método Pago', 'Forma Pago', 'Moneda', 'Uso CFDI', 'Estado'
      ];
      
      sheet.getRow(1).values = colHeaders;
      sheet.getRow(1).font = { bold: true };
      sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4472C4' } };
      sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };

      let row = 2;
      for (const f of mesEmitidas) {
        sheet.getRow(row).values = [
          `${f.uuid || ''}.xml`,
          f.emisorRfc || '',
          f.emisorNombre || '',
          f.emisorRegimen || '601', // NUEVO CAMPO
          f.receptorRfc || '',
          f.receptorNombre || '',
          f.tipoComprobante || '',
          f.serie || '',
          f.folio || '',
          f.fecha,
          f.subtotal || 0,
          f.descuento || 0,
          f.totalImpuestos || 0,
          0,
          f.monto || 0,
          f.uuid || '',
          f.metodoPago || '',
          f.formaPago || '',
          f.moneda || 'MXN',
          f.receptorUsoCfdi || '',
          f.estado || '',
        ];

        [11, 12, 13, 14, 15].forEach(col => {
          sheet.getCell(row, col).numFmt = '$#,##0.00';
        });

        row++;
      }

      sheet.columns.forEach(col => { col.width = 15; });
    }

    // ========== HOJAS POR MES - RECIBIDAS ==========
    for (let mes = 0; mes < 12; mes++) {
      const mesRecibidas = recibidas.filter(f => f.fecha.getMonth() === mes);
      if (mesRecibidas.length === 0) continue;

      const sheet = workbook.addWorksheet(`Recibidas ${meses[mes]}`);
      
      const colHeaders = [
        'XML', 'Rfc Emisor', 'Nombre Emisor', 'Régimen Fiscal', 'Rfc Receptor', 'Nombre Receptor',
        'Tipo', 'Serie', 'Folio', 'Fecha', 'Sub Total', 'Descuento',
        'Impuesto Trasladado', 'Impuesto Retenido', 'Total', 'UUID',
        'Método Pago', 'Forma Pago', 'Moneda', 'Uso CFDI', 'Estado'
      ];
      
      sheet.getRow(1).values = colHeaders;
      sheet.getRow(1).font = { bold: true };
      sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF70AD47' } };
      sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };

      let row = 2;
      for (const f of mesRecibidas) {
        sheet.getRow(row).values = [
          `${f.uuid || ''}.xml`,
          f.emisorRfc || '',
          f.emisorNombre || '',
          f.emisorRegimen || '601', // NUEVO CAMPO
          f.receptorRfc || '',
          f.receptorNombre || '',
          f.tipoComprobante || '',
          f.serie || '',
          f.folio || '',
          f.fecha,
          f.subtotal || 0,
          f.descuento || 0,
          f.totalImpuestos || 0,
          0,
          f.monto || 0,
          f.uuid || '',
          f.metodoPago || '',
          f.formaPago || '',
          f.moneda || 'MXN',
          f.receptorUsoCfdi || '',
          f.estado || '',
        ];

        [11, 12, 13, 14, 15].forEach(col => {
          sheet.getCell(row, col).numFmt = '$#,##0.00';
        });

        row++;
      }

      sheet.columns.forEach(col => { col.width = 15; });
    }

    // ========== HOJA NÓMINA ==========
    if (nominas.length > 0) {
      const nominaSheet = workbook.addWorksheet('NOMINA');
      
      const colHeaders = [
        'XML', 'Rfc Emisor', 'Nombre Emisor', 'Régimen Fiscal', 'Rfc Receptor', 'Nombre Receptor',
        'Serie', 'Folio', 'Fecha', 'Sub Total', 'Descuento',
        'Impuesto Retenido', 'Total', 'UUID', 'Estado'
      ];
      
      nominaSheet.getRow(1).values = colHeaders;
      nominaSheet.getRow(1).font = { bold: true };
      nominaSheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFC000' } };
      nominaSheet.getRow(1).font = { bold: true, color: { argb: 'FF000000' } };

      let row = 2;
      for (const f of nominas) {
        nominaSheet.getRow(row).values = [
          `${f.uuid || ''}.xml`,
          f.emisorRfc || '',
          f.emisorNombre || '',
          f.emisorRegimen || '601', // NUEVO CAMPO
          f.receptorRfc || '',
          f.receptorNombre || '',
          f.serie || '',
          f.folio || '',
          f.fecha,
          f.subtotal || 0,
          f.descuento || 0,
          f.totalImpuestos || 0,
          f.monto || 0,
          f.uuid || '',
          f.estado || '',
        ];

        [10, 11, 12, 13].forEach(col => {
          nominaSheet.getCell(row, col).numFmt = '$#,##0.00';
        });

        row++;
      }

      nominaSheet.columns.forEach(col => { col.width = 18; });
    }

    // Generar buffer
    const buffer = await workbook.xlsx.writeBuffer();

    return new NextResponse(buffer, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': 'attachment; filename=Concentrado_CFDI_2026.xlsx',
      },
    });
  } catch (error: any) {
    console.error('Error generando Excel:', error);
    return NextResponse.json(
      { error: error.message || 'Error al generar Excel' },
      { status: 500 }
    );
  }
}