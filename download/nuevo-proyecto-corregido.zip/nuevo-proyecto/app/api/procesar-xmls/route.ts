import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import prisma from "@/lib/prisma";
import AdmZip from "adm-zip";
import { parseCFDIXML } from "@/lib/cfdi-parser";

export async function POST(req: NextRequest) {
  // 1. Auth + validación
  const token = req.cookies.get("auth-token")?.value;
  if (!token) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }
  const payload = verifyToken(token);
  if (!payload) {
    return NextResponse.json({ error: "Token inválido o expirado" }, { status: 401 });
  }

  const usuario = await prisma.usuario.findUnique({
    where: { id: payload.sub },
    select: { id: true, email: true, nombre: true, empresaId: true },
  });
  if (!usuario) {
    return NextResponse.json({ error: "Usuario no encontrado" }, { status: 401 });
  }

  const formData = await req.formData();
  const file = formData.get("file") as File;
  const empresaId = formData.get("empresaId") as string;
  const tipo = formData.get("tipo") as "emitidos" | "recibidos";

  if (!file || !empresaId) {
    return NextResponse.json({ error: "Faltan parámetros" }, { status: 400 });
  }
  if (!["emitidos", "recibidos"].includes(tipo)) {
    return NextResponse.json({ error: "Tipo inválido" }, { status: 400 });
  }

  // 2. Autorización empresa: el usuario debe tener esa empresa asignada
  if (usuario.empresaId !== empresaId) {
    return NextResponse.json({ error: "Sin acceso a esta empresa" }, { status: 403 });
  }

  // 3. Límites
  if (file.size > 100 * 1024 * 1024) {
    return NextResponse.json({ error: "ZIP demasiado grande" }, { status: 413 });
  }

  // 4. Procesar en memoria (sin disco)
  const buffer = Buffer.from(await file.arrayBuffer());
  const zip = new AdmZip(buffer);
  const entries = zip.getEntries().filter(
    (e) => !e.isDirectory && e.entryName.toLowerCase().endsWith(".xml")
  );

  if (entries.length > 5000) {
    return NextResponse.json({ error: "Demasiados XMLs en el ZIP" }, { status: 413 });
  }

  // 5. Pre-check duplicados en batch
  const parsedCfdi: Array<{ cfdi: NonNullable<ReturnType<typeof parseCFDIXML>>; xml: string }> = [];
  for (const entry of entries) {
    const xml = entry.getData().toString("utf8");
    if (!xml.includes("Comprobante")) continue;
    const cfdi = parseCFDIXML(xml);
    if (cfdi?.uuid) parsedCfdi.push({ cfdi, xml });
  }

  const existentes = await prisma.factura.findMany({
    where: { uuid: { in: parsedCfdi.map((p) => p.cfdi.uuid) } },
    select: { uuid: true },
  });
  const existentesSet = new Set(existentes.map((e) => e.uuid));

  // 6. Procesar con transacción
  let totalProcesados = 0,
    totalDuplicados = 0,
    totalErrores = 0;
  const erroresDetallados: string[] = [];

  for (const { cfdi, xml } of parsedCfdi) {
    if (existentesSet.has(cfdi.uuid)) {
      totalDuplicados++;
      continue;
    }

    const fecha = new Date(cfdi.fecha);
    if (isNaN(fecha.getTime())) {
      totalErrores++;
      erroresDetallados.push(`${cfdi.uuid}: Fecha inválida`);
      continue;
    }

    try {
      await prisma.$transaction(async (tx) => {
        const factura = await tx.factura.create({
          data: {
            folio: cfdi.folio || "S/F",
            serie: cfdi.serie || null,
            fecha,
            monto: cfdi.total,
            subtotal: cfdi.subtotal,
            totalImpuestos: cfdi.impuestos.totalTrasladados,
            descuento: cfdi.descuento,
            moneda: cfdi.moneda,
            // tipoCambio es Float @default(1) en el schema, no nullable
            tipoCambio: cfdi.moneda === "MXN" ? 1 : 1,
            tipoComprobante: cfdi.tipoComprobante,
            metodoPago: cfdi.metodoPago,
            formaPago: cfdi.formaPago,
            lugarExpedicion: cfdi.lugarExpedicion,
            uuid: cfdi.uuid,
            // tipo es 'emitidos' | 'recibidos' (plural), el campo
            // direccion espera singular 'emitida' | 'recibida'
            direccion: tipo === "emitidos" ? "emitida" : "recibida",
            estado: "timbrada",
            empresaId,
            receptorRfc: cfdi.receptor.rfc,
            receptorNombre: cfdi.receptor.nombre,
            receptorUsoCfdi: cfdi.receptor.usoCFDI,
            emisorRfc: cfdi.emisor.rfc,
            emisorNombre: cfdi.emisor.nombre,
            emisorRegimen: cfdi.emisor.regimenFiscal,
            complementoNomina: cfdi.esNomina,
            xmlOriginal: xml,
          },
        });

        if (cfdi.conceptos?.length) {
          await tx.concepto.createMany({
            data: cfdi.conceptos.map((c) => ({
              facturaId: factura.id,
              claveProdServ: c.claveProdServ,
              cantidad: c.cantidad,
              claveUnidad: c.claveUnidad,
              unidad: c.unidad || "ACT",
              descripcion: c.descripcion,
              valorUnitario: c.valorUnitario,
              importe: c.importe,
              objetoImpuesto: "02",
            })),
          });
        }
      });
      totalProcesados++;
    } catch (error: any) {
      totalErrores++;
      erroresDetallados.push(`${cfdi.uuid}: ${error.message}`);
    }
  }

  return NextResponse.json({
    success: true,
    totalProcesados,
    totalErrores,
    totalDuplicados,
    erroresDetallados: erroresDetallados.slice(0, 20),
    message: `Procesadas: ${totalProcesados}, Duplicadas: ${totalDuplicados}, Errores: ${totalErrores}`,
  });
}
