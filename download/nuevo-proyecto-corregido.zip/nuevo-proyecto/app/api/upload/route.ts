import { NextRequest, NextResponse } from 'next/server';
import * as fs from 'fs';
import * as path from 'path';

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No se recibió ningún archivo' },
        { status: 400 }
      );
    }

    // Validar tipo de archivo (permitir .cer, .key y .pdf)
    const fileName = file.name.toLowerCase();
    const validExtensions = ['.pdf', '.cer', '.key'];
    const hasValidExtension = validExtensions.some(ext => fileName.endsWith(ext));

    if (!hasValidExtension) {
      return NextResponse.json(
        { error: 'Solo se aceptan archivos PDF, CER y KEY' },
        { status: 400 }
      );
    }

    // Validar tamaño (máx 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json(
        { error: 'El archivo no debe pesar más de 10MB' },
        { status: 400 }
      );
    }

    // Crear directorio si no existe
    const uploadDir = path.join(process.cwd(), 'uploads', 'constancias');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }

    // Generar nombre único
    const timestamp = Date.now();
    const safeFileName = fileName.replace(/\s+/g, '_');
    const finalFileName = `${timestamp}-${safeFileName}`;
    const filePath = path.join(uploadDir, finalFileName);

    // Guardar archivo
    const buffer = Buffer.from(await file.arrayBuffer());
    fs.writeFileSync(filePath, buffer);

    console.log(`✅ Archivo subido: ${finalFileName} (${file.size} bytes)`);

    return NextResponse.json({
      success: true,
      filePath,
      fileName: finalFileName,
      fileSize: file.size,
      message: 'Archivo subido exitosamente',
    });
  } catch (error: any) {
    console.error('❌ Error uploading file:', error);
    return NextResponse.json(
      { error: error.message || 'Error al subir archivo' },
      { status: 500 }
    );
  }
}