import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

/** GET /api/finanzas/inversiones?empresaId=xxx */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const empresaId = searchParams.get('empresaId');
  if (!empresaId) {
    return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
  }
  try {
    const inversiones = await prisma.inversion.findMany({
      where: { empresaId },
      orderBy: { fechaInversion: 'desc' },
    });
    const totalInvertido = inversiones.reduce((s, i) => s + i.montoInvertido, 0);
    const valorActual = inversiones.reduce((s, i) => s + i.valorActual, 0);
    const ganancia = valorActual - totalInvertido;
    const pctRendimiento = totalInvertido > 0 ? (ganancia / totalInvertido) * 100 : 0;
    return NextResponse.json({
      inversiones,
      totalInvertido,
      valorActual,
      ganancia,
      pctRendimiento,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/finanzas/inversiones */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, ...data } = body;
    if (!empresaId) {
      return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
    }
    const inv = await prisma.inversion.create({
      data: {
        empresaId,
        tipo: data.tipo,
        nombre: data.nombre,
        descripcion: data.descripcion ?? null,
        montoInvertido: parseFloat(data.montoInvertido) || 0,
        valorActual: parseFloat(data.valorActual ?? data.montoInvertido) || 0,
        rendimientoAnual: data.rendimientoAnual ? parseFloat(data.rendimientoAnual) : null,
        plazoMeses: parseInt(data.plazoMeses) || 0,
      },
    });
    return NextResponse.json(inv, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
