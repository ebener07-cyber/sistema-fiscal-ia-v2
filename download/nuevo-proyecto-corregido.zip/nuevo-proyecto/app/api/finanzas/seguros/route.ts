import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

/** GET /api/finanzas/seguros?empresaId=xxx */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const empresaId = searchParams.get('empresaId');
  if (!empresaId) {
    return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
  }
  try {
    const seguros = await prisma.seguro.findMany({
      where: { empresaId },
      orderBy: { createdAt: 'desc' },
    });
    const primaTotal = seguros
      .filter((s) => s.estado === 'vigente')
      .reduce((s, x) => s + x.primaMensual, 0);
    return NextResponse.json({ seguros, primaTotalMensual: primaTotal });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/finanzas/seguros */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, ...data } = body;
    if (!empresaId) {
      return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
    }
    const seguro = await prisma.seguro.create({
      data: {
        empresaId,
        tipo: data.tipo,
        nombre: data.nombre,
        aseguradora: data.aseguradora ?? null,
        sumaAsegurada: parseFloat(data.sumaAsegurada) || 0,
        primaMensual: parseFloat(data.primaMensual) || 0,
        fechaInicio: data.fechaInicio ? new Date(data.fechaInicio) : null,
        fechaFin: data.fechaFin ? new Date(data.fechaFin) : null,
        estado: data.estado ?? 'vigente',
        descripcion: data.descripcion ?? null,
      },
    });
    return NextResponse.json(seguro, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
