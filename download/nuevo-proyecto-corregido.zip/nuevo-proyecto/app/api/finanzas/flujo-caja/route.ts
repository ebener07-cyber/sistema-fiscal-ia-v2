import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { calcularFlujoCaja } from '@/lib/finanzas';

/** GET /api/finanzas/flujo-caja?empresaId=xxx&anio=2026&mes=7 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const empresaId = searchParams.get('empresaId');
  if (!empresaId) {
    return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
  }
  const hoy = new Date();
  const anio = parseInt(searchParams.get('anio') ?? String(hoy.getFullYear()));
  const mes = parseInt(searchParams.get('mes') ?? String(hoy.getMonth() + 1));
  try {
    const distribucion = await calcularFlujoCaja(empresaId, anio, mes);
    return NextResponse.json({ anio, mes, ...distribucion });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/finanzas/flujo-caja — registrar movimiento */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, ...data } = body;
    if (!empresaId) {
      return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
    }
    const mov = await prisma.movimientoFinanciero.create({
      data: {
        empresaId,
        categoria: data.categoria, // necesidad, deseo, ahorro_inversion
        tipo: data.tipo,           // ingreso, egreso
        concepto: data.concepto,
        monto: parseFloat(data.monto) || 0,
        descripcion: data.descripcion ?? null,
        fecha: data.fecha ? new Date(data.fecha) : new Date(),
      },
    });
    return NextResponse.json(mov, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
