import { NextRequest, NextResponse } from 'next/server';
import { calcularKPIs, guardarSnapshotKPIs } from '@/lib/finanzas';
import prisma from '@/lib/prisma';

/** GET /api/finanzas/kpis?empresaId=xxx&historico=true */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const empresaId = searchParams.get('empresaId');
  if (!empresaId) {
    return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
  }
  try {
    const kpis = await calcularKPIs(empresaId);
    const historico = searchParams.get('historico') === 'true'
      ? await prisma.kPIFinanciero.findMany({
          where: { empresaId },
          orderBy: { fecha: 'desc' },
          take: 12,
        })
      : [];
    return NextResponse.json({ actual: kpis, historico });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/finanzas/kpis — guarda snapshot */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId } = body;
    if (!empresaId) {
      return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
    }
    const kpis = await guardarSnapshotKPIs(empresaId);
    return NextResponse.json(kpis, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
