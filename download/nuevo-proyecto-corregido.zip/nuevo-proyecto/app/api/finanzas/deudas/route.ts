import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import {
  ordenarDeudasPorEstrategia,
  calcularPresupuestoAvalancha,
} from '@/lib/finanzas';

/** GET /api/finanzas/deudas?empresaId=xxx&estrategia=avalancha */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const empresaId = searchParams.get('empresaId');
  if (!empresaId) {
    return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
  }
  try {
    const ordenadas = await ordenarDeudasPorEstrategia(empresaId);
    const excedente = parseFloat(searchParams.get('excedente') ?? '0') || 0;
    const presupuesto = calcularPresupuestoAvalancha(ordenadas, excedente);
    return NextResponse.json({
      deudas: ordenadas,
      presupuestoAvalancha: presupuesto,
      totalDeudas: ordenadas.reduce((s, d) => s + d.saldoActual, 0),
      totalInteresMensual: ordenadas.reduce(
        (s, d) => s + (d.saldoActual * d.tasaInteresMensual) / 100,
        0
      ),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/finanzas/deudas — registrar nueva deuda */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, ...data } = body;
    if (!empresaId) {
      return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
    }
    const deuda = await prisma.deuda.create({
      data: {
        empresaId,
        pasivoId: data.pasivoId ?? null,
        nombre: data.nombre,
        acreedor: data.acreedor,
        saldoActual: parseFloat(data.saldoActual) || 0,
        tasaInteresMensual: parseFloat(data.tasaInteresMensual) || 0,
        pagoMensualMinimo: parseFloat(data.pagoMensualMinimo) || 0,
        estrategia: data.estrategia ?? 'avalancha',
        prioridad: parseInt(data.prioridad) || 99,
        estado: data.estado ?? 'activa',
        notasRenegociacion: data.notasRenegociacion ?? null,
      },
    });
    return NextResponse.json(deuda, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** PATCH /api/finanzas/deudas — actualizar deuda (pago, renegociación) */
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...data } = body;
    if (!id) {
      return NextResponse.json({ error: 'Falta id' }, { status: 400 });
    }
    const actualizada = await prisma.deuda.update({
      where: { id },
      data: {
        ...(data.saldoActual !== undefined && { saldoActual: parseFloat(data.saldoActual) }),
        ...(data.tasaInteresMensual !== undefined && {
          tasaInteresMensual: parseFloat(data.tasaInteresMensual),
        }),
        ...(data.pagoMensualMinimo !== undefined && {
          pagoMensualMinimo: parseFloat(data.pagoMensualMinimo),
        }),
        ...(data.estrategia && { estrategia: data.estrategia }),
        ...(data.estado && { estado: data.estado }),
        ...(data.notasRenegociacion !== undefined && {
          notasRenegociacion: data.notasRenegociacion,
        }),
      },
    });
    return NextResponse.json(actualizada);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
