import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { calcularPatrimonioNeto } from '@/lib/finanzas';

/** GET /api/finanzas/patrimonio?empresaId=xxx */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const empresaId = searchParams.get('empresaId');
  if (!empresaId) {
    return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
  }
  try {
    const resumen = await calcularPatrimonioNeto(empresaId);
    return NextResponse.json(resumen);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/finanzas/patrimonio — crea activo o pasivo */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, tipo, data } = body;
    if (!empresaId || !tipo || !data) {
      return NextResponse.json({ error: 'Faltan parámetros' }, { status: 400 });
    }
    if (tipo === 'activo') {
      const activo = await prisma.activo.create({
        data: {
          empresaId,
          tipo: data.tipo,
          nombre: data.nombre,
          descripcion: data.descripcion ?? null,
          valor: parseFloat(data.valor) || 0,
          esLiquidable: Boolean(data.esLiquidable),
          rendimientoAnual: data.rendimientoAnual ? parseFloat(data.rendimientoAnual) : null,
        },
      });
      return NextResponse.json(activo, { status: 201 });
    }
    if (tipo === 'pasivo') {
      const pasivo = await prisma.pasivo.create({
        data: {
          empresaId,
          tipo: data.tipo,
          nombre: data.nombre,
          descripcion: data.descripcion ?? null,
          saldo: parseFloat(data.saldo) || 0,
          tasaInteresMensual: parseFloat(data.tasaInteresMensual) || 0,
          pagoMensualMinimo: parseFloat(data.pagoMensualMinimo) || 0,
          fechaVencimiento: data.fechaVencimiento ? new Date(data.fechaVencimiento) : null,
          acreedor: data.acreedor ?? null,
          estado: data.estado ?? 'activa',
        },
      });
      return NextResponse.json(pasivo, { status: 201 });
    }
    return NextResponse.json({ error: 'tipo inválido (activo|pasivo)' }, { status: 400 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
