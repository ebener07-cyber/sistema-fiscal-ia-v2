import { NextRequest, NextResponse } from 'next/server';
import {
  obtenerOcrearFondoEmergencia,
  registrarMovimientoFondo,
} from '@/lib/finanzas';

/** GET /api/finanzas/fondo-emergencia?empresaId=xxx */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const empresaId = searchParams.get('empresaId');
  if (!empresaId) {
    return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
  }
  try {
    const fondo = await obtenerOcrearFondoEmergencia(empresaId);
    const { default: prisma } = await import('@/lib/prisma');
    const movimientos = await prisma.movimientoFondo.findMany({
      where: { fondoId: fondo.id },
      orderBy: { fecha: 'desc' },
      take: 50,
    });
    const pct = fondo.meta > 0 ? (fondo.saldoActual / fondo.meta) * 100 : 0;
    return NextResponse.json({
      ...fondo,
      movimientos,
      progreso: pct,
      faltante: Math.max(0, fondo.meta - fondo.saldoActual),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/finanzas/fondo-emergencia — registrar depósito/retiro */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, tipo, monto, descripcion } = body;
    if (!empresaId || !tipo || !monto) {
      return NextResponse.json({ error: 'Faltan parámetros' }, { status: 400 });
    }
    if (!['deposito', 'retiro'].includes(tipo)) {
      return NextResponse.json({ error: 'tipo inválido (deposito|retiro)' }, { status: 400 });
    }
    const fondo = await obtenerOcrearFondoEmergencia(empresaId);
    const actualizado = await registrarMovimientoFondo({
      fondoId: fondo.id,
      tipo,
      monto: parseFloat(monto),
      descripcion,
    });
    return NextResponse.json(actualizado, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** PATCH /api/finanzas/fondo-emergencia — actualizar meta */
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, meta } = body;
    if (!empresaId || !meta) {
      return NextResponse.json({ error: 'Faltan empresaId o meta' }, { status: 400 });
    }
    const { default: prisma } = await import('@/lib/prisma');
    const fondo = await obtenerOcrearFondoEmergencia(empresaId);
    const actualizado = await prisma.fondoEmergencia.update({
      where: { id: fondo.id },
      data: { meta: parseFloat(meta) },
    });
    return NextResponse.json(actualizado);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
