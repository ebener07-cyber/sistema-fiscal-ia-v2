import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

/** GET /api/finanzas/metas?empresaId=xxx&fase=1 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const empresaId = searchParams.get('empresaId');
  if (!empresaId) {
    return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
  }
  const where: any = { empresaId };
  const faseParam = searchParams.get('fase');
  if (faseParam) where.fase = parseInt(faseParam);
  try {
    const metas = await prisma.metaFinanciera.findMany({
      where,
      orderBy: [{ fase: 'asc' }, { createdAt: 'asc' }],
    });
    return NextResponse.json({ metas });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/finanzas/metas */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, ...data } = body;
    if (!empresaId) {
      return NextResponse.json({ error: 'Falta empresaId' }, { status: 400 });
    }
    const meta = await prisma.metaFinanciera.create({
      data: {
        empresaId,
        fase: parseInt(data.fase) || 1,
        nombre: data.nombre,
        descripcion: data.descripcion ?? null,
        meta: parseFloat(data.meta) || 0,
        progreso: parseFloat(data.progreso) || 0,
        fechaObjetivo: data.fechaObjetivo ? new Date(data.fechaObjetivo) : null,
        estado: data.estado ?? 'pendiente',
      },
    });
    return NextResponse.json(meta, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** PATCH /api/finanzas/metas — actualizar progreso */
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, progreso, estado } = body;
    if (!id) {
      return NextResponse.json({ error: 'Falta id' }, { status: 400 });
    }
    const actualizada = await prisma.metaFinanciera.update({
      where: { id },
      data: {
        ...(progreso !== undefined && { progreso: parseFloat(progreso) }),
        ...(estado && { estado }),
      },
    });
    return NextResponse.json(actualizada);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
