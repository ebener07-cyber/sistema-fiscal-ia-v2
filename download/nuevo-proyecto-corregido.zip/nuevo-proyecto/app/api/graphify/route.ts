import { NextResponse } from 'next/server';
import { loadGraphifyContext } from '@/lib/graphify';

/**
 * GET /api/graphify
 * Devuelve toda la memoria técnica del proyecto (Graphify)
 * Utilizado por el Provider para mantener contexto disponible en toda la app
 */
export async function GET() {
  try {
    const graphifyContext = await loadGraphifyContext();

    return NextResponse.json(
      {
        ...graphifyContext,
        isLoading: false,
        error: null,
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=3600, stale-while-revalidate=86400',
        },
      }
    );
  } catch (error) {
    console.error('Error en endpoint /api/graphify:', error);
    return NextResponse.json(
      {
        contexto: '',
        entidades: '',
        relaciones: '',
        componentes: '',
        rutas: '',
        mapaDelSistema: '',
        sesiones: '',
        dependencias: '',
        isLoading: false,
        error: error instanceof Error ? error.message : 'Error desconocido',
      },
      { status: 500 }
    );
  }
}
