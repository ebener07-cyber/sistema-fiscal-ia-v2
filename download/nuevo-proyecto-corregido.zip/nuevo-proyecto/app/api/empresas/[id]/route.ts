import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const body = await request.json();
    const { id } = await params;
    const empresa = await prisma.empresa.update({
      where: { id },
      data: {
        nombre: body.nombre,
        rfc: body.rfc?.toUpperCase(),
        email: body.email,
        telefono: body.telefono,
        direccion: body.direccion,
        regimenFiscal: body.regimenFiscal,
        codigoPostal: body.codigoPostal,
        usoCFDI: body.usoCFDI,
        constanciaFiscalPath: body.constanciaFiscalPath,
        constanciaVigente: body.constanciaVigente,
      },
    });
    return NextResponse.json({ data: empresa });
  } catch (error: any) {
    console.error('Error updating empresa:', error);
    return NextResponse.json(
      { error: error.message || 'Error al actualizar empresa' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await prisma.empresa.delete({
      where: { id },
    });
    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Error deleting empresa:', error);
    return NextResponse.json(
      { error: error.message || 'Error al eliminar empresa' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const body = await request.json();
    const { id } = await params;
    const empresa = await prisma.empresa.update({
      where: { id },
      data: body,
    });
    return NextResponse.json({ data: empresa });
  } catch (error: any) {
    console.error('Error updating empresa:', error);
    return NextResponse.json(
      { error: error.message || 'Error al actualizar empresa' },
      { status: 500 }
    );
  }
}