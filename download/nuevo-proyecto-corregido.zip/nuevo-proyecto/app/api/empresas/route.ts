import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET() {
  try {
    const empresas = await prisma.empresa.findMany({ orderBy: { createdAt: 'desc' } });
    return NextResponse.json({ data: empresas });
  } catch (error) {
    console.error('Error GET /api/empresas:', error);
    return NextResponse.json({ error: 'Error al obtener empresas', details: String(error) }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    console.log('Creando empresa:', body);
    const empresa = await prisma.empresa.create({ data: body });
    return NextResponse.json({ data: empresa });
  } catch (error) {
    console.error('Error POST /api/empresas:', error);
    return NextResponse.json({ error: 'Error al crear empresa', details: String(error) }, { status: 500 });
  }
}