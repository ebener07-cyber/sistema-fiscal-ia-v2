import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const body = await req.json();
    const { id } = await params;
    
    const factura = await prisma.factura.update({
      where: { id },
      data: {
        folio: body.folio,
        serie: body.serie,
        fecha: body.fecha ? new Date(body.fecha) : undefined,
        monto: body.monto,
        subtotal: body.subtotal,
        totalImpuestos: body.totalImpuestos,
        descuento: body.descuento,
        moneda: body.moneda,
        tipoCambio: body.tipoCambio,
        tipoComprobante: body.tipoComprobante,
        metodoPago: body.metodoPago,
        formaPago: body.formaPago,
        lugarExpedicion: body.lugarExpedicion,
        confirmacion: body.confirmacion,
        uuid: body.uuid,
        direccion: body.direccion,
        estado: body.estado,
        receptorRfc: body.receptorRfc,
        receptorNombre: body.receptorNombre,
        receptorUsoCfdi: body.receptorUsoCfdi,
        emisorRfc: body.emisorRfc,
        emisorNombre: body.emisorNombre,
        xmlTimbrado: body.xmlTimbrado,
        xmlOriginal: body.xmlOriginal,
        complementoPago: body.complementoPago,
        complementoNomina: body.complementoNomina,
        categoria: body.categoria,
        proveedor: body.proveedor,
        conceptosClave: body.conceptosClave,
      },
    });
    
    return NextResponse.json({ data: factura });
  } catch (error: any) {
    console.error('Error updating factura:', error);
    return NextResponse.json(
      { error: error.message || 'Error al actualizar factura' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await prisma.factura.delete({
      where: { id },
    });
    
    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Error deleting factura:', error);
    return NextResponse.json(
      { error: error.message || 'Error al eliminar factura' },
      { status: 500 }
    );
  }
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const factura = await prisma.factura.findUnique({
      where: { id },
      include: {
        cliente: {
          select: { nombre: true, rfc: true },
        },
        empresa: {
          select: { nombre: true, rfc: true },
        },
        conceptos: true,
        impuestos: true,
      },
    });
    
    if (!factura) {
      return NextResponse.json(
        { error: 'Factura no encontrada' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ data: factura });
  } catch (error: any) {
    console.error('Error fetching factura:', error);
    return NextResponse.json(
      { error: error.message || 'Error al obtener factura' },
      { status: 500 }
    );
  }
}