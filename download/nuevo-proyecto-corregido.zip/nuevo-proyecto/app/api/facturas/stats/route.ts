import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const empresaId = searchParams.get('empresaId');

    const where: any = {};
    if (empresaId) where.empresaId = empresaId;

    const porCobrar = await prisma.factura.aggregate({
      where: { ...where, direccion: 'emitida', estado: { in: ['timbrada', 'cargada', 'vigente'] } },
      _sum: { monto: true },
      _count: { id: true },
    });

    const porPagar = await prisma.factura.aggregate({
      where: { ...where, direccion: 'recibida', estado: { in: ['timbrada', 'cargada', 'pendiente'] } },
      _sum: { monto: true },
      _count: { id: true },
    });

    const timbradas = await prisma.factura.aggregate({
      where: { ...where, estado: 'timbrada' },
      _count: { id: true },
    });

    const pendientes = await prisma.factura.aggregate({
      where: { ...where, estado: { in: ['pendiente', 'cargada'] } },
      _count: { id: true },
    });

    const nomina = await prisma.factura.aggregate({
      where: { ...where, tipoComprobante: 'N' },
      _sum: { monto: true },
      _count: { id: true },
    });

    const emitidas = await prisma.factura.aggregate({
      where: { ...where, direccion: 'emitida' },
      _sum: { monto: true },
      _count: { id: true },
    });

    const recibidas = await prisma.factura.aggregate({
      where: { ...where, direccion: 'recibida' },
      _sum: { monto: true },
      _count: { id: true },
    });

    return NextResponse.json({
      success: true,
      stats: {
        porCobrar: {
          monto: porCobrar._sum.monto || 0,
          count: porCobrar._count.id,
        },
        porPagar: {
          monto: porPagar._sum.monto || 0,
          count: porPagar._count.id,
        },
        timbradas: {
          count: timbradas._count.id,
        },
        pendientes: {
          count: pendientes._count.id,
        },
        nomina: {
          monto: nomina._sum.monto || 0,
          count: nomina._count.id,
        },
        emitidas: {
          monto: emitidas._sum.monto || 0,
          count: emitidas._count.id,
        },
        recibidas: {
          monto: recibidas._sum.monto || 0,
          count: recibidas._count.id,
        },
      },
    });
  } catch (error: any) {
    console.error('Error fetching stats:', error);
    return NextResponse.json(
      { error: error.message || 'Error al obtener estadísticas' },
      { status: 500 }
    );
  }
}