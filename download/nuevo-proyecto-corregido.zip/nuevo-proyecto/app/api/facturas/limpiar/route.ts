import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { empresaId, mes, tipo } = body;

    // mes: "2026-05" (Año-Mes)
    // tipo: "emitidos" o "recibidos" o "todos"
    
    if (!empresaId || !mes) {
      return NextResponse.json({ error: 'Faltan datos' }, { status: 400 });
    }

    const [year, month] = mes.split('-').map(Number);
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 1);

    const where: any = {
      empresaId,
      fecha: {
        gte: startDate,
        lt: endDate,
      },
    };

    if (tipo && tipo !== 'todos') {
      where.direccion = tipo;
    }

    const result = await prisma.factura.deleteMany({ where });

    return NextResponse.json({ 
      success: true, 
      deleted: result.count,
      message: `Se eliminaron ${result.count} facturas del mes ${mes}` 
    });
  } catch (error: any) {
    console.error('Error limpiando mes:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}