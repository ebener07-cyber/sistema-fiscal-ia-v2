import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const empresaId = searchParams.get('empresaId');
    const direccion = searchParams.get('direccion');
    const estado = searchParams.get('estado');
    const limit = parseInt(searchParams.get('limit') || '1000');

    console.log('🔍 Parámetros de búsqueda:');
    console.log(`  - empresaId: ${empresaId}`);
    console.log(`  - direccion: ${direccion}`);
    console.log(`  - estado: ${estado}`);
    console.log(`  - limit: ${limit}`);

    const where: any = {};
    if (empresaId) where.empresaId = empresaId;
    if (direccion) where.direccion = direccion;
    if (estado) where.estado = estado;

    console.log('📋 Filtro WHERE:', JSON.stringify(where, null, 2));

    const facturas = await prisma.factura.findMany({
      where,
      orderBy: { fecha: 'desc' },
      take: limit,
      include: {
        cliente: {
          select: { nombre: true, rfc: true },
        },
        empresa: {
          select: { nombre: true, rfc: true },
        },
        _count: {
          select: { conceptos: true },
        },
      },
    });

    console.log(`✅ Encontradas: ${facturas.length} facturas`);

    return NextResponse.json({
      success: true,
      data: facturas,
      total: facturas.length,
    });
  } catch (error: any) {
    console.error('❌ Error fetching facturas:', error);
    return NextResponse.json(
      { error: error.message || 'Error al obtener facturas' },
      { status: 500 }
    );
  }
}