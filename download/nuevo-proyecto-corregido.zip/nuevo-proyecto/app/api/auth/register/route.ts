import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { hashPassword, createToken } from "@/lib/auth";

/**
 * POST /api/auth/register
 * Registra un nuevo usuario
 */
export async function POST(req: NextRequest) {
  try {
    const { email, password, nombre } = await req.json();

    if (!email || !password || !nombre) {
      return NextResponse.json(
        { error: "Email, contraseña y nombre son requeridos" },
        { status: 400 }
      );
    }

    // Verificar que el email no exista
    const usuarioExistente = await prisma.usuario.findUnique({
      where: { email },
    });

    if (usuarioExistente) {
      return NextResponse.json(
        { error: "El email ya está registrado" },
        { status: 409 }
      );
    }

    // Crear usuario
    const usuarioNuevo = await prisma.usuario.create({
      data: {
        email,
        password: hashPassword(password),
        nombre,
      },
    });

    // Crear token
    const token = createToken(usuarioNuevo.id, usuarioNuevo.email);

    return NextResponse.json(
      {
        token,
        usuario: {
          id: usuarioNuevo.id,
          email: usuarioNuevo.email,
          nombre: usuarioNuevo.nombre,
        },
      },
      {
        headers: {
          "Set-Cookie": `auth-token=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${7 * 24 * 60 * 60}`,
        },
      }
    );
  } catch (error) {
    console.error("Error en POST /api/auth/register:", error);
    return NextResponse.json(
      { error: "Error al registrar usuario" },
      { status: 500 }
    );
  }
}