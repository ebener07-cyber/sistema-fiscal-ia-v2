import { NextResponse } from "next/server";

/**
 * POST /api/auth/logout
 * Cierra la sesión del usuario
 */
export async function POST() {
  const response = NextResponse.json({ success: true });

  // Eliminar cookie de autenticación
  response.cookies.set("auth-token", "", {
    path: "/",
    httpOnly: true,
    sameSite: "strict",
    maxAge: 0,
  });

  return response;
}