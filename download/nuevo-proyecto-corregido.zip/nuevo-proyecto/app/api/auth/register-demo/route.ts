import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { hashPassword } from "@/lib/auth";

/**
 * POST /api/auth/register-demo
 * Crea un usuario de demostración si no existe
 */
export async function POST() {
  try {
    const email = "demo@ejemplo.com";
    const password = "demo123";
    const nombre = "Usuario Demo";

    // Verificar si ya existe
    const existente = await prisma.usuario.findUnique({
      where: { email },
    });

    if (existente) {
      return NextResponse.json({
        message: "Usuario demo ya existe",
        email,
      });
    }

    // Crear usuario demo
    const usuario = await prisma.usuario.create({
      data: {
        email,
        password: hashPassword(password),
        nombre,
      },
    });

    return NextResponse.json({
      message: "Usuario demo creado",
      email,
      password,
    });
  } catch (error) {
    console.error("Error creando usuario demo:", error);
    return NextResponse.json(
      { error: "Error al crear usuario demo" },
      { status: 500 }
    );
  }
}