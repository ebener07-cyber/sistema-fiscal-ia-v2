import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { hashPassword, verifyPassword, createToken } from '@/lib/auth';

/**
 * POST /api/auth/login
 * Login y retorna token JWT
 */
export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email y contraseña son requeridos' },
        { status: 400 }
      );
    }

    // Buscar usuario
    const usuario = await prisma.usuario.findUnique({
      where: { email },
    });

    if (!usuario || !verifyPassword(password, usuario.password)) {
      return NextResponse.json(
        { error: 'Email o contraseña incorrecto' },
        { status: 401 }
      );
    }

    // Crear token
    const token = createToken(usuario.id, usuario.email);

    // Retornar datos del usuario y token
    return NextResponse.json(
      {
        token,
        usuario: {
          id: usuario.id,
          email: usuario.email,
          nombre: usuario.nombre,
        },
      },
      {
        headers: {
          'Set-Cookie': `auth-token=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${7 * 24 * 60 * 60}`,
        },
      }
    );
  } catch (error) {
    console.error('Error en POST /api/auth/login:', error);
    return NextResponse.json(
      { error: 'Error al iniciar sesión' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/auth/register
 * Registra un nuevo usuario (opcional, para desarrollo)
 */
export async function PUT(req: NextRequest) {
  try {
    const { email, password, nombre } = await req.json();

    if (!email || !password || !nombre) {
      return NextResponse.json(
        { error: 'Email, contraseña y nombre son requeridos' },
        { status: 400 }
      );
    }

    // Verificar que el email no exista
    const usuarioExistente = await prisma.usuario.findUnique({
      where: { email },
    });

    if (usuarioExistente) {
      return NextResponse.json(
        { error: 'El email ya está registrado' },
        { status: 409 }
      );
    }

    // Crear usuario
    const usuarioNuevo = await prisma.usuario.create({
      data: {
        email,
        password: hashPassword(password),
        nombre,
      },
    });

    // Crear token
    const token = createToken(usuarioNuevo.id, usuarioNuevo.email);

    return NextResponse.json(
      {
        token,
        usuario: {
          id: usuarioNuevo.id,
          email: usuarioNuevo.email,
          nombre: usuarioNuevo.nombre,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error en PUT /api/auth/login:', error);
    return NextResponse.json(
      { error: 'Error al registrarse' },
      { status: 500 }
    );
  }
}
