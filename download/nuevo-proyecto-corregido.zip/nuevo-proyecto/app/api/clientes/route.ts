import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

/**
 * GET /api/clientes
 * Obtiene todos los clientes
 */
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const skip = parseInt(searchParams.get('skip') || '0');
    const take = parseInt(searchParams.get('take') || '10');
    const empresaId = searchParams.get('empresaId');

    const where = empresaId ? { empresaId } : {};

    const [clientes, total] = await Promise.all([
      prisma.cliente.findMany({
        where,
        skip,
        take,
        include: {
          empresa: {
            select: { id: true, nombre: true, rfc: true },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.cliente.count({ where }),
    ]);

    return NextResponse.json({
      data: clientes,
      pagination: {
        total,
        skip,
        take,
        pages: Math.ceil(total / take),
      },
    });
  } catch (error) {
    console.error('Error en GET /api/clientes:', error);
    return NextResponse.json(
      { error: 'Error al obtener clientes' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/clientes
 * Crea un nuevo cliente
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { nombre, rfc, correo, empresaId } = body;

    // Validación
    if (!nombre || !rfc || !correo || !empresaId) {
      return NextResponse.json(
        { error: 'nombre, rfc, correo y empresaId son requeridos' },
        { status: 400 }
      );
    }

    // Validar que la empresa existe
    const empresaExistente = await prisma.empresa.findUnique({
      where: { id: empresaId },
    });

    if (!empresaExistente) {
      return NextResponse.json(
        { error: 'Empresa no encontrada' },
        { status: 404 }
      );
    }

    // Validar que el RFC no exista para esta empresa
    const rfcExistente = await prisma.cliente.findFirst({
      where: { rfc, empresaId },
    });

    if (rfcExistente) {
      return NextResponse.json(
        { error: 'RFC de cliente ya existe en el sistema' },
        { status: 409 }
      );
    }

    const cliente = await prisma.cliente.create({
      data: {
        nombre,
        rfc,
        email: correo,
        empresaId,
      },
      include: {
        empresa: {
          select: { id: true, nombre: true, rfc: true },
        },
      },
    });

    return NextResponse.json(cliente, { status: 201 });
  } catch (error) {
    console.error('Error en POST /api/clientes:', error);
    return NextResponse.json(
      { error: 'Error al crear cliente' },
      { status: 500 }
    );
  }
}
