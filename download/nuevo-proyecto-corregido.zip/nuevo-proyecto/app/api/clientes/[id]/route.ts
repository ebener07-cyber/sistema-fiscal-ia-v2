import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/clientes/[id]
 * Obtiene un cliente específico
 */
export async function GET(
  req: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    const cliente = await prisma.cliente.findUnique({
      where: { id },
      include: {
        empresa: {
          select: { id: true, nombre: true, rfc: true },
        },
      },
    });

    if (!cliente) {
      return NextResponse.json(
        { error: 'Cliente no encontrado' },
        { status: 404 }
      );
    }

    return NextResponse.json(cliente);
  } catch (error) {
    console.error('Error en GET /api/clientes/[id]:', error);
    return NextResponse.json(
      { error: 'Error al obtener cliente' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/clientes/[id]
 * Actualiza un cliente
 */
export async function PUT(
  req: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { nombre, correo, empresaId } = body;

    // Verificar que el cliente existe
    const clienteExistente = await prisma.cliente.findUnique({
      where: { id },
    });

    if (!clienteExistente) {
      return NextResponse.json(
        { error: 'Cliente no encontrado' },
        { status: 404 }
      );
    }

    // Si se cambio empresaId, verificar que existe
    if (empresaId && empresaId !== clienteExistente.empresaId) {
      const empresaExistente = await prisma.empresa.findUnique({
        where: { id: empresaId },
      });

      if (!empresaExistente) {
        return NextResponse.json(
          { error: 'Empresa no encontrada' },
          { status: 404 }
        );
      }
    }

    const clienteActualizado = await prisma.cliente.update({
      where: { id },
      data: {
        nombre: nombre || clienteExistente.nombre,
        email: correo || clienteExistente.email,
        empresaId: empresaId || clienteExistente.empresaId,
      },
      include: {
        empresa: {
          select: { id: true, nombre: true, rfc: true },
        },
      },
    });

    return NextResponse.json(clienteActualizado);
  } catch (error) {
    console.error('Error en PUT /api/clientes/[id]:', error);
    return NextResponse.json(
      { error: 'Error al actualizar cliente' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/clientes/[id]
 * Elimina un cliente
 */
export async function DELETE(
  req: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    // Verificar que el cliente existe
    const clienteExistente = await prisma.cliente.findUnique({
      where: { id },
    });

    if (!clienteExistente) {
      return NextResponse.json(
        { error: 'Cliente no encontrado' },
        { status: 404 }
      );
    }

    await prisma.cliente.delete({
      where: { id },
    });

    return NextResponse.json(
      { message: 'Cliente eliminado correctamente' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error en DELETE /api/clientes/[id]:', error);
    return NextResponse.json(
      { error: 'Error al eliminar cliente' },
      { status: 500 }
    );
  }
}
