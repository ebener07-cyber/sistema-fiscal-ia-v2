import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// GET /api/empleados?empresaId=xxx
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const empresaId = searchParams.get('empresaId');
    const status = searchParams.get('status');

    if (!empresaId) {
      return NextResponse.json({ error: 'empresaId es requerido' }, { status: 400 });
    }

    const where: any = { empresaId };
    if (status) where.status = status;

    const empleados = await prisma.empleado.findMany({
      where,
      orderBy: { nombre: 'asc' },
      include: {
        _count: { select: { recibosNomina: true } },
      },
    });

    return NextResponse.json({ success: true, data: empleados });
  } catch (error: any) {
    console.error('Error GET /api/empleados:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// POST /api/empleados
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      nombre, rfc, curp, nss, correo, telefono,
      puesto, departamento, salarioDiario, salarioMensual,
      tipoContrato, tipoJornada, regimenContratacion, riesgoPuesto,
      fechaAlta, empresaId
    } = body;

    if (!nombre || !rfc || !empresaId) {
      return NextResponse.json({ error: 'nombre, rfc y empresaId son requeridos' }, { status: 400 });
    }

    const empleado = await prisma.empleado.create({
      data: {
        nombre, rfc, empresaId,
        curp, nss, correo, telefono,
        puesto, departamento,
        salarioDiario: salarioDiario ? parseFloat(salarioDiario) : null,
        salarioMensual: salarioMensual ? parseFloat(salarioMensual) : null,
        tipoContrato: tipoContrato || 'base',
        tipoJornada: tipoJornada || '01',
        regimenContratacion: regimenContratacion || '02',
        riesgoPuesto: riesgoPuesto || '2',
        fechaAlta: fechaAlta ? new Date(fechaAlta) : new Date(),
      },
    });

    return NextResponse.json({ success: true, data: empleado });
  } catch (error: any) {
    console.error('Error POST /api/empleados:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}