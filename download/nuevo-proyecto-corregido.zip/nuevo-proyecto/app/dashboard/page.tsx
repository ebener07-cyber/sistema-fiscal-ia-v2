'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ERPLayout, MODULES } from '@/components/ERPLayout';
import { Send, X, MessageSquare, Building2, Plus } from 'lucide-react';
import { useEmpresa } from '@/providers/EmpresaProvider';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function DashboardPage() {
  const router = useRouter();
  const { empresas, empresaSeleccionada, setEmpresaSeleccionada, loading: empresaLoading } = useEmpresa();
  const [showEmpresaSelector, setShowEmpresaSelector] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Cambiar título del navegador
  useEffect(() => {
    document.title = 'Abbax-IA ERP - Sistema Fiscal Inteligente';
  }, []);

  const modules = [
    { ...MODULES.empresas, href: '/empresas' },
    { ...MODULES.descarga, href: '/descarga-sat' },
    { ...MODULES.contabilidad, href: '/contabilidad' },
    { ...MODULES.bancos, href: '/bancos' },
    { ...MODULES.nomina, href: '/nomina' },
    { ...MODULES.crm, href: '/crm' },
    { ...MODULES.compras, href: '/compras' },
    { ...MODULES.tributario, href: '/tributario' },
    { ...MODULES.diot, href: '/diot' },
    { ...MODULES.inventario, href: '/inventario' },
    { ...MODULES.reportes, href: '/reportes' },
    { ...MODULES.usuarios, href: '/usuarios' },
  ];

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date(),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputMessage('');
    setIsLoading(true);

    // Mostrar indicador de "escribiendo..."
    const loadingMessage: Message = {
      id: 'loading',
      role: 'assistant',
      content: 'Pensando...',
      timestamp: new Date(),
    };
    setMessages([...newMessages, loadingMessage]);

    try {
      const res = await fetch('/api/ia-fiscal/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: inputMessage,
        }),
      });

      const data = await res.json();

      if (data.error) {
        setMessages([
          ...newMessages,
          {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            content: `Error: ${data.error}`,
            timestamp: new Date(),
          },
        ]);
      } else {
        setMessages([
          ...newMessages,
          {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            content: data.reply || 'Lo siento, no pude generar una respuesta.',
            timestamp: new Date(),
          },
        ]);
      }
    } catch (error) {
      console.error('Error:', error);
      setMessages([
        ...newMessages,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: 'Lo siento, tuve un error de conexión. Intenta de nuevo.',
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-rose-500 to-red-600 rounded-lg flex items-center justify-center text-white font-bold text-lg shadow-md">
                  A
                </div>
                <div>
                  <h1 className="font-bold text-gray-900 text-lg">Abbax-IA ERP</h1>
                  <p className="text-xs text-gray-500">Sistema Fiscal Inteligente</p>
                </div>
              </div>
            </div>

            {/* Selector de Empresa */}
            <div className="relative">
              <button
                onClick={() => setShowEmpresaSelector(!showEmpresaSelector)}
                className="flex items-center gap-3 px-4 py-2 bg-gray-50 hover:bg-gray-100 rounded-lg border border-gray-200 transition"
              >
                <span className="text-2xl">{empresaSeleccionada?.logo || '🏢'}</span>
                <div className="text-left">
                  <p className="text-sm font-semibold text-gray-900">{empresaSeleccionada?.nombre || 'Cargando...'}</p>
                  <p className="text-xs text-gray-500 font-mono">{empresaSeleccionada?.rfc || '...'}</p>
                </div>
                <span className="text-gray-400">▼</span>
              </button>

              {showEmpresaSelector && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-gray-200 z-50">
                  <div className="p-3 border-b border-gray-100 flex items-center justify-between">
                    <p className="text-xs font-semibold text-gray-500 uppercase">Seleccionar Empresa</p>
                    <button
                      onClick={() => {
                        setShowEmpresaSelector(false);
                        router.push('/empresas');
                      }}
                      className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-medium"
                    >
                      <Plus size={14} />
                      Nueva
                    </button>
                  </div>
                  <div className="max-h-96 overflow-y-auto p-2">
                    {empresas.map((empresa) => (
                      <button
                        key={empresa.id}
                        onClick={() => {
                          setEmpresaSeleccionada(empresa);
                          setShowEmpresaSelector(false);
                        }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition ${
                          empresaSeleccionada?.id === empresa.id
                            ? 'bg-rose-50 border border-rose-200'
                            : 'hover:bg-gray-50'
                        }`}
                      >
                        <span className="text-2xl">{empresa.logo}</span>
                        <div className="flex-1 text-left">
                          <p className="text-sm font-semibold text-gray-900">{empresa.nombre}</p>
                          <p className="text-xs text-gray-500 font-mono">{empresa.rfc}</p>
                        </div>
                        {empresaSeleccionada?.id === empresa.id && (
                          <span className="text-rose-600">✓</span>
                        )}
                      </button>
                    ))}
                  </div>
                  <div className="p-3 border-t border-gray-100">
                    <button
                      onClick={() => {
                        setShowEmpresaSelector(false);
                        router.push('/empresas');
                      }}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition font-medium"
                    >
                      <Building2 size={16} />
                      Gestionar Empresas
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* User Profile & Chat Button */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowChat(!showChat)}
                className="flex items-center gap-2 px-4 py-2 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition"
              >
                <MessageSquare size={18} />
                <span className="text-sm font-medium">Asistente IA</span>
              </button>
              
              <div className="text-right hidden md:block">
                <p className="text-sm font-semibold text-gray-900">Alejandro García</p>
                <p className="text-xs text-gray-500">Admin · Fiscal</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center text-white font-bold">
                A
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Chat Panel */}
      {showChat && (
        <div className="fixed right-4 bottom-4 w-96 bg-white rounded-2xl shadow-2xl border border-gray-200 z-50 flex flex-col max-h-[600px]">
          <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-rose-50 to-red-50 rounded-t-2xl">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-rose-600 rounded-lg flex items-center justify-center text-white">
                <MessageSquare size={16} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-sm">Asistente Fiscal IA</h3>
                <p className="text-xs text-gray-500">Abbax-IA</p>
              </div>
            </div>
            <button
              onClick={() => setShowChat(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <MessageSquare className="text-rose-600" size={32} />
                </div>
                <p className="text-sm text-gray-600 font-medium">¡Hola! Soy tu asistente fiscal</p>
                <p className="text-xs text-gray-500 mt-1">
                  Puedo ayudarte con facturas, conciliaciones, declaraciones y más.
                </p>
                <div className="mt-4 space-y-2">
                  <p className="text-xs text-gray-400 font-medium">Prueba preguntando:</p>
                  <button
                    onClick={() => setInputMessage('¿Qué es la DIOT y cuándo se presenta?')}
                    className="block w-full text-left text-xs text-rose-600 hover:bg-rose-50 px-3 py-2 rounded-lg transition"
                  >
                    💡 ¿Qué es la DIOT y cuándo se presenta?
                  </button>
                  <button
                    onClick={() => setInputMessage('¿Cuáles son los requisitos del CFDI 4.0?')}
                    className="block w-full text-left text-xs text-rose-600 hover:bg-rose-50 px-3 py-2 rounded-lg transition"
                  >
                    💡 ¿Cuáles son los requisitos del CFDI 4.0?
                  </button>
                  <button
                    onClick={() => setInputMessage('¿Cómo se calcula el IVA?')}
                    className="block w-full text-left text-xs text-rose-600 hover:bg-rose-50 px-3 py-2 rounded-lg transition"
                  >
                    💡 ¿Cómo se calcula el IVA?
                  </button>
                </div>
              </div>
            )}
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] px-4 py-2 rounded-lg ${
                    msg.role === 'user'
                      ? 'bg-rose-600 text-white'
                      : msg.id === 'loading'
                      ? 'bg-gray-100 text-gray-500 italic'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                  {msg.id !== 'loading' && (
                    <p className={`text-xs mt-1 ${
                      msg.role === 'user' ? 'text-rose-100' : 'text-gray-500'
                    }`}>
                      {msg.timestamp.toLocaleTimeString('es-MX', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-gray-200">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Escribe tu consulta fiscal..."
                disabled={isLoading}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-rose-500 focus:border-rose-500 disabled:opacity-50"
              />
              <button
                onClick={handleSendMessage}
                disabled={isLoading || !inputMessage.trim()}
                className="px-3 py-2 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="p-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-1">
            Bienvenido al Panel de Control
          </h2>
          <p className="text-gray-600">
            Empresa: <span className="font-semibold">{empresaSeleccionada?.nombre || 'Sin empresa'}</span> · RFC: {empresaSeleccionada?.rfc || '...'}
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <StatCard 
            icon="📥" 
            label="CFDIs Descargados" 
            value="58,234" 
            sub="Últimos 12 meses" 
            color="emerald" 
          />
          <StatCard 
            icon="💰" 
            label="Por Cobrar" 
            value="$145,280" 
            sub="15 facturas" 
            color="blue" 
          />
          <StatCard 
            icon="💳" 
            label="Por Pagar" 
            value="$87,450" 
            sub="9 facturas" 
            color="orange" 
          />
          <StatCard 
            icon="⚠️" 
            label="Pendientes" 
            value="245" 
            sub="Requieren acción" 
            color="red" 
          />
        </div>

        {/* Modules Grid */}
        <div className="mb-8">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Módulos del Sistema</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {modules.map((mod) => (
              <button
                key={mod.key}
                onClick={() => router.push(mod.href)}
                className={`group text-left p-5 rounded-xl border transition-all hover:shadow-lg ${
                  mod.key === 'descarga'
                    ? 'bg-gradient-to-br from-rose-600 to-red-700 text-white border-transparent shadow-md'
                    : mod.key === 'empresas'
                    ? 'bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 hover:border-blue-400'
                    : 'bg-white border-gray-200 hover:border-rose-300'
                }`}
              >
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-2xl mb-3 ${
                  mod.key === 'descarga' ? 'bg-white/20' : mod.bgColor
                }`}>
                  {mod.icon}
                </div>
                <h4 className={`font-bold text-sm mb-1 ${
                  mod.key === 'descarga' ? 'text-white' : mod.color
                }`}>
                  {mod.name}
                </h4>
                <p className={`text-xs leading-relaxed ${
                  mod.key === 'descarga' ? 'text-rose-100' : 'text-gray-500'
                }`}>
                  {mod.description.substring(0, 60)}...
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-3 gap-6">
          {/* Recent Activity */}
          <div className="col-span-2 bg-white rounded-2xl border border-gray-200 p-6">
            <h4 className="font-bold text-gray-900 mb-4">Actividad Reciente</h4>
            <div className="space-y-3">
              <ActivityItem 
                icon="🏢" 
                text="Nueva empresa registrada: Abbax-IA S.A. de C.V." 
                time="Hace 1 hora" 
                color="blue" 
              />
              <ActivityItem 
                icon="📥" 
                text="Descarga masiva completada: 847 CFDIs" 
                time="Hace 2 horas" 
                color="emerald" 
              />
              <ActivityItem 
                icon="💳" 
                text="Pago registrado: Telmex S.A.B. - $4,500" 
                time="Hace 4 horas" 
                color="blue" 
              />
              <ActivityItem 
                icon="📄" 
                text="Factura timbrada: A-1234" 
                time="Hace 5 horas" 
                color="purple" 
              />
              <ActivityItem 
                icon="⚠️" 
                text="DIOT de Noviembre pendiente" 
                time="Hace 1 día" 
                color="amber" 
              />
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-gradient-to-br from-rose-50 to-red-50 border border-rose-200 rounded-2xl p-6">
            <h4 className="font-bold text-gray-900 mb-4">Resumen del Mes</h4>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-gray-600 mb-1">Ingresos</p>
                <p className="text-2xl font-bold text-emerald-600">$245,680</p>
                <p className="text-xs text-emerald-600 mt-1">↑ 12% vs mes anterior</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Egresos</p>
                <p className="text-2xl font-bold text-red-600">$98,450</p>
                <p className="text-xs text-red-600 mt-1">↓ 5% vs mes anterior</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Utilidad</p>
                <p className="text-2xl font-bold text-rose-600">$147,230</p>
                <p className="text-xs text-gray-500 mt-1">60.1% margen</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function StatCard({ icon, label, value, sub, color }: { icon: string; label: string; value: string; sub: string; color: string }) {
  const colors: Record<string, string> = {
    emerald: 'border-emerald-500',
    blue: 'border-blue-500',
    orange: 'border-orange-500',
    red: 'border-red-500',
  };

  return (
    <div className={`bg-white rounded-xl border-l-4 ${colors[color]} border border-gray-200 p-5 shadow-sm`}>
      <div className="flex items-start justify-between mb-2">
        <p className="text-xs text-gray-500 font-medium">{label}</p>
        <span className="text-xl">{icon}</span>
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      <p className="text-xs text-gray-400 mt-1">{sub}</p>
    </div>
  );
}

function ActivityItem({ icon, text, time, color }: { icon: string; text: string; time: string; color: string }) {
  const colors: Record<string, string> = {
    emerald: 'bg-emerald-100',
    blue: 'bg-blue-100',
    purple: 'bg-purple-100',
    amber: 'bg-amber-100',
  };

  return (
    <div className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg ${colors[color]}`}>
        {icon}
      </div>
      <div className="flex-1">
        <p className="text-sm text-gray-900">{text}</p>
        <p className="text-xs text-gray-500 mt-0.5">{time}</p>
      </div>
    </div>
  );
}