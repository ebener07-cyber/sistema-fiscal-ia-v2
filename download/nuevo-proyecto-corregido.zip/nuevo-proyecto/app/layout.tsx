import './globals.css';
import { GraphifyProvider } from '@/providers/GraphifyProvider';
import { EmpresaProvider } from '@/providers/EmpresaProvider';
import AuthWrapper from '@/components/AuthWrapper';

export const metadata = {
  title: 'Abbax-IA ERP - Sistema Fiscal Inteligente',
  description: 'Plataforma integral de gestión fiscal y contable con IA',
  keywords: 'SAT, CFDI, facturación, contabilidad, fiscal, México, DIOT, impuestos',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body>
        <AuthWrapper>
          <EmpresaProvider>
            <GraphifyProvider>{children}</GraphifyProvider>
          </EmpresaProvider>
        </AuthWrapper>
      </body>
    </html>
  );
}