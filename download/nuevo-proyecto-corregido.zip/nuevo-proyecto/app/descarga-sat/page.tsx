'use client';

import { useState, useEffect } from 'react';
import { ERPLayout } from '@/components/ERPLayout';
import { 
  Download, Upload, FileUp, FileText, RefreshCw, 
  AlertCircle, CheckCircle, Loader2, Database,
  TrendingUp, TrendingDown, Calendar
} from 'lucide-react';

interface DescargaSAT {
  id: string;
  solicitudId: string;
  rfc: string;
  fechaInicial: string;
  fechaFinal: string;
  tipo: 'emitidos' | 'recibidos';
  estado: string;
  numeroCFDIs: number;
  fechaSolicitud: string;
  archivosProcesados: boolean;
}

export default function DescargaSATPage() {
  const [loading, setLoading] = useState(false);
  const [descargas, setDescargas] = useState<DescargaSAT[]>([]);
  const [selectedEmpresa, setSelectedEmpresa] = useState('');
  const [empresas, setEmpresas] = useState<any[]>([]);
  
  // Upload Emitidas
  const [zipEmitidas, setZipEmitidas] = useState<File | null>(null);
  const [procesandoEmitidas, setProcesandoEmitidas] = useState(false);
  
  // Upload Recibidas
  const [zipRecibidas, setZipRecibidas] = useState<File | null>(null);
  const [procesandoRecibidas, setProcesandoRecibidas] = useState(false);
  
  // Generar Excel
  const [generandoExcel, setGenerandoExcel] = useState(false);

  useEffect(() => {
    cargarEmpresas();
    cargarDescargas();
  }, []);

  const cargarEmpresas = async () => {
    try {
      const res = await fetch('/api/empresas');
      const data = await res.json();
      const lista = data.data || [];
      setEmpresas(lista);
      if (lista.length > 0) {
        setSelectedEmpresa(lista[0].id);
      }
    } catch (error) {
      console.error('Error cargando empresas:', error);
    }
  };

  const cargarDescargas = async () => {
    if (!selectedEmpresa) return;
    try {
      const res = await fetch(`/api/descarga-sat/historial?empresaId=${selectedEmpresa}&limit=50`);
      const data = await res.json();
      if (data.success) {
        setDescargas(data.descargas);
      }
    } catch (error) {
      console.error('Error cargando descargas:', error);
    }
  };

  const procesarZIP = async (file: File, tipo: 'emitidos' | 'recibidos') => {
    if (!selectedEmpresa) {
      alert('❌ Selecciona una empresa primero');
      return;
    }

    if (tipo === 'emitidos') {
      setProcesandoEmitidas(true);
    } else {
      setProcesandoRecibidas(true);
    }

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('empresaId', selectedEmpresa);
      formData.append('tipo', tipo);

      const res = await fetch('/api/procesar-xmls', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Error al procesar');
      }

      alert(`✅ ${tipo === 'emitidos' ? 'Emitidas' : 'Recibidas'} procesadas\n\nFacturas creadas: ${data.facturasCreadas}\nTotal procesados: ${data.totalProcesados}\nErrores: ${data.totalErrores}`);
      
      if (tipo === 'emitidos') {
        setZipEmitidas(null);
      } else {
        setZipRecibidas(null);
      }
      
      await cargarDescargas();
    } catch (error: any) {
      alert(`❌ Error: ${error.message}`);
    } finally {
      if (tipo === 'emitidos') {
        setProcesandoEmitidas(false);
      } else {
        setProcesandoRecibidas(false);
      }
    }
  };

  const generarExcel = async () => {
    if (!selectedEmpresa) {
      alert('❌ Selecciona una empresa primero');
      return;
    }

    setGenerandoExcel(true);
    try {
      const res = await fetch(`/api/generar-excel?empresaId=${selectedEmpresa}`);
      
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Error al generar Excel');
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Concentrado_CFDI_2026_${Date.now()}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      alert('✅ Excel generado exitosamente');
    } catch (error: any) {
      alert(`❌ Error: ${error.message}`);
    } finally {
      setGenerandoExcel(false);
    }
  };

  const getEstadoColor = (estado: string) => {
    const colors: Record<string, string> = {
      pendiente: 'bg-yellow-100 text-yellow-800',
      en_proceso: 'bg-blue-100 text-blue-800',
      terminada: 'bg-emerald-100 text-emerald-800',
      error: 'bg-red-100 text-red-800',
    };
    return colors[estado] || 'bg-gray-100 text-gray-800';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('es-MX', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit',
    });
  };

  return (
    <ERPLayout moduleKey="descarga">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Descarga SAT</h1>
            <p className="text-gray-600">Sube los XMLs descargados del portal del SAT</p>
          </div>
          <div className="flex items-center gap-3">
            <select
              value={selectedEmpresa}
              onChange={(e) => {
                setSelectedEmpresa(e.target.value);
                cargarDescargas();
              }}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-500"
            >
              {empresas.map(emp => (
                <option key={emp.id} value={emp.id}>{emp.nombre}</option>
              ))}
            </select>
            <button
              onClick={generarExcel}
              disabled={generandoExcel}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50"
            >
              {generandoExcel ? (
                <><Loader2 size={18} className="animate-spin" /> Generando...</>
              ) : (
                <><FileText size={18} /> Descargar Excel</>
              )}
            </button>
          </div>
        </div>

        {/* Upload Zones */}
        <div className="grid grid-cols-2 gap-6">
          {/* Emitidas */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-blue-600" size={20} />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900">Facturas Emitidas</h2>
                <p className="text-sm text-gray-500">CFDIs que tú emitiste</p>
              </div>
            </div>

            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition">
              {zipEmitidas ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-center gap-3">
                    <FileUp className="text-blue-600" size={32} />
                    <div className="text-left flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">{zipEmitidas.name}</p>
                      <p className="text-xs text-gray-500">{(zipEmitidas.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => procesarZIP(zipEmitidas, 'emitidos')}
                      disabled={procesandoEmitidas}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 text-sm"
                    >
                      {procesandoEmitidas ? (
                        <><Loader2 size={16} className="animate-spin" /> Procesando...</>
                      ) : (
                        <><CheckCircle size={16} /> Procesar</>
                      )}
                    </button>
                    <button
                      onClick={() => setZipEmitidas(null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">Haz clic para seleccionar el ZIP de emitidas</p>
                  <p className="text-xs text-gray-500 mt-1">Archivo ZIP del portal del SAT</p>
                  <input
                    type="file"
                    accept=".zip"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) setZipEmitidas(file);
                    }}
                    className="hidden"
                    id="zip-emitidas"
                  />
                  <label
                    htmlFor="zip-emitidas"
                    className="inline-block mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer text-sm"
                  >
                    Seleccionar ZIP
                  </label>
                </>
              )}
            </div>
          </div>

          {/* Recibidas */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingDown className="text-purple-600" size={20} />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900">Facturas Recibidas</h2>
                <p className="text-sm text-gray-500">CFDIs que recibiste de proveedores</p>
              </div>
            </div>

            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-purple-500 transition">
              {zipRecibidas ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-center gap-3">
                    <FileUp className="text-purple-600" size={32} />
                    <div className="text-left flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">{zipRecibidas.name}</p>
                      <p className="text-xs text-gray-500">{(zipRecibidas.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => procesarZIP(zipRecibidas, 'recibidos')}
                      disabled={procesandoRecibidas}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 text-sm"
                    >
                      {procesandoRecibidas ? (
                        <><Loader2 size={16} className="animate-spin" /> Procesando...</>
                      ) : (
                        <><CheckCircle size={16} /> Procesar</>
                      )}
                    </button>
                    <button
                      onClick={() => setZipRecibidas(null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">Haz clic para seleccionar el ZIP de recibidas</p>
                  <p className="text-xs text-gray-500 mt-1">Archivo ZIP del portal del SAT</p>
                  <input
                    type="file"
                    accept=".zip"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) setZipRecibidas(file);
                    }}
                    className="hidden"
                    id="zip-recibidas"
                  />
                  <label
                    htmlFor="zip-recibidas"
                    className="inline-block mt-3 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 cursor-pointer text-sm"
                  >
                    Seleccionar ZIP
                  </label>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Instrucciones */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="text-blue-600 mt-0.5 flex-shrink-0" size={20} />
            <div className="text-sm text-blue-800">
              <p className="font-semibold mb-1">Instrucciones:</p>
              <ol className="space-y-1 text-xs list-decimal list-inside">
                <li>Descarga los CFDIs desde el portal del SAT (Descarga Masiva)</li>
                <li>Recibirás archivos ZIP separados para emitidas y recibidas</li>
                <li>Sube cada ZIP en su sección correspondiente arriba</li>
                <li>El sistema procesará automáticamente y creará las facturas</li>
                <li>Haz clic en "Descargar Excel" para obtener el concentrado mensual</li>
              </ol>
            </div>
          </div>
        </div>

        {/* Historial */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-gray-900">Historial de Procesamiento</h2>
              <p className="text-sm text-gray-500">Últimos archivos procesados</p>
            </div>
            <button onClick={cargarDescargas} className="flex items-center gap-2 px-3 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg">
              <RefreshCw size={16} /> Actualizar
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">CFDIs</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {descargas.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-12 text-center text-gray-500">
                      <Database size={48} className="mx-auto mb-4 text-gray-300" />
                      <p>No hay descargas registradas</p>
                    </td>
                  </tr>
                ) : (
                  descargas.map((descarga) => (
                    <tr key={descarga.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
                          descarga.tipo === 'emitidos' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
                        }`}>
                          {descarga.tipo === 'emitidos' ? '📤' : '📨'} {descarga.tipo}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{formatDate(descarga.fechaSolicitud)}</td>
                      <td className="px-6 py-4 text-sm font-medium">{descarga.numeroCFDIs || '-'}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${getEstadoColor(descarga.estado)}`}>
                          {descarga.estado.replace('_', ' ').toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </ERPLayout>
  );
}