'use client';

import { useState } from 'react';
import { ERPLayout } from '@/components/ERPLayout';

export default function InventarioPage() {
  const [tab, setTab] = useState<'productos' | 'servicios'>('productos');

  const productos = [
    { id: 'PROD-001', nombre: 'Laptop Dell Latitude', claveSAT: '43211503', unidad: 'Pieza', stock: 15, costo: 18500, precio: 24900 },
    { id: 'PROD-002', nombre: 'Monitor LG 27"', claveSAT: '43211904', unidad: 'Pieza', stock: 8, costo: 4200, precio: 6500 },
    { id: 'PROD-003', nombre: 'Teclado Mecánico', claveSAT: '43211607', unidad: 'Pieza', stock: 25, costo: 850, precio: 1200 },
    { id: 'PROD-004', nombre: 'Mouse Inalámbrico', claveSAT: '43211608', unidad: 'Pieza', stock: 30, costo: 350, precio: 599 },
  ];

  const servicios = [
    { id: 'SERV-001', nombre: 'Consultoría Fiscal', claveSAT: '82121500', unidad: 'Servicio', horas: 120, costo: 850, precio: 1500 },
    { id: 'SERV-002', nombre: 'Desarrollo de Software', claveSAT: '81111500', unidad: 'Servicio', horas: 200, costo: 650, precio: 1200 },
    { id: 'SERV-003', nombre: 'Soporte Técnico', claveSAT: '81111600', unidad: 'Servicio', horas: 80, costo: 450, precio: 800 },
  ];

  const datos = tab === 'productos' ? productos : servicios;

  return (
    <ERPLayout moduleKey="inventario">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Inventario</h3>
            <p className="text-sm text-gray-500">Productos y servicios clasificados desde CFDI de compras y ventas</p>
          </div>
          <button className="px-4 py-2 bg-amber-600 text-white rounded-lg text-sm font-medium hover:bg-amber-700">
            + Nuevo Item
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-gray-200">
          <button
            onClick={() => setTab('productos')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition ${
              tab === 'productos' ? 'border-amber-600 text-amber-700' : 'border-transparent text-gray-500'
            }`}
          >
            📦 Productos ({productos.length})
          </button>
          <button
            onClick={() => setTab('servicios')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition ${
              tab === 'servicios' ? 'border-amber-600 text-amber-700' : 'border-transparent text-gray-500'
            }`}
          >
             Servicios ({servicios.length})
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white rounded-xl border-l-4 border-amber-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Total Items</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{productos.length + servicios.length}</p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-emerald-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Valor Inventario</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">
              ${productos.reduce((s, p) => s + (p.stock * p.costo), 0).toLocaleString('es-MX')}
            </p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-blue-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Stock Bajo</p>
            <p className="text-2xl font-bold text-blue-600 mt-1">
              {productos.filter(p => p.stock < 10).length}
            </p>
          </div>
          <div className="bg-white rounded-xl border-l-4 border-purple-500 p-4 shadow-sm">
            <p className="text-xs text-gray-500">Claves SAT</p>
            <p className="text-2xl font-bold text-purple-600 mt-1">
              {new Set([...productos, ...servicios].map(i => i.claveSAT)).size}
            </p>
          </div>
        </div>

        {/* Tabla */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm">
          <table className="w-full">
            <thead>
              <tr className="text-xs text-gray-500 border-b border-gray-200 bg-gray-50">
                <th className="text-left px-5 py-3 font-medium">ID</th>
                <th className="text-left px-3 py-3 font-medium">Nombre</th>
                <th className="text-left px-3 py-3 font-medium">Clave SAT</th>
                <th className="text-left px-3 py-3 font-medium">Unidad</th>
                {tab === 'productos' && <th className="text-right px-3 py-3 font-medium">Stock</th>}
                {tab === 'servicios' && <th className="text-right px-3 py-3 font-medium">Horas</th>}
                <th className="text-right px-3 py-3 font-medium">Costo</th>
                <th className="text-right px-3 py-3 font-medium">Precio</th>
              </tr>
            </thead>
            <tbody>
              {datos.map((item) => (
                <tr key={item.id} className="border-b border-gray-100 hover:bg-gray-50 text-sm">
                  <td className="px-5 py-3 font-mono text-amber-600 font-semibold">{item.id}</td>
                  <td className="px-3 py-3 text-gray-900 font-medium">{item.nombre}</td>
                  <td className="px-3 py-3">
                    <span className="font-mono text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                      {item.claveSAT}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-gray-600">{item.unidad}</td>
                  {tab === 'productos' && (
                    <td className="px-3 py-3 text-right">
                      <span
                        className={`font-semibold ${
                          'stock' in item && item.stock < 10
                            ? 'text-red-600'
                            : 'text-emerald-600'
                        }`}
                      >
                        {'stock' in item ? item.stock : 0}
                      </span>
                    </td>
                  )}
                  {tab === 'servicios' && (
                    <td className="px-3 py-3 text-right font-semibold text-gray-900">{'horas' in item ? item.horas : 0}</td>
                  )}
                  <td className="px-3 py-3 text-right text-gray-600">${item.costo.toLocaleString('es-MX')}</td>
                  <td className="px-3 py-3 text-right font-semibold text-gray-900">${item.precio.toLocaleString('es-MX')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </ERPLayout>
  );
}