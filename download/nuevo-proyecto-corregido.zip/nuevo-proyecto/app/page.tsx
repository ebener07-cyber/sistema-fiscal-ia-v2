"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/providers/AuthProvider";
import { useGraphify } from "@/providers/GraphifyProvider";

export default function Home() {
  const router = useRouter();
  const { isLoading: authLoading } = useAuth();
  // Graphify no se usa en la pantalla de entrada
  const graphifyLoading = false;

  const isAuthenticated = false;


  useEffect(() => {
    if (!authLoading && !graphifyLoading) {
      if (isAuthenticated) {
        router.push("/dashboard");
      } else {
        router.push("/login");
      }
    }
  }, [isAuthenticated, authLoading, graphifyLoading, router]);

  // Pantalla de carga mientras verificamos auth
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-slate-400">Cargando...</p>
      </div>
    </div>
  );
}