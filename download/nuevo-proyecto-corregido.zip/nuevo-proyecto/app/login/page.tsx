"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/providers/AuthProvider";
import { FileText, Code, UserCheck, Globe, ChevronRight, ArrowLeft } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuth();
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState<"developer" | "auditor" | null>(null);
  const [language, setLanguage] = useState<"es" | "en">("es");

  const credentials = {
    developer: { email: "dev@ejemplo.com", password: "dev12345" },
    auditor: { email: "auditor@ejemplo.com", password: "auditor123" },
  };

  const handleRoleSelect = (role: "developer" | "auditor") => {
    setSelectedRole(role);
    setError("");
  };

  const handleChangeRole = () => {
    setSelectedRole(null);
    setError("");
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;

    setIsLoading(true);
    setError("");

    const creds = credentials[selectedRole];
    const result = await login(creds.email, creds.password);

    if (result.success) {
      router.push("/dashboard");
    } else {
      setError(result.error || "Error al iniciar sesión");
    }

    setIsLoading(false);
  };

  const toggleLanguage = () => {
    setLanguage(language === "es" ? "en" : "es");
  };

  const t = {
    es: {
      title: "Centro de Control Fiscal",
      subtitle: "Selecciona tu rol para continuar.",
      developer: "Desarrollador",
      auditor: "Auditor",
      email: "CORREO ELECTRÓNICO",
      password: "CONTRASEÑA",
      signIn: "Iniciar sesión",
      changeRole: "Cambiar rol",
      privacy: "Privacidad",
      terms: "Términos",
      help: "Ayuda",
      rightTitle: "Asesoría Fiscal",
      rightSubtitle: "Inteligencia con IA",
    },
    en: {
      title: "Tax Audit Platform",
      subtitle: "Select your role to continue.",
      developer: "Developer",
      auditor: "Auditor",
      email: "EMAIL",
      password: "PASSWORD",
      signIn: "Sign in",
      changeRole: "Change role",
      privacy: "Privacy",
      terms: "Terms",
      help: "Help",
      rightTitle: "Tax Advisory",
      rightSubtitle: "AI Intelligence",
    },
  };

  const currentText = t[language];

  return (
    <div className="min-h-screen flex relative overflow-hidden bg-gradient-to-br from-blue-900 via-slate-900 to-purple-900">
      {/* Fondo futurista unificado - Toda la pantalla */}
      <div className="absolute inset-0">
        {/* Grid animado */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 animate-[pulse_4s_ease-in-out_infinite]" 
               style={{
                 backgroundImage: `linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px),
                                   linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)`,
                 backgroundSize: '50px 50px'
               }}
          />
        </div>

        {/* Círculos flotantes animados - Distribuidos en toda la pantalla */}
        <div className="absolute top-20 left-32 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-[pulse_6s_ease-in-out_infinite]" />
        <div className="absolute bottom-20 right-32 w-[500px] h-[500px] bg-purple-500/20 rounded-full blur-3xl animate-[pulse_8s_ease-in-out_infinite_1s]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-3xl animate-[pulse_7s_ease-in-out_infinite_2s]" />
        <div className="absolute top-40 right-1/4 w-72 h-72 bg-indigo-500/15 rounded-full blur-3xl animate-[pulse_9s_ease-in-out_infinite_0.5s]" />
        
        {/* Partículas flotantes */}
        <div className="absolute top-32 right-48 w-4 h-4 bg-blue-400 rounded-full animate-[bounce_3s_ease-in-out_infinite] opacity-60" />
        <div className="absolute bottom-40 left-48 w-3 h-3 bg-purple-400 rounded-full animate-[bounce_4s_ease-in-out_infinite_0.5s] opacity-60" />
        <div className="absolute top-1/3 right-1/3 w-2 h-2 bg-cyan-400 rounded-full animate-[bounce_5s_ease-in-out_infinite_1s] opacity-60" />
        <div className="absolute bottom-1/3 left-1/4 w-3 h-3 bg-pink-400 rounded-full animate-[bounce_3.5s_ease-in-out_infinite_1.5s] opacity-60" />
        <div className="absolute top-1/4 left-1/3 w-2 h-2 bg-indigo-400 rounded-full animate-[bounce_4.5s_ease-in-out_infinite_2s] opacity-60" />
        
        {/* Líneas de conexión animadas */}
        <svg className="absolute inset-0 w-full h-full opacity-20">
          <line x1="150" y1="200" x2="450" y2="300" stroke="rgb(59, 130, 246)" strokeWidth="1" 
                className="animate-[pulse_3s_ease-in-out_infinite]" />
          <line x1="300" y1="450" x2="600" y2="350" stroke="rgb(168, 85, 247)" strokeWidth="1"
                className="animate-[pulse_4s_ease-in-out_infinite_0.5s]" />
          <line x1="200" y1="400" x2="500" y2="500" stroke="rgb(6, 182, 212)" strokeWidth="1"
                className="animate-[pulse_5s_ease-in-out_infinite_1s]" />
          <line x1="400" y1="150" x2="700" y2="250" stroke="rgb(99, 102, 241)" strokeWidth="1"
                className="animate-[pulse_4.5s_ease-in-out_infinite_1.5s]" />
        </svg>

        {/* Hexágonos decorativos */}
        <div className="absolute top-40 right-1/3 w-16 h-16 border border-blue-400/30 rotate-45 animate-[spin_20s_linear_infinite]" />
        <div className="absolute bottom-32 left-1/4 w-12 h-12 border border-purple-400/30 rotate-45 animate-[spin_15s_linear_infinite_reverse]" />
        <div className="absolute top-1/3 right-40 w-10 h-10 border border-cyan-400/30 rotate-45 animate-[spin_18s_linear_infinite_1s]" />
      </div>

      {/* Overlay sutil */}
      <div className="absolute inset-0 bg-slate-900/20 backdrop-blur-[1px]" />

      {/* Header unificado - Toda la pantalla */}
      <div className="absolute top-8 left-0 right-0 flex justify-between items-center z-30 px-16">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/50">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl font-bold text-white">
            <span className="text-blue-400">Abbax-</span>
            <span className="text-cyan-400">IA</span>
          </span>
        </div>
        <button 
          onClick={toggleLanguage}
          className="flex items-center gap-2 px-3 py-1.5 text-sm text-slate-300 hover:text-white transition-colors bg-white/10 backdrop-blur-sm rounded-lg border border-white/20"
        >
          <Globe className="w-4 h-4" />
          <span>{language.toUpperCase()}</span>
        </button>
      </div>

      {/* Panel Izquierdo - Formulario */}
      <div className="w-1/2 flex flex-col justify-center px-16 relative z-20">
        {/* Contenido principal */}
        <div className="max-w-md w-full mx-auto">
          <h1 className="text-4xl font-bold text-white mb-3 transition-all duration-300 drop-shadow-lg">
            {currentText.title}
          </h1>
          <p className="text-slate-300 mb-10 transition-all duration-300">
            {currentText.subtitle}
          </p>

          {error && (
            <div className="mb-6 p-4 bg-red-500/20 border border-red-400/50 rounded-lg backdrop-blur-sm animate-pulse">
              <p className="text-sm text-red-300">{error}</p>
            </div>
          )}

          {/* Selección de Rol */}
          <div className={`space-y-4 transition-all duration-500 ${selectedRole ? 'hidden' : 'block'}`}>
            <button
              onClick={() => handleRoleSelect("developer")}
              className="w-full group flex items-center justify-between p-5 bg-white/10 backdrop-blur-md hover:bg-white/20 border border-white/30 rounded-xl transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/20 hover:-translate-y-0.5"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-lg flex items-center justify-center shadow-lg">
                  <Code className="w-6 h-6 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-white">{currentText.developer}</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-emerald-400 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => handleRoleSelect("auditor")}
              className="w-full group flex items-center justify-between p-5 bg-white/10 backdrop-blur-md hover:bg-white/20 border border-white/30 rounded-xl transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/20 hover:-translate-y-0.5"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg flex items-center justify-center shadow-lg">
                  <UserCheck className="w-6 h-6 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-white">{currentText.auditor}</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-amber-400 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Formulario de Login */}
          <form onSubmit={handleLogin} className={`space-y-6 transition-all duration-500 ${selectedRole ? 'block' : 'hidden'}`}>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                {currentText.email}
              </label>
              <input
                type="email"
                defaultValue={selectedRole ? credentials[selectedRole].email : ""}
                readOnly
                className="w-full px-4 py-3 bg-white/10 backdrop-blur-md border border-white/30 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                {currentText.password}
              </label>
              <input
                type="password"
                defaultValue={selectedRole ? credentials[selectedRole].password : ""}
                readOnly
                className="w-full px-4 py-3 bg-white/10 backdrop-blur-md border border-white/30 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:from-slate-600 disabled:to-slate-600 text-white font-medium rounded-lg transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/30"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Cargando...
                </span>
              ) : (
                currentText.signIn
              )}
            </button>

            <button
              type="button"
              onClick={handleChangeRole}
              className="w-full flex items-center justify-center gap-2 text-sm text-slate-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              {currentText.changeRole}
            </button>
          </form>

          {/* Footer */}
          <div className="mt-12 flex items-center justify-center gap-6 text-sm text-slate-400">
            <button className="hover:text-white transition-colors">{currentText.privacy}</button>
            <span>•</span>
            <button className="hover:text-white transition-colors">{currentText.terms}</button>
            <span>•</span>
            <button className="hover:text-white transition-colors">{currentText.help}</button>
          </div>
        </div>
      </div>

      {/* Panel Derecho - Elementos orbitales integrados */}
      <div className="w-1/2 relative z-10 flex items-center justify-center">
        <div className="relative w-[500px] h-[500px]">
          {/* Círculos orbitales */}
          <div className="absolute inset-0 border border-blue-400/30 rounded-full animate-[pulse_4s_ease-in-out_infinite]" />
          <div className="absolute inset-12 border border-blue-400/20 rounded-full animate-[pulse_4s_ease-in-out_infinite_0.5s]" />
          <div className="absolute inset-24 border border-cyan-400/20 rounded-full animate-[pulse_4s_ease-in-out_infinite_1s]" />
          <div className="absolute inset-36 border border-purple-400/10 rounded-full animate-[pulse_4s_ease-in-out_infinite_1.5s]" />

          {/* Órbita externa - Elementos financieros */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 animate-[bounce_3s_ease-in-out_infinite]">
            <div className="w-14 h-14 bg-slate-800/80 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <FileText className="w-7 h-7 text-green-400" />
            </div>
          </div>

          <div className="absolute top-16 right-16 animate-[bounce_3s_ease-in-out_infinite_0.3s]">
            <div className="w-14 h-14 bg-slate-800/80 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <FileText className="w-7 h-7 text-blue-400" />
            </div>
          </div>

          <div className="absolute top-1/2 right-4 -translate-y-1/2 animate-[bounce_3s_ease-in-out_infinite_0.6s]">
            <div className="w-14 h-14 bg-slate-800/80 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <FileText className="w-7 h-7 text-emerald-400" />
            </div>
          </div>

          <div className="absolute bottom-16 right-16 animate-[bounce_3s_ease-in-out_infinite_0.9s]">
            <div className="w-14 h-14 bg-slate-800/80 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <FileText className="w-7 h-7 text-yellow-400" />
            </div>
          </div>

          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 animate-[bounce_3s_ease-in-out_infinite_1.2s]">
            <div className="w-14 h-14 bg-slate-800/80 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <FileText className="w-7 h-7 text-cyan-400" />
            </div>
          </div>

          <div className="absolute bottom-16 left-16 animate-[bounce_3s_ease-in-out_infinite_1.5s]">
            <div className="w-14 h-14 bg-slate-800/80 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <FileText className="w-7 h-7 text-pink-400" />
            </div>
          </div>

          <div className="absolute top-1/2 left-4 -translate-y-1/2 animate-[bounce_3s_ease-in-out_infinite_1.8s]">
            <div className="w-14 h-14 bg-slate-800/80 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <FileText className="w-7 h-7 text-purple-400" />
            </div>
          </div>

          <div className="absolute top-16 left-16 animate-[bounce_3s_ease-in-out_infinite_2.1s]">
            <div className="w-14 h-14 bg-slate-800/80 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <FileText className="w-7 h-7 text-orange-400" />
            </div>
          </div>

          {/* Órbita interna - Elementos fiscales */}
          <div className="absolute top-20 left-1/2 -translate-x-1/2 animate-[bounce_3.5s_ease-in-out_infinite_0.2s]">
            <div className="w-11 h-11 bg-slate-800/90 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <span className="text-xs font-bold text-yellow-400">SAT</span>
            </div>
          </div>

          <div className="absolute top-1/2 right-20 -translate-y-1/2 animate-[bounce_3.5s_ease-in-out_infinite_0.7s]">
            <div className="w-11 h-11 bg-slate-800/90 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <span className="text-xs font-bold text-purple-400">IVA</span>
            </div>
          </div>

          <div className="absolute bottom-20 left-1/2 -translate-x-1/2 animate-[bounce_3.5s_ease-in-out_infinite_1.2s]">
            <div className="w-11 h-11 bg-slate-800/90 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <span className="text-xs font-bold text-cyan-400">16%</span>
            </div>
          </div>

          <div className="absolute top-1/2 left-20 -translate-y-1/2 animate-[bounce_3.5s_ease-in-out_infinite_1.7s]">
            <div className="w-11 h-11 bg-slate-800/90 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <span className="text-xs font-bold text-blue-400">ISR</span>
            </div>
          </div>

          <div className="absolute top-28 right-24 animate-[bounce_3.5s_ease-in-out_infinite_0.4s]">
            <div className="w-10 h-10 bg-slate-800/90 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <span className="text-[10px] font-bold text-pink-400">RESICO</span>
            </div>
          </div>

          <div className="absolute bottom-28 right-24 animate-[bounce_3.5s_ease-in-out_infinite_0.9s]">
            <div className="w-10 h-10 bg-slate-800/90 backdrop-blur rounded-full flex items-center justify-center border border-slate-600 shadow-lg">
              <span className="text-xs font-bold text-amber-400">$</span>
            </div>
          </div>

          {/* Centro - Logo brillante */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-28 h-28 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-500/50 animate-[pulse_2s_ease-in-out_infinite]">
              <FileText className="w-14 h-14 text-white" />
            </div>
          </div>
        </div>

        {/* Texto superior derecho */}
        <div className="absolute top-20 right-12 text-right max-w-xs">
          <h2 className="text-2xl font-bold text-white mb-2 transition-all duration-300 drop-shadow-lg">
            {currentText.rightTitle}
          </h2>
          <p className="text-slate-300 text-sm">
            {currentText.rightSubtitle}
          </p>
        </div>

        {/* Footer derecho */}
        <div className="absolute bottom-12 left-12">
          <p className="text-slate-400 text-sm">
            <span className="text-white font-semibold">© 2026 Abbax-IA</span>
            <br />
            {language === "es" ? "Desarrollado por Grafyca" : "Smart tax advisory"}
          </p>
        </div>
      </div>
    </div>
  );
}