'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { ERPLayout } from '@/components/ERPLayout';
import { Plus, Edit2, Trash2, X, Check, Building2, AlertCircle, FileCheck, Upload, FileText, Loader2 } from 'lucide-react';

interface Empresa {
  id: string;
  nombre: string;
  rfc: string;
  email?: string;
  telefono?: string;
  direccion?: string;
  regimenFiscal?: string;
  codigoPostal?: string;
  usoCFDI?: string;
  status?: string;
  fechaAlta?: string;
  constanciaFiscalPath?: string;
  constanciaVigente?: boolean;
}

const REGIMENES_FISCALES = [
  { value: '601', label: 'General de Ley Personas Morales' },
  { value: '603', label: 'Personas Morales con Fines no Lucrativos' },
  { value: '612', label: 'Personas Físicas con Actividades Empresariales' },
  { value: '621', label: 'Incorporación Fiscal' },
  { value: '626', label: 'Régimen Simplificado de Confianza' },
];

const USOS_CFDI = [
  { value: 'G01', label: 'Adquisición de mercancías' },
  { value: 'G03', label: 'Gastos en general' },
  { value: 'I02', label: 'Mobiliario y equipo de oficina' },
  { value: 'I04', label: 'Equipo de cómputo' },
  { value: 'D01', label: 'Honorarios médicos' },
  { value: 'D10', label: 'Pagos por servicios educativos' },
  { value: 'CP01', label: 'Carta porte' },
  { value: 'S01', label: 'Sin efectos fiscales' },
];

export default function EmpresasPage() {
  const router = useRouter();
  const [empresas, setEmpresas] = useState<Empresa[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editingEmpresa, setEditingEmpresa] = useState<Empresa | null>(null);
  const [deletingEmpresa, setDeletingEmpresa] = useState<Empresa | null>(null);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; path: string } | null>(null);
  const [saving, setSaving] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    nombre: '',
    rfc: '',
    email: '',
    telefono: '',
    direccion: '',
    regimenFiscal: '',
    codigoPostal: '',
    usoCFDI: '',
  });

  useEffect(() => {
    fetchEmpresas();
  }, []);

  const fetchEmpresas = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/empresas');
      const data = await res.json();
      setEmpresas(data.data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({ nombre: '', rfc: '', email: '', telefono: '', direccion: '', regimenFiscal: '', codigoPostal: '', usoCFDI: '' });
    setEditingEmpresa(null);
    setUploadedFile(null);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingFile(true);

    try {
      const formDataUpload = new FormData();
      formDataUpload.append('file', file);

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formDataUpload,
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Error al subir archivo');
      }

      setUploadedFile({ name: file.name, path: data.filePath });
    } catch (error: any) {
      alert(`❌ Error: ${error.message}`);
    } finally {
      setUploadingFile(false);
    }
  };

  const handleOpenModal = (empresa?: Empresa) => {
    if (empresa) {
      setEditingEmpresa(empresa);
      setFormData({
        nombre: empresa.nombre,
        rfc: empresa.rfc,
        email: empresa.email || '',
        telefono: empresa.telefono || '',
        direccion: empresa.direccion || '',
        regimenFiscal: empresa.regimenFiscal || '',
        codigoPostal: empresa.codigoPostal || '',
        usoCFDI: empresa.usoCFDI || '',
      });
      setUploadedFile(
        empresa.constanciaFiscalPath 
          ? { name: empresa.constanciaFiscalPath.split('\\').pop() || 'constancia.pdf', path: empresa.constanciaFiscalPath } 
          : null
      );
    } else {
      resetForm();
    }
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const payload = {
        ...formData,
        constanciaFiscalPath: uploadedFile?.path || null,
        constanciaVigente: uploadedFile !== null,
      };

      if (editingEmpresa) {
        const res = await fetch(`/api/empresas/${editingEmpresa.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || 'Error al actualizar');
        }
      } else {
        const res = await fetch('/api/empresas', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...payload,
            status: 'activo',
            fechaAlta: new Date().toISOString(),
          }),
        });
        
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || 'Error al crear');
        }
      }
      
      setShowModal(false);
      resetForm();
      fetchEmpresas();
    } catch (error: any) {
      alert(`❌ Error: ${error.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteClick = (empresa: Empresa) => {
    setDeletingEmpresa(empresa);
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = async () => {
    if (!deletingEmpresa) return;
    try {
      await fetch(`/api/empresas/${deletingEmpresa.id}`, { method: 'DELETE' });
      setShowDeleteModal(false);
      setDeletingEmpresa(null);
      fetchEmpresas();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const getStatusBadge = (status?: string) => {
    if (!status) return 'bg-gray-100 text-gray-800';
    const styles: Record<string, string> = {
      activo: 'bg-emerald-100 text-emerald-800',
      inactivo: 'bg-gray-100 text-gray-800',
      cancelado: 'bg-red-100 text-red-800',
    };
    return styles[status] || 'bg-gray-100 text-gray-800';
  };

  const getStatusLabel = (status?: string) => {
    if (!status) return 'Sin estado';
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  return (
    <ERPLayout moduleKey="empresas">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Empresas</h1>
            <p className="text-gray-600">Gestión de empresas con validación SAT</p>
          </div>
          <button onClick={() => handleOpenModal()} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            <Plus size={20} />
            Nueva Empresa
          </button>
        </div>

        <div className="grid grid-cols-4 gap-4">
          <StatCard label="Total" value={empresas.length} icon={<Building2 size={24} />} color="blue" />
          <StatCard label="Activas" value={empresas.filter(e => e.status === 'activo').length} icon={<Check size={24} />} color="emerald" />
          <StatCard label="Inactivas" value={empresas.filter(e => e.status === 'inactivo').length} icon={<AlertCircle size={24} />} color="amber" />
          <StatCard label="Canceladas" value={empresas.filter(e => e.status === 'cancelado').length} icon={<X size={24} />} color="red" />
        </div>

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Empresa</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">RFC</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Régimen</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Constancia</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {loading ? (
                <tr><td colSpan={6} className="px-6 py-12 text-center">Cargando...</td></tr>
              ) : empresas.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center">
                    <Building2 size={48} className="mx-auto mb-4 text-gray-300" />
                    <p>No hay empresas registradas</p>
                    <button onClick={() => handleOpenModal()} className="mt-4 text-blue-600 hover:text-blue-800">
                      Crear la primera empresa
                    </button>
                  </td>
                </tr>
              ) : (
                empresas.map((empresa) => (
                  <tr key={empresa.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">{empresa.nombre}</div>
                      {empresa.email && <div className="text-sm text-gray-500">{empresa.email}</div>}
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-mono text-sm">{empresa.rfc}</div>
                      <div className="text-xs text-gray-500">CP: {empresa.codigoPostal || '-'}</div>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {REGIMENES_FISCALES.find(r => r.value === empresa.regimenFiscal)?.label || 'No especificado'}
                    </td>
                    <td className="px-6 py-4">
                      {empresa.constanciaVigente ? (
                        <span className="flex items-center gap-1 text-emerald-600 text-sm">
                          <FileCheck size={16} /> Subida
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-amber-600 text-sm">
                          <AlertCircle size={16} /> Pendiente
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(empresa.status)}`}>
                        {getStatusLabel(empresa.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button onClick={() => handleOpenModal(empresa)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg" title="Editar">
                          <Edit2 size={18} />
                        </button>
                        <button onClick={() => handleDeleteClick(empresa)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg" title="Eliminar">
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center z-10">
                <h2 className="text-xl font-bold">{editingEmpresa ? 'Editar Empresa' : 'Nueva Empresa'}</h2>
                <button onClick={() => { setShowModal(false); resetForm(); }} className="text-gray-500 hover:text-gray-700">
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Razón Social *</label>
                    <input required value={formData.nombre} onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                      className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" placeholder="Nombre de la empresa" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">RFC *</label>
                    <input required value={formData.rfc}
                      onChange={(e) => setFormData({ ...formData, rfc: e.target.value.toUpperCase() })}
                      className="w-full border rounded-lg px-3 py-2 font-mono focus:ring-2 focus:ring-blue-500" 
                      placeholder="AAA010101AAA" maxLength={13} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Código Postal *</label>
                    <input required value={formData.codigoPostal} onChange={(e) => setFormData({ ...formData, codigoPostal: e.target.value })}
                      className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" placeholder="01000" maxLength={5} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Régimen Fiscal *</label>
                    <select required value={formData.regimenFiscal} onChange={(e) => setFormData({ ...formData, regimenFiscal: e.target.value })}
                      className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
                      <option value="">Seleccionar</option>
                      {REGIMENES_FISCALES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Uso CFDI *</label>
                    <select required value={formData.usoCFDI} onChange={(e) => setFormData({ ...formData, usoCFDI: e.target.value })}
                      className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
                      <option value="">Seleccionar</option>
                      {USOS_CFDI.map(u => <option key={u.value} value={u.value}>{u.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" placeholder="contacto@empresa.com" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Teléfono</label>
                    <input type="tel" value={formData.telefono} onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                      className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" placeholder="55 1234 5678" />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Dirección</label>
                    <textarea value={formData.direccion} onChange={(e) => setFormData({ ...formData, direccion: e.target.value })}
                      className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" rows={2} placeholder="Calle, número, colonia, ciudad" />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Constancia Fiscal de Situación Tributaria (PDF)
                    </label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition">
                      {uploadedFile ? (
                        <div className="flex items-center justify-center gap-3">
                          <FileText className="text-emerald-600 flex-shrink-0" size={32} />
                          <div className="text-left flex-1">
                            <p className="text-sm font-medium text-gray-900 truncate">{uploadedFile.name}</p>
                            <p className="text-xs text-emerald-600">✓ Archivo cargado exitosamente</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setUploadedFile(null);
                              if (fileInputRef.current) fileInputRef.current.value = '';
                            }}
                            className="ml-4 p-2 text-red-600 hover:bg-red-50 rounded-lg"
                            title="Eliminar archivo"
                          >
                            <X size={20} />
                          </button>
                        </div>
                      ) : (
                        <>
                          <Upload className="mx-auto h-12 w-12 text-gray-400" />
                          <p className="mt-2 text-sm text-gray-600">
                            {uploadingFile ? 'Subiendo archivo...' : 'Sube la constancia fiscal del SAT'}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">Formato PDF, máximo 10MB</p>
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept=".pdf"
                            onChange={handleFileUpload}
                            disabled={uploadingFile}
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={uploadingFile}
                            className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 text-sm inline-flex items-center gap-2"
                          >
                            {uploadingFile ? (
                              <>
                                <Loader2 size={16} className="animate-spin" />
                                Subiendo...
                              </>
                            ) : (
                              <>
                                <Upload size={16} />
                                Seleccionar archivo PDF
                              </>
                            )}
                          </button>
                        </>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-2 flex items-start gap-1">
                      <AlertCircle size={12} className="mt-0.5 flex-shrink-0" />
                      <span>La constancia fiscal es opcional pero recomendada para validar los datos de la empresa ante el SAT.</span>
                    </p>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t">
                  <button type="button" onClick={() => { setShowModal(false); resetForm(); }} className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                    Cancelar
                  </button>
                  <button type="submit" disabled={saving || uploadingFile} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 inline-flex items-center gap-2">
                    {saving ? (
                      <>
                        <Loader2 size={18} className="animate-spin" />
                        Guardando...
                      </>
                    ) : (
                      <>
                        <Check size={18} />
                        {editingEmpresa ? 'Actualizar' : 'Crear'} Empresa
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showDeleteModal && deletingEmpresa && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <AlertCircle className="text-red-600" size={24} />
                </div>
                <h3 className="text-lg font-bold">Eliminar Empresa</h3>
              </div>
              <p className="text-sm text-gray-600 mb-6">
                Se eliminará <strong>{deletingEmpresa.nombre}</strong> (RFC: {deletingEmpresa.rfc}). Esta acción no se puede deshacer.
              </p>
              <div className="flex justify-end gap-3">
                <button onClick={() => { setShowDeleteModal(false); setDeletingEmpresa(null); }} className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                  Cancelar
                </button>
                <button onClick={handleConfirmDelete} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                  Eliminar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ERPLayout>
  );
}

function StatCard({ label, value, icon, color }: { label: string; value: number; icon: React.ReactNode; color: string }) {
  const colors: Record<string, string> = { blue: 'border-blue-500', emerald: 'border-emerald-500', amber: 'border-amber-500', red: 'border-red-500' };
  return (
    <div className={`bg-white rounded-xl border-l-4 ${colors[color]} border border-gray-200 p-5 shadow-sm`}>
      <div className="flex items-start justify-between mb-2">
        <p className="text-xs text-gray-500 font-medium">{label}</p>
        <div className="text-gray-400">{icon}</div>
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  );
}