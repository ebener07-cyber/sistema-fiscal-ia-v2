'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import DashboardLayout from '@/components/DashboardLayout';
import { ArrowLeft, CheckCircle, AlertTriangle, XCircle, FileText, Shield } from 'lucide-react';

interface ValidacionSAT {
  rfcValido: boolean;
  regimenFiscalValido: boolean;
  usoCFDIValido: boolean;
  constanciaFiscalValida: boolean;
  estructuraValida: boolean;
  conceptosValidados: ConceptoValidado[];
  alertas: AlertaSAT[];
  recomendaciones: string[];
}

interface ConceptoValidado {
  claveProdServ: string;
  descripcion: string;
  valido: boolean;
  mensaje: string;
  articuloSAT: string;
  riesgo: 'bajo' | 'medio' | 'alto';
}

interface AlertaSAT {
  tipo: 'error' | 'advertencia' | 'info';
  mensaje: string;
  articulo: string;
}

export default function ValidacionSATPage() {
  const params = useParams();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [validacion, setValidacion] = useState<ValidacionSAT | null>(null);
  const [empresa, setEmpresa] = useState<any>(null);

  useEffect(() => {
    if (params.id) {
      fetchValidacionSAT();
    }
  }, [params.id]);

  const fetchValidacionSAT = async () => {
    try {
      setLoading(true);
      // Aquí se haría la llamada a la API de validación SAT
      // Por ahora usamos datos simulados
      const data = await mockValidacionSAT();
      setValidacion(data);
    } catch (error) {
      console.error('Error en validación SAT:', error);
    } finally {
      setLoading(false);
    }
  };

  const mockValidacionSAT = async (): Promise<ValidacionSAT> => {
    // Simulación de validación SAT
    return {
      rfcValido: true,
      regimenFiscalValido: true,
      usoCFDIValido: true,
      constanciaFiscalValida: false,
      estructuraValida: true,
      conceptosValidados: [
        {
          claveProdServ: '01010101',
          descripcion: 'Cereales y leguminosas',
          valido: true,
          mensaje: 'Concepto válido según catálogo SAT',
          articuloSAT: 'Art. 25 LISR',
          riesgo: 'bajo',
        },
        {
          claveProdServ: '43211503',
          descripcion: 'Computadoras personales',
          valido: true,
          mensaje: 'Requiere validación de activo fijo',
          articuloSAT: 'Art. 35 LISR',
          riesgo: 'medio',
        },
        {
          claveProdServ: '80141600',
          descripcion: 'Servicios de consultoría',
          valido: false,
          mensaje: 'Requiere retención de IVA según régimen',
          articuloSAT: 'Art. 1-A Ley IVA',
          riesgo: 'alto',
        },
      ],
      alertas: [
        {
          tipo: 'error',
          mensaje: 'Constancia fiscal vencida o no disponible',
          articulo: 'Art. 29 CFF',
        },
        {
          tipo: 'advertencia',
          mensaje: 'Régimen fiscal requiere actualización anual',
          articulo: 'Art. 76 LISR',
        },
        {
          tipo: 'info',
          mensaje: 'Uso de CFDI correcto para el tipo de empresa',
          articulo: 'Guía de llenado CFDI 4.0',
        },
      ],
      recomendaciones: [
        'Actualizar constancia de situación fiscal antes de emitir facturas',
        'Validar que todos los conceptos tengan clave de producto/servicio del SAT',
        'Implementar complemento de pagos para facturas mayores a $50,000',
        'Revisar régimen fiscal anual para evitar inconsistencias',
        'Mantener documentación comprobatoria de cada operación',
      ],
    };
  };

  const getAlertIcon = (tipo: string) => {
    switch (tipo) {
      case 'error':
        return <XCircle className="text-red-600" size={20} />;
      case 'advertencia':
        return <AlertTriangle className="text-amber-600" size={20} />;
      default:
        return <CheckCircle className="text-emerald-600" size={20} />;
    }
  };

  const getAlertBg = (tipo: string) => {
    switch (tipo) {
      case 'error':
        return 'bg-red-50 border-red-200';
      case 'advertencia':
        return 'bg-amber-50 border-amber-200';
      default:
        return 'bg-emerald-50 border-emerald-200';
    }
  };

  const getRiesgoColor = (riesgo: string) => {
    switch (riesgo) {
      case 'alto':
        return 'bg-red-100 text-red-800';
      case 'medio':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-emerald-100 text-emerald-800';
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => router.push('/empresas')}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Validación SAT</h1>
            <p className="text-gray-600">Análisis de cumplimiento fiscal y validación de conceptos</p>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : validacion ? (
          <>
            {/* Resumen de Validación */}
            <div className="grid grid-cols-5 gap-4">
              <ValidationCard 
                label="RFC Válido"
                valido={validacion.rfcValido}
                icon={<FileText size={24} />}
              />
              <ValidationCard 
                label="Régimen Fiscal"
                valido={validacion.regimenFiscalValido}
                icon={<Shield size={24} />}
              />
              <ValidationCard 
                label="Uso CFDI"
                valido={validacion.usoCFDIValido}
                icon={<FileText size={24} />}
              />
              <ValidationCard 
                label="Constancia Fiscal"
                valido={validacion.constanciaFiscalValida}
                icon={<FileText size={24} />}
              />
              <ValidationCard 
                label="Estructura"
                valido={validacion.estructuraValida}
                icon={<Shield size={24} />}
              />
            </div>

            {/* Alertas */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Alertas de Cumplimiento</h3>
              <div className="space-y-3">
                {validacion.alertas.map((alerta, index) => (
                  <div key={index} className={`flex items-start gap-3 p-4 rounded-lg border ${getAlertBg(alerta.tipo)}`}>
                    {getAlertIcon(alerta.tipo)}
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{alerta.mensaje}</p>
                      <p className="text-xs text-gray-600 mt-1">{alerta.articulo}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Conceptos Validados */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Validación de Conceptos</h3>
              <div className="space-y-3">
                {validacion.conceptosValidados.map((concepto, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium text-gray-900">{concepto.descripcion}</p>
                        <p className="text-sm text-gray-600 font-mono">Clave: {concepto.claveProdServ}</p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRiesgoColor(concepto.riesgo)}`}>
                        Riesgo {concepto.riesgo}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      {concepto.valido ? (
                        <CheckCircle className="text-emerald-600" size={16} />
                      ) : (
                        <XCircle className="text-red-600" size={16} />
                      )}
                      <span className="text-gray-700">{concepto.mensaje}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">{concepto.articuloSAT}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Recomendaciones */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Recomendaciones para Reducir Riesgo de Auditoría</h3>
              <ul className="space-y-2">
                {validacion.recomendaciones.map((rec, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <CheckCircle className="text-blue-600 mt-0.5 flex-shrink-0" size={16} />
                    <span className="text-sm text-gray-700">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </>
        ) : (
          <div className="text-center py-12">
            <AlertTriangle className="mx-auto text-amber-600 mb-4" size={48} />
            <p className="text-gray-600">No se pudo cargar la validación SAT</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

function ValidationCard({ label, valido, icon }: { label: string; valido: boolean; icon: React.ReactNode }) {
  return (
    <div className={`bg-white rounded-lg border-l-4 p-4 shadow-sm ${
      valido ? 'border-emerald-500' : 'border-red-500'
    }`}>
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs text-gray-500 font-medium">{label}</p>
        <div className={valido ? 'text-emerald-600' : 'text-red-600'}>
          {icon}
        </div>
      </div>
      <p className={`text-lg font-bold ${valido ? 'text-emerald-600' : 'text-red-600'}`}>
        {valido ? 'Válido' : 'Inválido'}
      </p>
    </div>
  );
}