# Componentes

## Dashboard

* DashboardCard
* DataTable
* ExpenseDonut
* RevenueChart
* FiscalAlert
* AIRecommendation
* RiskGauge
* KpiCard
* AlertPanel

## Navegación

* Navbar
* Sidebar

## Utilidades

* UploadZone
* QuickSimulation

## Layout

* DashboardLayout
