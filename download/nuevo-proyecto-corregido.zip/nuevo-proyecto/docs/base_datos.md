# Base de Datos

Motor:

PostgreSQL

ORM:

Prisma ORM

Tablas actuales:

* Empresa
* Cliente
* Factura
* AlertaFiscal

Relaciones:

Empresa 1:N Cliente

Empresa 1:N Factura
