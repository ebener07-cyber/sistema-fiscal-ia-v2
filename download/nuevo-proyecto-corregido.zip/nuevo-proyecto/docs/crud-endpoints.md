# 🚀 Endpoints CRUD - Empresas y Clientes

**Estado**: ✅ Implementados  
**Fecha**: 2026-06-06

---

## 📡 Endpoints Disponibles

### EMPRESAS

#### 1. **GET /api/empresas** - Listar todas las empresas
```bash
curl http://localhost:3000/api/empresas
# Con paginación:
curl http://localhost:3000/api/empresas?skip=0&take=10
```

**Respuesta**:
```json
{
  "data": [
    {
      "id": "cuid123",
      "nombre": "Mi Empresa S.A.",
      "rfc": "MIE123456ABC",
      "email": "contacto@empresa.com",
      "telefono": "5512345678",
      "direccion": "Calle 123, México",
      "createdAt": "2026-06-06T...",
      "_count": {
        "clientes": 5,
        "facturas": 12
      }
    }
  ],
  "pagination": {
    "total": 1,
    "skip": 0,
    "take": 10,
    "pages": 1
  }
}
```

---

#### 2. **POST /api/empresas** - Crear nueva empresa
```bash
curl -X POST http://localhost:3000/api/empresas \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Nueva Empresa",
    "rfc": "NEE123456XYZ",
    "email": "info@nuevaempresa.com",
    "telefono": "5587654321",
    "direccion": "Av. Principal 456"
  }'
```

**Campos requeridos**: `nombre`, `rfc`  
**Campos opcionales**: `email`, `telefono`, `direccion`

**Respuesta** (201):
```json
{
  "id": "cuid456",
  "nombre": "Nueva Empresa",
  "rfc": "NEE123456XYZ",
  "email": "info@nuevaempresa.com",
  "telefono": "5587654321",
  "direccion": "Av. Principal 456",
  "createdAt": "2026-06-06T..."
}
```

---

#### 3. **GET /api/empresas/[id]** - Obtener empresa específica
```bash
curl http://localhost:3000/api/empresas/cuid123
```

**Respuesta**:
```json
{
  "id": "cuid123",
  "nombre": "Mi Empresa S.A.",
  "rfc": "MIE123456ABC",
  "email": "contacto@empresa.com",
  "telefono": "5512345678",
  "direccion": "Calle 123, México",
  "createdAt": "2026-06-06T...",
  "clientes": [
    {
      "id": "cliente1",
      "nombre": "Cliente A",
      "rfc": "CLIA123456",
      "correo": "clientea@example.com"
    }
  ],
  "facturas": [
    {
      "id": "fac1",
      "folio": "001",
      "monto": 5000.00,
      "createdAt": "2026-06-06T..."
    }
  ],
  "_count": {
    "clientes": 5,
    "facturas": 12
  }
}
```

---

#### 4. **PUT /api/empresas/[id]** - Actualizar empresa
```bash
curl -X PUT http://localhost:3000/api/empresas/cuid123 \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Empresa Actualizada",
    "email": "nuevo@email.com",
    "telefono": "5599999999",
    "direccion": "Nueva dirección"
  }'
```

**Respuesta** (200):
```json
{
  "id": "cuid123",
  "nombre": "Empresa Actualizada",
  "rfc": "MIE123456ABC",
  "email": "nuevo@email.com",
  "telefono": "5599999999",
  "direccion": "Nueva dirección",
  "createdAt": "2026-06-06T..."
}
```

---

#### 5. **DELETE /api/empresas/[id]** - Eliminar empresa
```bash
curl -X DELETE http://localhost:3000/api/empresas/cuid123
```

**Respuesta** (200):
```json
{
  "message": "Empresa eliminada correctamente"
}
```

**Nota**: No se puede eliminar si tiene clientes o facturas asociadas.

---

### CLIENTES

#### 1. **GET /api/clientes** - Listar todos los clientes
```bash
curl http://localhost:3000/api/clientes
# Con filtro por empresa:
curl http://localhost:3000/api/clientes?empresaId=cuid123
# Con paginación:
curl http://localhost:3000/api/clientes?skip=0&take=10
```

**Respuesta**:
```json
{
  "data": [
    {
      "id": "cliente1",
      "nombre": "Cliente A",
      "rfc": "CLIA123456",
      "correo": "clientea@example.com",
      "empresaId": "cuid123",
      "createdAt": "2026-06-06T...",
      "empresa": {
        "id": "cuid123",
        "nombre": "Mi Empresa S.A.",
        "rfc": "MIE123456ABC"
      }
    }
  ],
  "pagination": {
    "total": 5,
    "skip": 0,
    "take": 10,
    "pages": 1
  }
}
```

---

#### 2. **POST /api/clientes** - Crear nuevo cliente
```bash
curl -X POST http://localhost:3000/api/clientes \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Nuevo Cliente",
    "rfc": "NUCL123456XYZ",
    "correo": "nuevocliente@example.com",
    "empresaId": "cuid123"
  }'
```

**Campos requeridos**: `nombre`, `rfc`, `correo`, `empresaId`

**Respuesta** (201):
```json
{
  "id": "cliente2",
  "nombre": "Nuevo Cliente",
  "rfc": "NUCL123456XYZ",
  "correo": "nuevocliente@example.com",
  "empresaId": "cuid123",
  "createdAt": "2026-06-06T...",
  "empresa": {
    "id": "cuid123",
    "nombre": "Mi Empresa S.A.",
    "rfc": "MIE123456ABC"
  }
}
```

---

#### 3. **GET /api/clientes/[id]** - Obtener cliente específico
```bash
curl http://localhost:3000/api/clientes/cliente1
```

**Respuesta**:
```json
{
  "id": "cliente1",
  "nombre": "Cliente A",
  "rfc": "CLIA123456",
  "correo": "clientea@example.com",
  "empresaId": "cuid123",
  "createdAt": "2026-06-06T...",
  "empresa": {
    "id": "cuid123",
    "nombre": "Mi Empresa S.A.",
    "rfc": "MIE123456ABC"
  }
}
```

---

#### 4. **PUT /api/clientes/[id]** - Actualizar cliente
```bash
curl -X PUT http://localhost:3000/api/clientes/cliente1 \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Cliente A Actualizado",
    "correo": "nuevo@clientea.com"
  }'
```

**Respuesta** (200):
```json
{
  "id": "cliente1",
  "nombre": "Cliente A Actualizado",
  "rfc": "CLIA123456",
  "correo": "nuevo@clientea.com",
  "empresaId": "cuid123",
  "createdAt": "2026-06-06T...",
  "empresa": {
    "id": "cuid123",
    "nombre": "Mi Empresa S.A.",
    "rfc": "MIE123456ABC"
  }
}
```

---

#### 5. **DELETE /api/clientes/[id]** - Eliminar cliente
```bash
curl -X DELETE http://localhost:3000/api/clientes/cliente1
```

**Respuesta** (200):
```json
{
  "message": "Cliente eliminado correctamente"
}
```

---

## 🧪 Testing Completo

### Crear Empresa de Prueba
```bash
curl -X POST http://localhost:3000/api/empresas \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Test Company",
    "rfc": "TST123456ABC",
    "email": "test@company.com"
  }'

# Guarda el ID de la respuesta, ej: "test-empresa-id"
```

### Listar Empresas
```bash
curl http://localhost:3000/api/empresas
```

### Crear Cliente para esa Empresa
```bash
curl -X POST http://localhost:3000/api/clientes \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Test Client",
    "rfc": "TSTC123456XYZ",
    "correo": "testclient@example.com",
    "empresaId": "test-empresa-id"
  }'
```

### Listar Clientes de una Empresa
```bash
curl http://localhost:3000/api/clientes?empresaId=test-empresa-id
```

### Actualizar Empresa
```bash
curl -X PUT http://localhost:3000/api/empresas/test-empresa-id \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Test Company Updated"
  }'
```

### Obtener Detalles (con clientes y facturas)
```bash
curl http://localhost:3000/api/empresas/test-empresa-id
```

### Eliminar Cliente
```bash
curl -X DELETE http://localhost:3000/api/clientes/test-cliente-id
```

### Intentar Eliminar Empresa (fallará si tiene datos)
```bash
curl -X DELETE http://localhost:3000/api/empresas/test-empresa-id
# Si falla, significa que tiene clientes o facturas asociadas
```

---

## 📋 Códigos de Respuesta

| Código | Significado | Ejemplo |
|--------|-------------|---------|
| **200** | OK | Actualización exitosa |
| **201** | Created | Recurso creado exitosamente |
| **400** | Bad Request | Campos requeridos faltantes |
| **404** | Not Found | Recurso no existe |
| **409** | Conflict | RFC duplicado o empresa con datos asociados |
| **500** | Server Error | Error en el servidor |

---

## 🛠️ Herramientas para Testear

### Opción 1: cURL (línea de comandos)
```bash
curl http://localhost:3000/api/empresas
```

### Opción 2: VS Code REST Client
Crea archivo `test.http`:
```http
GET http://localhost:3000/api/empresas

###

POST http://localhost:3000/api/empresas
Content-Type: application/json

{
  "nombre": "Test",
  "rfc": "TST123456ABC"
}
```

### Opción 3: Postman / Insomnia
- Importa los ejemplos de arriba
- Usa variables para IDs

### Opción 4: Desde el Navegador
```javascript
// Console del navegador
fetch('http://localhost:3000/api/empresas').then(r => r.json()).then(console.log)
```

---

## ✅ Validaciones Implementadas

### Empresas
- ✅ RFC obligatorio y único
- ✅ Nombre obligatorio
- ✅ No se puede eliminar si tiene clientes/facturas
- ✅ Email, teléfono y dirección opcionales

### Clientes
- ✅ RFC obligatorio y único
- ✅ Nombre, email y empresaId obligatorios
- ✅ Valida que la empresa exista
- ✅ Se puede eliminar sin restricciones

---

## 🔗 Relaciones

```
Empresa (1)
  ├── (N) Clientes
  └── (N) Facturas

Cliente (N)
  └── (1) Empresa
```

---

## 📊 Ejemplos de Flujo

### Flujo 1: Crear empresa y agregar cliente
1. POST /api/empresas → Obtener `empresaId`
2. POST /api/clientes → Usar `empresaId`
3. GET /api/empresas/{id} → Ver empresa con clientes

### Flujo 2: Listar y filtrar
1. GET /api/empresas?skip=0&take=5
2. GET /api/clientes?empresaId=xyz

### Flujo 3: Actualizar y verificar
1. PUT /api/empresas/{id}
2. GET /api/empresas/{id} → Verificar cambios

---

**Estado**: ✅ **LISTO PARA USAR**

Los endpoints están completamente funcionales. Ahora puedes:
- Crear, leer, actualizar y eliminar empresas y clientes
- Paginar resultados
- Filtrar clientes por empresa
- Verificar relaciones (GET /api/empresas/{id} muestra clientes)
