# Integración de Graphify con Chat IA

**Fecha**: 2026-06-06  
**Estado**: ✅ Implementado  
**Versión**: 1.0

## ¿Qué es esta integración?

Graphify (memoria técnica del proyecto) ahora se integra automáticamente con el sistema de chat IA. Esto significa que las respuestas del asesor fiscal incluyen contexto automático sobre:

- Arquitectura técnica del sistema
- Entidades de datos (Empresas, Clientes, Facturas)
- Relaciones en la base de datos
- Rutas y endpoints disponibles

## Cómo funciona

```
Usuario escribe pregunta fiscal
        ↓
Frontend envía a /api/ia-fiscal/chat
        ↓
Backend carga system.md + Graphify
        ↓
Sistema enriquece prompt con contexto técnico
        ↓
Groq LLM recibe prompt mejorado
        ↓
Respuesta más precisa y contextualizada
        ↓
Respuesta llega al usuario
```

## Archivos Clave

### `/src/lib/graphify.ts`
Parser que lee la memoria técnica:
- `loadGraphifyContext()` - Carga todos los archivos Graphify
- `enrichPromptWithGraphify(prompt)` - Enriquece un prompt con contexto
- `getGraphifySection(section)` - Obtiene una sección específica

### `/prompts/system.md`
System prompt enriquecido con:
- Rol y responsabilidades del asesor fiscal
- Valores y principios
- Restricciones importantes
- Contexto de entidades del sistema

### `/app/api/ia-fiscal/chat/route.ts`
Endpoint actualizado que:
- Carga system.md automáticamente
- Enriquece con contexto de Graphify
- Mantiene respuestas en rango de tokens
- Maneja errores elegantemente

## Archivos de Prompts

Se completaron 4 archivos de prompts para documentar patrones:

| Archivo | Propósito |
|---------|-----------|
| `prompts/system.md` | Sistema prompt principal (cargado en todas las IA) |
| `prompts/backend.md` | Validaciones, cálculos, análisis fiscales |
| `prompts/frontend.md` | Mensajes UI, validaciones, componentes |
| `prompts/nextjs.md` | Patrones React, rutas, integración |
| `prompts/prisma.md` | Schema, operaciones, consideraciones BD |

## Cómo usar en desarrollo

### Agregar nueva sección a Graphify
1. Edita un archivo en `/graphify/` (ej: `graphify/contexto.md`)
2. La próxima llamada al chat cargará automáticamente los cambios
3. El contexto se enriquece sin tocar el código

### Modificar el system prompt
1. Edita `/prompts/system.md`
2. Reinicia el servidor (o Next.js se recarga automáticamente)
3. Las nuevas conversaciones usan el prompt actualizado

### Agregar reglas de validación
1. Documenta en `/prompts/backend.md`
2. Implementa lógica en componentes/API routes
3. El asesor fiscal tendrá contexto de esas reglas

## Ventajas de esta arquitectura

✅ **Separación de responsabilidades**: Prompts en archivos, código limpio  
✅ **Fácil mantenimiento**: Cambiar prompts sin tocar código  
✅ **Escalable**: Agregar más secciones a Graphify sin recompilación  
✅ **Reutilizable**: Mismos prompts para múltiples IA (si hay)  
✅ **Versionable**: Los prompts están en git, fácil de trackear cambios  

## Próximos pasos (Opcional)

- [ ] Agregar persistencia de conversaciones (guardar historial)
- [ ] Implementar RAG (Retrieval-Augmented Generation) con Graphify
- [ ] Crear sistema de feedback para mejorar prompts
- [ ] Agregar multi-turno conversacional (contexto de turno anterior)
- [ ] Implementar validación de respuestas (fact-checking contra Graphify)

## Troubleshooting

### Error: "No se pudo cargar system.md"
- Verifica que `/prompts/system.md` existe
- Comprueba permisos de lectura del archivo

### Error: "No se pudo cargar Graphify"
- Verifica que `/graphify/` existe con archivos .md
- Check console logs para ver qué sección falló
- El sistema funciona con prompts degradados si no encuentra Graphify

### El chat no usa contexto Graphify
- Asegúrate que `/src/lib/graphify.ts` está correctamente importado
- Revisa que `enrichPromptWithGraphify()` se llama en route.ts
- Aumenta `max_tokens` si la respuesta se corta
