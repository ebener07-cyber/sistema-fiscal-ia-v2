Sistema Fiscal Auditado
Descripción

Plataforma web para gestión fiscal, administrativa y documental de empresas.

Tecnologías
Frontend
Next.js 15
React
TypeScript
Tailwind CSS
Backend
Next.js API Routes
Prisma ORM
Base de Datos
PostgreSQL
IA
ChatGPT (Arquitecto y Programador Principal)
Graphify (Memoria Técnica)
Objetivo

Centralizar:

Empresas
Clientes
Facturación
CFDI
SAT
Impuestos
Nómina
Riesgo Fiscal
IA Fiscal
Arquitectura IA

Sistema Fiscal Auditado
│
▼
Graphify
(Memoria Técnica)
│
▼
Contexto Relevante
│
▼
ChatGPT
(Arquitecto y Programador)
│
▼
Código
Documentación
Refactorización
Pruebas