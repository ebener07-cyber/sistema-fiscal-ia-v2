# Módulos del Sistema

## Operativos

* Dashboard
* Empresas
* Clientes
* Bancos
* Proveedores

## Fiscal

* SAT
* CFDI
* Constancia Fiscal
* Opinión de Cumplimiento

## Financiero

* Facturación
* Gastos
* Impuestos

## Laboral

* Nómina
* IMSS
* INFONAVIT

## Inteligencia

* Alertas Fiscales
* Recomendaciones IA
