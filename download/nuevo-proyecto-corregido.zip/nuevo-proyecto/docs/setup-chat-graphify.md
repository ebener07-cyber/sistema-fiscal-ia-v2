# 🔧 Configuración de Chat + Graphify

## 📋 Descripción General

Esta configuración integra completamente **Graphify** (memoria técnica) con el sistema de **Chat IA** y toda la aplicación. Ahora:

- ✅ Graphify está disponible en toda la app
- ✅ El Chat enriquece automáticamente prompts con contexto
- ✅ Configuración centralizada y validada
- ✅ Hooks para acceder a Graphify desde componentes
- ✅ API endpoint para servir Graphify

## 🗂️ Estructura de Archivos

```
src/
├── env.ts                          # Validación de variables de ambiente
├── config/
│   └── app.ts                      # Configuración centralizada de la app
├── lib/
│   ├── graphify.ts                 # Parser de Graphify (servidor)
│   └── graphify-utils.ts           # Utilidades para trabajar con Graphify
├── providers/
│   └── GraphifyProvider.tsx        # Context Provider para toda la app
├── types/
│   └── graphify.ts                 # Tipos TypeScript
└── ...

app/
├── layout.tsx                      # Layout con GraphifyProvider
├── api/
│   ├── graphify/
│   │   └── route.ts               # GET /api/graphify - Endpoint de Graphify
│   └── ia-fiscal/
│       └── chat/
│           └── route.ts            # POST /api/ia-fiscal/chat - Chat mejorado
└── ...
```

## 🚀 Cómo Usar

### 1. **En Componentes (Cliente)**

```typescript
'use client';

import { useGraphify, useGraphifySection } from '@/providers/GraphifyProvider';

export function MiComponente() {
  // Obtener todo el contexto de Graphify
  const { graphify, isLoading, getSection } = useGraphify();

  // O usar hook específico para una sección
  const { content: rutas } = useGraphifySection('rutas');

  if (isLoading) return <div>Cargando contexto...</div>;

  return (
    <div>
      <h2>Rutas del Sistema</h2>
      <pre>{rutas}</pre>
    </div>
  );
}
```

### 2. **En API Routes (Servidor)**

```typescript
import { loadGraphifyContext, enrichPromptWithGraphify } from '@/lib/graphify';
import env from '@/env';
import { APP_CONFIG } from '@/config/app';

export async function POST(req: Request) {
  // Cargar contexto de Graphify
  const graphify = await loadGraphifyContext();
  
  // Enriquecer un prompt con contexto
  const prompt = 'Tu pregunta aquí';
  const enriched = await enrichPromptWithGraphify(prompt);

  // Usar configuración
  console.log(APP_CONFIG.ai.model);
  console.log(env.GROQ_API_KEY);

  // ...
}
```

### 3. **Para Procesar Graphify**

```typescript
import {
  extractMarkdownSection,
  cleanMarkdown,
  summarizeContent,
  formatAsTable,
  formatAsList,
} from '@/lib/graphify-utils';

// Extraer sección de Graphify
const entidades = graphify.entidades;
const empresaSection = extractMarkdownSection(entidades, 'Empresa');

// Limpiar markdown
const plainText = cleanMarkdown(empresaSection);

// Resumir contenido
const summary = summarizeContent(plainText, 200);

// Formatear
const list = formatAsList(['item1', 'item2']);
```

### 4. **Caché Local en Navegador**

```typescript
import { GraphifyCache } from '@/lib/graphify-utils';

// Guardar sección en caché (1 hora)
GraphifyCache.save('rutas', contenido, 3600000);

// Obtener del caché
const cached = GraphifyCache.get('rutas');

// Limpiar todo
GraphifyCache.clear();
```

## 🔐 Variables de Ambiente

Crea `.env.local` en la raíz del proyecto:

```env
GROQ_API_KEY=tu_api_key_de_groq_aqui
DATABASE_URL=postgresql://usuario:password@localhost:5432/base_datos
```

El archivo `src/env.ts` validará que existan automáticamente.

## ⚙️ Configuración Centralizada

Edita `src/config/app.ts` para cambiar:

- ✏️ Nombre y versión de la app
- ✏️ Rutas disponibles
- ✏️ Endpoints de API
- ✏️ Parámetros de IA (modelo, temperatura, tokens)
- ✏️ Configuración fiscal (impuestos, períodos)
- ✏️ Configuración de UI (tema, idioma)
- ✏️ Timeouts

## 🔄 Flujo de Chat Enriquecido

```
Usuario pregunta en /ia-fiscal
       ↓
Frontend envía a POST /api/ia-fiscal/chat
       ↓
Backend carga prompts/system.md
       ↓
enrichPromptWithGraphify() carga Graphify automáticamente
       ↓
System prompt enriquecido con contexto + Graphify
       ↓
Groq LLM procesa prompt mejorado
       ↓
Respuesta inteligente y contextualizada
       ↓
Se devuelve al usuario
```

## 📡 Endpoint de Graphify

```bash
# GET /api/graphify
# Devuelve todo el contexto de Graphify en JSON
# Cache: 1 hora (para no cargar archivos constantemente)

curl http://localhost:3000/api/graphify

# Respuesta:
{
  "contexto": "...",
  "entidades": "...",
  "relaciones": "...",
  "componentes": "...",
  "rutas": "...",
  "mapaDelSistema": "...",
  "sesiones": "...",
  "dependencias": "...",
  "isLoading": false,
  "error": null
}
```

## 🧪 Testing

### Verificar que Graphify carga correctamente:

```bash
# En navegador
curl http://localhost:3000/api/graphify

# Debería devolver JSON con todas las secciones
```

### Verificar que Chat enriquece prompts:

```bash
curl -X POST http://localhost:3000/api/ia-fiscal/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "¿Qué es una entidad de empresa en el sistema?"}'

# El chat ahora incluye contexto de Graphify automáticamente
```

## 📦 Dependencias Requeridas

Ya están instaladas:
- ✅ next 16.2.6
- ✅ react 19.2.4
- ✅ groq-sdk 1.2.1
- ✅ @prisma/client 6.19.3

No necesitas instalar nada más.

## 🐛 Troubleshooting

### Error: "useGraphify debe ser usado dentro de GraphifyProvider"

**Solución**: Asegúrate que el componente está envuelto en el árbol dentro de `<GraphifyProvider>` (en layout.tsx está).

### Error: "GROQ_API_KEY no está configurada"

**Solución**: Crea `.env.local` con `GROQ_API_KEY=tu_clave`.

### Graphify no carga en componentes cliente

**Solución**: El Provider hace un fetch a `/api/graphify` al montar. Verifica que:
1. El endpoint existe y responde
2. Hay conexión a internet
3. No hay errores en consola del navegador

### El chat no enriquece prompts

**Solución**: Verifica que:
1. `prompts/system.md` existe
2. `/graphify/*.md` existen con contenido
3. `enrichPromptWithGraphify()` se llama en route.ts
4. No hay errores en logs del servidor

## 📖 Referencia Rápida

| Necesito | Usar |
|----------|------|
| Variables de ambiente | `import env from '@/env'` |
| Configuración global | `import { APP_CONFIG } from '@/config/app'` |
| Graphify en componente | `useGraphify()` o `useGraphifySection()` |
| Graphify en API route | `import { loadGraphifyContext }` |
| Procesar markdown | `import { cleanMarkdown, extractMarkdownSection }` |
| Toda la estructura | Ver este archivo |

## ✨ Resumen

Ahora tienes:
- ✅ Sistema centralizado y validado de configuración
- ✅ Graphify disponible en toda la app (frontend + backend)
- ✅ Chat inteligente enriquecido con contexto del proyecto
- ✅ Hooks para acceder a Graphify desde componentes
- ✅ Utilidades para procesar y cachear Graphify
- ✅ API endpoint para servir Graphify
- ✅ TypeScript types para Graphify

**Estado**: 🚀 **LISTO PARA PRODUCCIÓN**
