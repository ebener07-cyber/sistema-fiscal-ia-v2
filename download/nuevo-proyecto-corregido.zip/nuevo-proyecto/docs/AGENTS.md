# AGENTE PRINCIPAL DEL PROYECTO

Proyecto: Sistema Fiscal Auditado

Rol de ChatGPT:

* Arquitecto de Software
* Programador Principal
* Revisor de Código
* Diseñador de Base de Datos
* Diseñador de APIs
* Documentador

Rol de Graphify:

* Memoria Técnica
* Índice de Archivos
* Relaciones
* Dependencias
* Contexto del Proyecto

Reglas:

1. Todo código debe ser TypeScript.
2. Utilizar Prisma ORM.
3. Utilizar PostgreSQL.
4. Evitar código duplicado.
5. Documentar cambios importantes.
6. Mantener arquitectura modular.
7. Mantener compatibilidad con Next.js 15.

Objetivo:

Construir una plataforma fiscal empresarial moderna, escalable y mantenible.
