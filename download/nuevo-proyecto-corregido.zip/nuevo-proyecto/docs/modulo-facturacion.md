# 🚀 Módulo de Facturación/CFDI 4.0

**Estado**: ✅ Implementado  
**Fecha**: 2026-06-06

---

## 📁 Estructura del Módulo

```
app/
├── api/facturas/
│   ├── route.ts          # GET (listar), POST (crear)
│   └── [id]/route.ts     # GET, PUT, DELETE
└── facturacion/
    └── page.tsx           # Interfaz de usuario
```

---

## 🗄️ Modelo de Datos (Prisma)

### Factura
- `id`, `folio`, `serie`, `fecha`
- `monto`, `subtotal`, `totalImpuestos`, `descuento`
- `moneda`, `tipoCambio`, `tipoComprobante` (I/E/N)
- `metodoPago` (PUE/PPD), `formaPago`
- `uuid` (para CFDI timbrado)
- `estado` (borrador/timbrado/cancelado)
- `receptorRfc`, `receptorNombre`, `receptorUsoCfdi`
- `emisorRfc`, `emisorNombre`
- `xmlTimbrado`, `complementoPago`, `complementoNomina`

### Concepto
- `claveProdServ`, `noIdentificacion`, `cantidad`
- `claveUnidad`, `unidad`, `descripcion`
- `valorUnitario`, `importe`, `objetoImpuesto`

### Impuesto
- `tipo` (Traslado/Retencion)
- `impuesto` (001=ISR, 002=IVA, 003=IEPS)
- `tasaOcuota`, `importe`, `retencion`

---

## 📡 Endpoints API

### GET /api/facturas
Lista facturas con filtros y paginación.

**Query params**: `skip`, `take`, `empresaId`, `estado`, `fechaDesde`, `fechaHasta`

### POST /api/facturas
Crea factura con conceptos e impuestos.

### GET /api/facturas/[id]
Obtiene detalle de factura.

### PUT /api/facturas/[id]
Actualiza factura (solo en estado borrador).

### DELETE /api/facturas/[id]
Elimina factura (solo en estado borrador).

---

## 🎨 Interfaz de Usuario

### Características
- Lista de facturas con búsqueda y filtros
- Modal para crear nuevas facturas
- Modal para ver detalles
- Cálculo automático de totales e impuestos
- Paginación
- Badges de estado (borrador/timbrado/cancelado)

### Catálogos SAT Implementados
- Tipos de comprobante (Ingreso/Egreso/Nómina)
- Métodos de pago (PUE/PPD)
- Formas de pago (01-99)
- Usos CFDI (G01, G02, G03, CP01, P01)

---

## ⚠️ Pendiente

1. **Timbrado CFDI**: Integración con PAC (Servicio de timbrado)
2. **Cancelación**: Integración con SAT para cancelar facturas
3. **Complementos**: Carta porte, nómina, pagos
4. **Exportar PDF**: Generación de PDF para impresión
5. **Reportes**: Estadísticas de facturación

---

## 🚀 Próximos Pasos

1. Ejecutar migración: `npx prisma migrate dev --name add_cfdi_models`
2. Iniciar servidor: `npm run dev`
3. Acceder a: `http://localhost:3000/facturacion`