-- ============================================================================
-- MIGRATION: Módulo Reestructura Financiera
-- Añade 10 tablas nuevas para gestión de patrimonio, deudas, fondo de
-- emergencia, inversiones, seguros, metas y KPIs financieros.
-- No afecta tablas existentes.
-- ============================================================================

-- CreateTable: Activo
CREATE TABLE "Activo" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "nombre" TEXT NOT NULL,
    "descripcion" TEXT,
    "valor" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "esLiquidable" BOOLEAN NOT NULL DEFAULT false,
    "fechaValor" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "rendimientoAnual" DOUBLE PRECISION,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Activo_pkey" PRIMARY KEY ("id")
);

-- CreateTable: Pasivo
CREATE TABLE "Pasivo" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "nombre" TEXT NOT NULL,
    "descripcion" TEXT,
    "saldo" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "tasaInteresMensual" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "pagoMensualMinimo" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "fechaVencimiento" TIMESTAMP(3),
    "acreedor" TEXT,
    "estado" TEXT NOT NULL DEFAULT 'activa',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Pasivo_pkey" PRIMARY KEY ("id")
);

-- CreateTable: FondoEmergencia
CREATE TABLE "FondoEmergencia" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "meta" DOUBLE PRECISION NOT NULL DEFAULT 200000,
    "saldoActual" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "cuentaDestino" TEXT,
    "activoId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FondoEmergencia_pkey" PRIMARY KEY ("id")
);

-- CreateTable: MovimientoFondo
CREATE TABLE "MovimientoFondo" (
    "id" TEXT NOT NULL,
    "fondoId" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "monto" DOUBLE PRECISION NOT NULL,
    "descripcion" TEXT,
    "fecha" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "MovimientoFondo_pkey" PRIMARY KEY ("id")
);

-- CreateTable: MovimientoFinanciero
CREATE TABLE "MovimientoFinanciero" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "categoria" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "concepto" TEXT NOT NULL,
    "monto" DOUBLE PRECISION NOT NULL,
    "facturaId" TEXT,
    "fecha" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "descripcion" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "MovimientoFinanciero_pkey" PRIMARY KEY ("id")
);

-- CreateTable: Deuda
CREATE TABLE "Deuda" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "pasivoId" TEXT,
    "nombre" TEXT NOT NULL,
    "acreedor" TEXT NOT NULL,
    "saldoActual" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "tasaInteresMensual" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "pagoMensualMinimo" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "estrategia" TEXT NOT NULL DEFAULT 'avalancha',
    "prioridad" INTEGER NOT NULL DEFAULT 99,
    "estado" TEXT NOT NULL DEFAULT 'activa',
    "fechaEstimadaPago" TIMESTAMP(3),
    "notasRenegociacion" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Deuda_pkey" PRIMARY KEY ("id")
);

-- CreateTable: Inversion
CREATE TABLE "Inversion" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "nombre" TEXT NOT NULL,
    "descripcion" TEXT,
    "montoInvertido" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "valorActual" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "rendimientoAnual" DOUBLE PRECISION,
    "fechaInversion" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "plazoMeses" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Inversion_pkey" PRIMARY KEY ("id")
);

-- CreateTable: Seguro
CREATE TABLE "Seguro" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "nombre" TEXT NOT NULL,
    "aseguradora" TEXT,
    "sumaAsegurada" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "primaMensual" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "fechaInicio" TIMESTAMP(3),
    "fechaFin" TIMESTAMP(3),
    "estado" TEXT NOT NULL DEFAULT 'vigente',
    "descripcion" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Seguro_pkey" PRIMARY KEY ("id")
);

-- CreateTable: MetaFinanciera
CREATE TABLE "MetaFinanciera" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "fase" INTEGER NOT NULL DEFAULT 1,
    "nombre" TEXT NOT NULL,
    "descripcion" TEXT,
    "meta" DOUBLE PRECISION NOT NULL,
    "progreso" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "fechaObjetivo" TIMESTAMP(3),
    "estado" TEXT NOT NULL DEFAULT 'pendiente',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MetaFinanciera_pkey" PRIMARY KEY ("id")
);

-- CreateTable: KPIFinanciero
CREATE TABLE "KPIFinanciero" (
    "id" TEXT NOT NULL,
    "empresaId" TEXT NOT NULL,
    "fecha" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "patrimonioNeto" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "activoTotal" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "pasivoTotal" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "tasaAhorro" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "ratioEndeudamiento" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "diasCoberturaCaja" INTEGER NOT NULL DEFAULT 0,
    "progresoFondoEmergencia" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "totalDeudas" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "faseActual" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "KPIFinanciero_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Activo_empresaId_idx" ON "Activo"("empresaId");
CREATE INDEX "Activo_tipo_idx" ON "Activo"("tipo");

CREATE INDEX "Pasivo_empresaId_idx" ON "Pasivo"("empresaId");
CREATE INDEX "Pasivo_tipo_idx" ON "Pasivo"("tipo");
CREATE INDEX "Pasivo_estado_idx" ON "Pasivo"("estado");

CREATE INDEX "FondoEmergencia_empresaId_idx" ON "FondoEmergencia"("empresaId");

CREATE INDEX "MovimientoFondo_fondoId_idx" ON "MovimientoFondo"("fondoId");
CREATE INDEX "MovimientoFondo_fecha_idx" ON "MovimientoFondo"("fecha");

CREATE INDEX "MovimientoFinanciero_empresaId_idx" ON "MovimientoFinanciero"("empresaId");
CREATE INDEX "MovimientoFinanciero_categoria_idx" ON "MovimientoFinanciero"("categoria");
CREATE INDEX "MovimientoFinanciero_tipo_idx" ON "MovimientoFinanciero"("tipo");
CREATE INDEX "MovimientoFinanciero_fecha_idx" ON "MovimientoFinanciero"("fecha");

CREATE INDEX "Deuda_empresaId_idx" ON "Deuda"("empresaId");
CREATE INDEX "Deuda_estado_idx" ON "Deuda"("estado");
CREATE INDEX "Deuda_prioridad_idx" ON "Deuda"("prioridad");

CREATE INDEX "Inversion_empresaId_idx" ON "Inversion"("empresaId");
CREATE INDEX "Inversion_tipo_idx" ON "Inversion"("tipo");

CREATE INDEX "Seguro_empresaId_idx" ON "Seguro"("empresaId");
CREATE INDEX "Seguro_tipo_idx" ON "Seguro"("tipo");
CREATE INDEX "Seguro_estado_idx" ON "Seguro"("estado");

CREATE INDEX "MetaFinanciera_empresaId_idx" ON "MetaFinanciera"("empresaId");
CREATE INDEX "MetaFinanciera_fase_idx" ON "MetaFinanciera"("fase");
CREATE INDEX "MetaFinanciera_estado_idx" ON "MetaFinanciera"("estado");

CREATE INDEX "KPIFinanciero_empresaId_idx" ON "KPIFinanciero"("empresaId");
CREATE INDEX "KPIFinanciero_fecha_idx" ON "KPIFinanciero"("fecha");

-- AddForeignKey
ALTER TABLE "Activo" ADD CONSTRAINT "Activo_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Pasivo" ADD CONSTRAINT "Pasivo_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "FondoEmergencia" ADD CONSTRAINT "FondoEmergencia_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "MovimientoFondo" ADD CONSTRAINT "MovimientoFondo_fondoId_fkey" FOREIGN KEY ("fondoId") REFERENCES "FondoEmergencia"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "MovimientoFinanciero" ADD CONSTRAINT "MovimientoFinanciero_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Deuda" ADD CONSTRAINT "Deuda_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Inversion" ADD CONSTRAINT "Inversion_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Seguro" ADD CONSTRAINT "Seguro_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "MetaFinanciera" ADD CONSTRAINT "MetaFinanciera_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "KPIFinanciero" ADD CONSTRAINT "KPIFinanciero_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
