-- AlterTable
ALTER TABLE "Factura" ADD COLUMN     "descargaSATId" TEXT;

-- CreateTable
CREATE TABLE "DescargaSAT" (
    "id" TEXT NOT NULL,
    "solicitudId" TEXT NOT NULL,
    "rfc" TEXT NOT NULL,
    "fechaInicial" TIMESTAMP(3) NOT NULL,
    "fechaFinal" TIMESTAMP(3) NOT NULL,
    "tipo" TEXT NOT NULL,
    "estado" TEXT NOT NULL DEFAULT 'pendiente',
    "codigoEstado" INTEGER,
    "mensajeEstado" TEXT,
    "numeroCFDIs" INTEGER NOT NULL DEFAULT 0,
    "numeroPaquetes" INTEGER NOT NULL DEFAULT 0,
    "fechaSolicitud" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "fechaUltimaActualizacion" TIMESTAMP(3),
    "fechaCompletado" TIMESTAMP(3),
    "archivosZipPath" TEXT,
    "archivosProcesados" BOOLEAN NOT NULL DEFAULT false,
    "empresaId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DescargaSAT_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "DescargaSAT_solicitudId_key" ON "DescargaSAT"("solicitudId");

-- CreateIndex
CREATE INDEX "DescargaSAT_solicitudId_idx" ON "DescargaSAT"("solicitudId");

-- CreateIndex
CREATE INDEX "DescargaSAT_rfc_idx" ON "DescargaSAT"("rfc");

-- CreateIndex
CREATE INDEX "DescargaSAT_estado_idx" ON "DescargaSAT"("estado");

-- CreateIndex
CREATE INDEX "DescargaSAT_empresaId_idx" ON "DescargaSAT"("empresaId");

-- CreateIndex
CREATE INDEX "DescargaSAT_fechaSolicitud_idx" ON "DescargaSAT"("fechaSolicitud");

-- CreateIndex
CREATE INDEX "DescargaSAT_fechaInicial_fechaFinal_idx" ON "DescargaSAT"("fechaInicial", "fechaFinal");

-- CreateIndex
CREATE INDEX "Factura_descargaSATId_idx" ON "Factura"("descargaSATId");

-- AddForeignKey
ALTER TABLE "Factura" ADD CONSTRAINT "Factura_descargaSATId_fkey" FOREIGN KEY ("descargaSATId") REFERENCES "DescargaSAT"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DescargaSAT" ADD CONSTRAINT "DescargaSAT_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
