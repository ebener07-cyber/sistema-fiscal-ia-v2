/*
  Warnings:

  - A unique constraint covering the columns `[uuid]` on the table `Factura` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `subtotal` to the `Factura` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updatedAt` to the `Factura` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Factura" ADD COLUMN     "categoria" TEXT,
ADD COLUMN     "clienteId" TEXT,
ADD COLUMN     "complementoNomina" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "complementoPago" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "conceptosClave" TEXT,
ADD COLUMN     "confirmacion" TEXT,
ADD COLUMN     "descuento" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "direccion" TEXT NOT NULL DEFAULT 'emitida',
ADD COLUMN     "emisorNombre" TEXT,
ADD COLUMN     "emisorRfc" TEXT,
ADD COLUMN     "estado" TEXT NOT NULL DEFAULT 'cargada',
ADD COLUMN     "fecha" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "formaPago" TEXT NOT NULL DEFAULT '01',
ADD COLUMN     "lugarExpedicion" TEXT,
ADD COLUMN     "metodoPago" TEXT NOT NULL DEFAULT 'PUE',
ADD COLUMN     "moneda" TEXT NOT NULL DEFAULT 'MXN',
ADD COLUMN     "proveedor" TEXT,
ADD COLUMN     "receptorNombre" TEXT,
ADD COLUMN     "receptorRfc" TEXT,
ADD COLUMN     "receptorUsoCfdi" TEXT DEFAULT 'G03',
ADD COLUMN     "serie" TEXT,
ADD COLUMN     "subtotal" DOUBLE PRECISION NOT NULL,
ADD COLUMN     "tipoCambio" DOUBLE PRECISION NOT NULL DEFAULT 1,
ADD COLUMN     "tipoComprobante" TEXT NOT NULL DEFAULT 'I',
ADD COLUMN     "totalImpuestos" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "uuid" TEXT,
ADD COLUMN     "xmlOriginal" TEXT,
ADD COLUMN     "xmlTimbrado" TEXT;

-- CreateTable
CREATE TABLE "Usuario" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "nombre" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Usuario_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Concepto" (
    "id" TEXT NOT NULL,
    "facturaId" TEXT NOT NULL,
    "claveProdServ" TEXT,
    "noIdentificacion" TEXT,
    "cantidad" DOUBLE PRECISION NOT NULL,
    "claveUnidad" TEXT NOT NULL DEFAULT 'H87',
    "unidad" TEXT NOT NULL DEFAULT 'Pieza',
    "descripcion" TEXT NOT NULL,
    "valorUnitario" DOUBLE PRECISION NOT NULL,
    "importe" DOUBLE PRECISION NOT NULL,
    "objetoImpuesto" TEXT NOT NULL DEFAULT '02',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Concepto_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Impuesto" (
    "id" TEXT NOT NULL,
    "facturaId" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "impuesto" TEXT NOT NULL,
    "tasaOcuota" DOUBLE PRECISION NOT NULL,
    "importe" DOUBLE PRECISION NOT NULL,
    "retencion" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Impuesto_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EstadoDeCuenta" (
    "id" TEXT NOT NULL,
    "banco" TEXT NOT NULL,
    "cuenta" TEXT NOT NULL,
    "periodoInicio" TIMESTAMP(3) NOT NULL,
    "periodoFin" TIMESTAMP(3) NOT NULL,
    "saldoInicial" DOUBLE PRECISION NOT NULL,
    "saldoFinal" DOUBLE PRECISION NOT NULL,
    "empresaId" TEXT NOT NULL,
    "archivoOriginal" TEXT,
    "tipoArchivo" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "EstadoDeCuenta_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MovimientoBancario" (
    "id" TEXT NOT NULL,
    "estadoCuentaId" TEXT NOT NULL,
    "fecha" TIMESTAMP(3) NOT NULL,
    "descripcion" TEXT NOT NULL,
    "referencia" TEXT,
    "monto" DOUBLE PRECISION NOT NULL,
    "tipo" TEXT NOT NULL,
    "concepto" TEXT,
    "rfc" TEXT,
    "conciliado" BOOLEAN NOT NULL DEFAULT false,
    "facturaId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MovimientoBancario_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Conciliacion" (
    "id" TEXT NOT NULL,
    "facturaId" TEXT NOT NULL,
    "movimientoId" TEXT NOT NULL,
    "metodo" TEXT NOT NULL,
    "confianza" DOUBLE PRECISION,
    "notas" TEXT,
    "conciliadoPor" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Conciliacion_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Usuario_email_key" ON "Usuario"("email");

-- CreateIndex
CREATE INDEX "Concepto_facturaId_idx" ON "Concepto"("facturaId");

-- CreateIndex
CREATE INDEX "Impuesto_facturaId_idx" ON "Impuesto"("facturaId");

-- CreateIndex
CREATE INDEX "EstadoDeCuenta_empresaId_idx" ON "EstadoDeCuenta"("empresaId");

-- CreateIndex
CREATE INDEX "EstadoDeCuenta_periodoInicio_periodoFin_idx" ON "EstadoDeCuenta"("periodoInicio", "periodoFin");

-- CreateIndex
CREATE INDEX "MovimientoBancario_estadoCuentaId_idx" ON "MovimientoBancario"("estadoCuentaId");

-- CreateIndex
CREATE INDEX "MovimientoBancario_fecha_idx" ON "MovimientoBancario"("fecha");

-- CreateIndex
CREATE INDEX "MovimientoBancario_monto_idx" ON "MovimientoBancario"("monto");

-- CreateIndex
CREATE INDEX "MovimientoBancario_conciliado_idx" ON "MovimientoBancario"("conciliado");

-- CreateIndex
CREATE UNIQUE INDEX "Conciliacion_movimientoId_key" ON "Conciliacion"("movimientoId");

-- CreateIndex
CREATE INDEX "Conciliacion_facturaId_idx" ON "Conciliacion"("facturaId");

-- CreateIndex
CREATE INDEX "Conciliacion_movimientoId_idx" ON "Conciliacion"("movimientoId");

-- CreateIndex
CREATE INDEX "Conciliacion_createdAt_idx" ON "Conciliacion"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "Factura_uuid_key" ON "Factura"("uuid");

-- CreateIndex
CREATE INDEX "Factura_empresaId_idx" ON "Factura"("empresaId");

-- CreateIndex
CREATE INDEX "Factura_clienteId_idx" ON "Factura"("clienteId");

-- CreateIndex
CREATE INDEX "Factura_fecha_idx" ON "Factura"("fecha");

-- CreateIndex
CREATE INDEX "Factura_uuid_idx" ON "Factura"("uuid");

-- CreateIndex
CREATE INDEX "Factura_folio_idx" ON "Factura"("folio");

-- CreateIndex
CREATE INDEX "Factura_direccion_idx" ON "Factura"("direccion");

-- CreateIndex
CREATE INDEX "Factura_estado_idx" ON "Factura"("estado");

-- AddForeignKey
ALTER TABLE "Factura" ADD CONSTRAINT "Factura_clienteId_fkey" FOREIGN KEY ("clienteId") REFERENCES "Cliente"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Concepto" ADD CONSTRAINT "Concepto_facturaId_fkey" FOREIGN KEY ("facturaId") REFERENCES "Factura"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Impuesto" ADD CONSTRAINT "Impuesto_facturaId_fkey" FOREIGN KEY ("facturaId") REFERENCES "Factura"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EstadoDeCuenta" ADD CONSTRAINT "EstadoDeCuenta_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "Empresa"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MovimientoBancario" ADD CONSTRAINT "MovimientoBancario_estadoCuentaId_fkey" FOREIGN KEY ("estadoCuentaId") REFERENCES "EstadoDeCuenta"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Conciliacion" ADD CONSTRAINT "Conciliacion_facturaId_fkey" FOREIGN KEY ("facturaId") REFERENCES "Factura"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Conciliacion" ADD CONSTRAINT "Conciliacion_movimientoId_fkey" FOREIGN KEY ("movimientoId") REFERENCES "MovimientoBancario"("id") ON DELETE CASCADE ON UPDATE CASCADE;
