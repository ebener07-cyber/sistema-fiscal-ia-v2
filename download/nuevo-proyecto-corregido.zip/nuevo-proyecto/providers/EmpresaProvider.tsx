'use client';

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Empresa {
  id: string;
  nombre: string;
  rfc: string;
  logo?: string;
  status?: string;
}

interface EmpresaContextType {
  empresas: Empresa[];
  empresaSeleccionada: Empresa | null;
  setEmpresaSeleccionada: (empresa: Empresa) => void;
  loading: boolean;
  refreshEmpresas: () => Promise<void>;
}

const EmpresaContext = createContext<EmpresaContextType | undefined>(undefined);

export function EmpresaProvider({ children }: { children: ReactNode }) {
  const [empresas, setEmpresas] = useState<Empresa[]>([]);
  const [empresaSeleccionada, setEmpresaSeleccionadaState] = useState<Empresa | null>(null);
  const [loading, setLoading] = useState(true);

  // Cargar empresas al iniciar
  useEffect(() => {
    refreshEmpresas();
  }, []);

  // Cargar empresa seleccionada desde localStorage
  useEffect(() => {
    const saved = localStorage.getItem('empresaSeleccionada');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Verificar que la empresa aún existe en la lista
        const exists = empresas.find(e => e.id === parsed.id);
        if (exists) {
          setEmpresaSeleccionadaState(exists);
        }
      } catch (e) {
        console.error('Error parsing saved empresa:', e);
      }
    }
  }, [empresas]);

  const refreshEmpresas = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/empresas');
      const data = await res.json();
      
      const empresasMapped: Empresa[] = data.data?.map((e: any) => ({
        id: e.id,
        nombre: e.nombre,
        rfc: e.rfc,
        logo: '🏢',
        status: e.status,
      })) || [];

      setEmpresas(empresasMapped);

      // Si no hay empresa seleccionada, seleccionar la primera
      if (!empresaSeleccionada && empresasMapped.length > 0) {
        setEmpresaSeleccionadaState(empresasMapped[0]);
      }
    } catch (error) {
      console.error('Error cargando empresas:', error);
    } finally {
      setLoading(false);
    }
  };

  const setEmpresaSeleccionada = (empresa: Empresa) => {
    setEmpresaSeleccionadaState(empresa);
    localStorage.setItem('empresaSeleccionada', JSON.stringify(empresa));
  };

  return (
    <EmpresaContext.Provider value={{
      empresas,
      empresaSeleccionada,
      setEmpresaSeleccionada,
      loading,
      refreshEmpresas
    }}>
      {children}
    </EmpresaContext.Provider>
  );
}

export function useEmpresa() {
  const context = useContext(EmpresaContext);
  if (context === undefined) {
    throw new Error('useEmpresa must be used within an EmpresaProvider');
  }
  return context;
}