'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

interface User {
  email: string;
  name: string;
  role: 'developer' | 'auditor';
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  isLoading: boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  // Credenciales válidas
  const validCredentials = {
    developer: { 
      email: 'dev@ejemplo.com', 
      password: 'dev12345', 
      name: 'Desarrollador', 
      role: 'developer' as const 
    },
    auditor: { 
      email: 'auditor@ejemplo.com', 
      password: 'auditor123', 
      name: 'Auditor', 
      role: 'auditor' as const 
    },
  };

  // Función de login
  const login = async (email: string, password: string) => {
    // Simulamos un retraso de red
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Verificar credenciales
    const validUser = Object.values(validCredentials).find(
      cred => cred.email === email && cred.password === password
    );

    if (validUser) {
      const userData = { 
        email: validUser.email, 
        name: validUser.name, 
        role: validUser.role 
      };
      setUser(userData);

      // Crear cookie auth-token para el middleware
      const tokenPayload = {
        email: validUser.email,
        name: validUser.name,
        role: validUser.role,
        exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // Expira en 24 horas
      };

      const tokenBase64 = Buffer.from(JSON.stringify(tokenPayload)).toString('base64');
      document.cookie = `auth-token=${tokenBase64}; path=/; max-age=86400; SameSite=Lax`;

      return { success: true };
    } else {
      return { success: false, error: 'Credenciales incorrectas' };
    }
  };

  const logout = () => {
    setUser(null);
    // Eliminar cookie
    document.cookie = 'auth-token=; path=/; max-age=0';
  };

  const isAuthenticated = !!user;

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        isLoading: false,
        isAuthenticated,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}