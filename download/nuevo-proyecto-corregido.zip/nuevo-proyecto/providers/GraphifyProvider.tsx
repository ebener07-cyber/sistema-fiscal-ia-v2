'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

interface GraphifyContextType {
  data: any;
  setData: (data: any) => void;
}

const GraphifyContext = createContext<GraphifyContextType | undefined>(undefined);

export function GraphifyProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<any>(null);

  return (
    <GraphifyContext.Provider value={{ data, setData }}>
      {children}
    </GraphifyContext.Provider>
  );
}

export function useGraphify() {
  const context = useContext(GraphifyContext);
  if (context === undefined) {
    throw new Error('useGraphify must be used within a GraphifyProvider');
  }
  return context;
}